<div class="container" style="max-width: 420px; margin: 48px auto;">
    <div class="card" style="padding: 2rem; box-shadow: 0 1px 4px #0001; border-radius: 10px;">
        <h2 style="margin-bottom: 1rem;">CurseForge Browser: Admin Settings</h2>

        <div id="cfStatus" style="margin-bottom: 1rem; font-size: 0.9rem; color: #9aa0a6;">
            Checking status…
        </div>

        <form id="cfTokenForm">
            <div style="margin-bottom: 1.25rem;">
                <label for="apiToken" style="font-weight: 500;">CurseForge API Token</label>
                <input type="password" class="form-control" id="apiToken" name="apiToken"
                    placeholder="Enter your CurseForge API token…" style="margin-top: 0.5rem;">
                <small class="form-text text-muted">
                    Required for CurseForge plugin installation.<br>
                    The token is encrypted before being stored.
                </small>
            </div>
            <button type="submit" class="btn btn-primary" id="cfSaveBtn" style="width: 100%;">
                Save Token
            </button>
            <button type="button" class="btn btn-danger" id="cfRemoveBtn" style="width: 100%; margin-top: 0.5rem;">
                Remove Token
            </button>
        </form>
    </div>
</div>

<script>
(function () {
    const base = '/admin/extensions/modrinthbrowser';
    const statusEl = document.getElementById('cfStatus');
    const form = document.getElementById('cfTokenForm');
    const input = document.getElementById('apiToken');
    const saveBtn = document.getElementById('cfSaveBtn');
    const removeBtn = document.getElementById('cfRemoveBtn');

    function csrfToken() {
        const meta = document.querySelector('meta[name="csrf-token"]');
        return meta ? meta.getAttribute('content') : '';
    }

    function refreshStatus() {
        fetch(`${base}/curseforge/status`, {
            headers: { 'Accept': 'application/json' },
            credentials: 'same-origin',
        })
            .then(r => r.json())
            .then(data => {
                statusEl.textContent = data.configured
                    ? '✅ A CurseForge API token is currently saved.'
                    : '⚠️ No CurseForge API token saved yet.';
                statusEl.style.color = data.configured ? '#3fb950' : '#c77c15';
            })
            .catch(() => {
                statusEl.textContent = 'Could not check token status.';
            });
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        const token = input.value.trim();
        if (!token) return;

        saveBtn.disabled = true;
        saveBtn.textContent = 'Saving…';

        fetch(`${base}/curseforge/token`, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken(),
            },
            body: JSON.stringify({ apiToken: token }),
        })
            .then(r => r.json())
            .then(data => {
                saveBtn.textContent = 'Save Token';
                saveBtn.disabled = false;
                if (data.success) {
                    input.value = '';
                    refreshStatus();
                } else {
                    alert(data.message || 'Failed to save token.');
                }
            })
            .catch(() => {
                saveBtn.textContent = 'Save Token';
                saveBtn.disabled = false;
                alert('Request failed.');
            });
    });

    removeBtn.addEventListener('click', function () {
        if (!confirm('Remove the saved CurseForge API token?')) return;

        fetch(`${base}/curseforge/token`, {
            method: 'DELETE',
            credentials: 'same-origin',
            headers: {
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken(),
            },
        })
            .then(r => r.json())
            .then(() => refreshStatus())
            .catch(() => alert('Request failed.'));
    });

    refreshStatus();
})();
</script>

<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\BlueprintFramework\Extensions\modrinthbrowser\PluginController;
use Pterodactyl\BlueprintFramework\Extensions\modrinthbrowser\AdminController;
use Pterodactyl\BlueprintFramework\Extensions\modrinthbrowser\CurseforgeController;

Route::post('/download', [PluginController::class, 'download'])->name('extension.modrinthbrowser.download');

// CurseForge — used by logged-in users browsing the Plugins tab.
Route::get('/curseforge/search', [CurseforgeController::class, 'search'])->name('extension.modrinthbrowser.curseforge.search');
Route::get('/curseforge/versions/{modId}', [CurseforgeController::class, 'versions'])->name('extension.modrinthbrowser.curseforge.versions');
Route::post('/curseforge/download', [CurseforgeController::class, 'download'])->name('extension.modrinthbrowser.curseforge.download');

// Admin-only — saving/checking/removing the CurseForge API token.
Route::middleware(['auth', 'admin'])->prefix('admin')->group(function () {
    Route::get('/curseforge/status', [AdminController::class, 'status'])->name('extension.modrinthbrowser.admin.status');
    Route::post('/curseforge/token', [AdminController::class, 'saveToken'])->name('extension.modrinthbrowser.admin.save');
    Route::delete('/curseforge/token', [AdminController::class, 'deleteToken'])->name('extension.modrinthbrowser.admin.delete');
});

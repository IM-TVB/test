<?php

namespace Pterodactyl\BlueprintFramework\Extensions\modrinthbrowser;

use Illuminate\Http\Request;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\Http;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;
use Pterodactyl\Exceptions\Http\Connection\DaemonConnectionException;

class CurseforgeController extends Controller
{
    private DaemonFileRepository $fileRepository;

    // Bukkit Plugins class id on CurseForge
    private const BUKKIT_PLUGINS_CLASS_ID = 5;

    public function __construct(DaemonFileRepository $fileRepository)
    {
        $this->fileRepository = $fileRepository;
    }

    private function apiKeyOrFail(): string
    {
        $token = Setting::getCurseforgeToken();
        if (!$token) {
            abort(response()->json([
                'success' => false,
                'message' => 'No CurseForge API token has been configured by the panel admin yet.',
            ], 412));
        }
        return $token;
    }

    /**
     * Search CurseForge for plugins/mods.
     */
    public function search(Request $request)
    {
        $apiKey = $this->apiKeyOrFail();

        $request->validate([
            'query' => 'nullable|string',
            'offset' => 'nullable|integer',
            'sort' => 'nullable|string',
        ]);

        $offset = (int) $request->input('offset', 0);

        $sortFieldMap = [
            'relevance' => 1,
            'downloads' => 6,
            'newest' => 11,
            'updated' => 3,
        ];
        $sortField = $sortFieldMap[$request->input('sort', 'relevance')] ?? 1;

        $response = Http::withHeaders([
            'x-api-key' => $apiKey,
            'Accept' => 'application/json',
        ])->get('https://api.curseforge.com/v1/mods/search', [
            'gameId' => 432, // Minecraft
            'classId' => self::BUKKIT_PLUGINS_CLASS_ID,
            'searchFilter' => $request->input('query', ''),
            'sortField' => $sortField,
            'sortOrder' => 'desc',
            'index' => $offset,
            'pageSize' => 12,
        ]);

        if (!$response->successful()) {
            return response()->json([
                'success' => false,
                'message' => 'CurseForge API request failed.',
                'error' => $response->body(),
            ], $response->status());
        }

        $data = $response->json();

        $plugins = collect($data['data'] ?? [])->map(function ($mod) {
            return [
                'id' => (string) $mod['id'],
                'title' => $mod['name'],
                'description' => $mod['summary'] ?? '',
                'author' => $mod['authors'][0]['name'] ?? 'Unknown',
                'downloads' => $mod['downloadCount'] ?? 0,
                'icon_url' => $mod['logo']['thumbnailUrl'] ?? '',
                'categories' => collect($mod['categories'] ?? [])->pluck('name')->take(3)->values(),
                'date_modified' => $mod['dateModified'] ?? now()->toIso8601String(),
                'platform' => 'curseforge',
            ];
        })->values();

        return response()->json([
            'success' => true,
            'plugins' => $plugins,
            'total' => $data['pagination']['totalCount'] ?? $plugins->count(),
        ]);
    }

    /**
     * List versions/files for a given CurseForge mod.
     */
    public function versions(Request $request, string $modId)
    {
        $apiKey = $this->apiKeyOrFail();

        $response = Http::withHeaders([
            'x-api-key' => $apiKey,
            'Accept' => 'application/json',
        ])->get("https://api.curseforge.com/v1/mods/{$modId}/files", [
            'pageSize' => 20,
        ]);

        if (!$response->successful()) {
            return response()->json([
                'success' => false,
                'message' => 'Could not load CurseForge versions.',
                'error' => $response->body(),
            ], $response->status());
        }

        $data = $response->json();

        $versions = collect($data['data'] ?? [])->map(function ($file) {
            return [
                'id' => (string) $file['id'],
                'name' => $file['displayName'] ?? $file['fileName'],
                'version_type' => strtolower($file['releaseType'] ?? 'release') === 1 ? 'release' : 'release',
                'date_published' => $file['fileDate'] ?? now()->toIso8601String(),
                'downloads' => $file['downloadCount'] ?? 0,
                'files' => [[
                    'url' => $file['downloadUrl'] ?? '',
                    'filename' => $file['fileName'],
                    'primary' => true,
                    'size' => $file['fileLength'] ?? 0,
                ]],
                'game_versions' => $file['gameVersions'] ?? [],
                'loaders' => collect($file['gameVersions'] ?? [])
                    ->filter(fn ($v) => in_array(strtolower($v), ['paper', 'spigot', 'bukkit', 'purpur', 'folia']))
                    ->values(),
            ];
        })->values();

        return response()->json([
            'success' => true,
            'versions' => $versions,
        ]);
    }

    /**
     * Download a plugin file from CurseForge onto the target server.
     */
    public function download(Request $request)
    {
        $apiKey = $this->apiKeyOrFail();

        $request->validate([
            'downloadUrl' => 'required|url',
            'filename' => 'required|string|ends_with:.jar',
            'serverUuid' => 'required|string|exists:servers,uuid',
        ]);

        $server = Server::where('uuid', $request->input('serverUuid'))->firstOrFail();
        $this->authorize('file.create', $server);

        $url = $request->input('downloadUrl');
        $filename = $request->input('filename');

        try {
            // CurseForge file download URLs are pre-signed CDN links; the API
            // key is not required on this request, but we send it anyway in
            // case the URL ever needs authenticating.
            $response = Http::withHeaders(['x-api-key' => $apiKey])->get($url);

            if (!$response->successful()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Failed to download file from CurseForge.',
                ], 502);
            }

            $path = '/plugins/' . $filename;
            $this->fileRepository->setServer($server)->putContent($path, $response->body());

            return response()->json([
                'success' => true,
                'path' => $path,
            ]);
        } catch (DaemonConnectionException $ex) {
            return response()->json([
                'success' => false,
                'message' => 'Could not connect to server daemon.',
                'error' => $ex->getMessage(),
            ], 500);
        } catch (\Exception $ex) {
            return response()->json([
                'success' => false,
                'message' => 'An unexpected error occurred.',
                'error' => $ex->getMessage(),
            ], 500);
        }
    }
}

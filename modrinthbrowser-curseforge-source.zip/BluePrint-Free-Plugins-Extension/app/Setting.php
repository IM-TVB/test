<?php

namespace Pterodactyl\BlueprintFramework\Extensions\modrinthbrowser;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class Setting extends Model
{
    protected $table = 'modrinthbrowser_settings';
    protected $fillable = ['key', 'value'];

    public static function getCurseforgeToken(): ?string
    {
        $row = self::where('key', 'curseforge_api_token')->first();
        if (!$row || !$row->value) {
            return null;
        }

        try {
            return Crypt::decryptString($row->value);
        } catch (\Exception $e) {
            return null;
        }
    }

    public static function setCurseforgeToken(string $token): void
    {
        self::updateOrCreate(
            ['key' => 'curseforge_api_token'],
            ['value' => Crypt::encryptString($token)]
        );
    }

    public static function hasCurseforgeToken(): bool
    {
        return self::getCurseforgeToken() !== null;
    }
}

<?php

namespace Pterodactyl\BlueprintFramework\Extensions\modrinthbrowser;

use Illuminate\Http\Request;
use Pterodactyl\Http\Controllers\Controller;

class AdminController extends Controller
{
    /**
     * Return whether a token is currently saved (never returns the token itself).
     */
    public function status()
    {
        return response()->json([
            'configured' => Setting::hasCurseforgeToken(),
        ]);
    }

    /**
     * Save (or replace) the CurseForge API token.
     */
    public function saveToken(Request $request)
    {
        $request->validate([
            'apiToken' => 'required|string|min:10|max:255',
        ]);

        Setting::setCurseforgeToken($request->input('apiToken'));

        return response()->json([
            'success' => true,
            'message' => 'CurseForge API token saved.',
        ]);
    }

    /**
     * Remove the saved token.
     */
    public function deleteToken()
    {
        Setting::where('key', 'curseforge_api_token')->delete();

        return response()->json([
            'success' => true,
            'message' => 'CurseForge API token removed.',
        ]);
    }
}

#!/usr/bin/env bash
#
# Seal the theme package: write CHECKSUMS, a sha256 of every file the manifest
# ships, plus a VERSION stamp.
#
#   ./seal.sh              # stamp the version from git if there is one, else keep it
#   ./seal.sh 1.4.0        # stamp an explicit version
#
# Why this exists at all: `--check` compares the panel against this package, which
# is only meaningful if the package itself is trustworthy. Without CHECKSUMS a
# tampered or half-copied package would "verify" a tampered panel perfectly --
# the check would be comparing the damage against itself. So the check verifies
# the package first and refuses to continue if it has drifted.
#
# CHECKSUMS covers the *sources* the manifest names, not the deployed copies. The
# deployed copies are compared against these, which keeps one list rather than two
# that can disagree.

set -euo pipefail

THEME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$THEME_DIR"

VERSION_ARG="${1:-}"

# The manifest lives in install.sh as a shell array, so it is read from there
# rather than duplicated here. A second copy of the file list is a second thing to
# forget to update, and the failure mode is a checksum file that silently covers
# less than the installer installs.
manifest_sources() {
    sed -n '/^MANIFEST=(/,/^)/p' install.sh \
        | grep -oE '"[^"|]+\|[^"]+"' \
        | sed -E 's/^"[^"|]+\|//; s/"$//'
}

if [[ -n "$VERSION_ARG" ]]; then
    printf '%s\n' "$VERSION_ARG" > VERSION
elif [[ ! -f VERSION ]]; then
    # No explicit version and no stamp yet. Date it, and say so, rather than
    # inventing a number that would look like a release.
    printf '%s\n' "unversioned-$(date +%Y%m%d)" > VERSION
    echo "  wrote a dated placeholder to VERSION; pass a version to set a real one"
fi

# The manifest's source list, plus every file in the package that is NOT in the
# manifest. The manifest only names files the installer DEPLOYS; the package's own
# tools live outside it, and an unchecked tool is the worst thing to leave out --
# panel-update.sh is the thing that takes a backup and rewrites the panel, and
# db-config.php is the thing that reads the database password. A tampered
# installer is bad; a tampered updater is worse, because nobody runs --check before
# trusting it.
#
# Found by listing the package rather than by naming them, so adding a script does
# not silently leave it uncovered. dist/ is excluded, because the archive inside it
# contains CHECKSUMS which would then disagree with this one.
PACKAGE_TOOLS=()
while IFS= read -r f; do
    rel="${f#./}"
    case "$rel" in
        CHECKSUMS*|VERSION|dist/*) continue ;;
    esac
    PACKAGE_TOOLS+=("$rel")
done < <(find . -maxdepth 1 -type f | sort)

{
    manifest_sources
    printf '%s\n' "${PACKAGE_TOOLS[@]}"
} | sort -u | while IFS= read -r rel; do
    if [[ ! -f "$rel" ]]; then
        echo "  MISSING: $rel is in the manifest but not in the package" >&2
        exit 1
    fi
    sha256sum "$rel"
done > CHECKSUMS.tmp

mv CHECKSUMS.tmp CHECKSUMS

echo "  sealed $(wc -l < CHECKSUMS) files, version $(cat VERSION)"

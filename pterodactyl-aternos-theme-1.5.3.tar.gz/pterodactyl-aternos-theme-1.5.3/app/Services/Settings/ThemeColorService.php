<?php

namespace Pterodactyl\Services\Settings;

/**
 * The panel's colours, set from the admin area.
 *
 * Stored as a JSON sidecar next to the branding files, so the values are
 * readable without booting the database and resetting them is deleting a file.
 *
 * Only the base colours are stored. Everything the theme consumes -- the
 * Tailwind `at-primary-*` scale, the `--at-*` custom properties read by
 * assets/aternos.css -- is derived here, so a customised colour and its
 * shades can never drift apart.
 *
 * Fields, with their defaults matching the stock stylesheet:
 *
 *   primary   buttons, links, focus rings
 *   sidebar / sidebarText   the left navigation surface and its text
 *   nav       the top bar (blue mode is 88% alpha, dark mode opaque)
 *   pageBlue / pageDark   content background per mode
 *   surfaceBlue / surfaceDark   card background per mode
 *   textBlue / textDark   body text per mode
 *   borderBlue / borderDark   separators per mode
 *   success / warning / danger   the status colours
 *
 * A field that is left unset simply does not appear in the generated CSS, and
 * the stock stylesheet value wins. That is what keeps a partial customisation
 * from recolouring things the operator never touched.
 */
class ThemeColorService
{
    public const DEFAULTS = [
        'primary' => '#007bff',
        'sidebar' => '#1f2933',
        'sidebarText' => '#e5e8ec',
        'nav' => '#ffffff',
        'pageBlue' => '#78b1f2',
        'pageDark' => '#33404c',
        'surfaceBlue' => '#9dc4f1',
        'surfaceDark' => '#3e4d5a',
        'textBlue' => '#112136',
        'textDark' => '#e5e8ec',
        'borderBlue' => '#79aae1',
        'borderDark' => '#7d8996',
        'success' => '#28a745',
        'warning' => '#ffc107',
        'danger' => '#dc3545',
    ];

    /** Fields that keep their value forever, order preserved for the UI. */
    public const FIELDS = [
        'primary',
        'sidebar', 'sidebarText', 'nav',
        'pageBlue', 'surfaceBlue', 'textBlue', 'borderBlue',
        'pageDark', 'surfaceDark', 'textDark', 'borderDark',
        'success', 'warning', 'danger',
    ];

    public const DEFAULT = self::DEFAULTS['primary'];

    public function path(): string
    {
        return public_path('branding/colors.json');
    }

    public function metadata(): array
    {
        $path = $this->path();

        if (!is_file($path) || !is_readable($path)) {
            return [];
        }

        $decoded = json_decode((string) @file_get_contents($path), true);

        return is_array($decoded) ? $decoded : [];
    }

    /** The raw map of customised fields: ['primary' => '#ff00aa', ...]. */
    public function customised(): array
    {
        $stored = $this->metadata()['colors'] ?? null;

        if (is_array($stored)) {
            $out = [];
            foreach (self::FIELDS as $field) {
                if (isset($stored[$field]) && $this->isValidHex($stored[$field])) {
                    $out[$field] = $stored[$field];
                }
            }
            return $out;
        }

        // One version back the file held a single 'primary' key at the top
        // level. Read it rather than discarding the operator's colour.
        $legacy = $this->metadata()['primary'] ?? null;

        return (is_string($legacy) && $this->isValidHex($legacy)) ? ['primary' => strtolower($legacy)] : [];
    }

    public function hasCustom(): bool
    {
        return $this->customised() !== [];
    }

    public function primary(): string
    {
        return $this->value('primary');
    }

    /**
     * The custom footer line, or null to keep the stock copyright. Read from
     * the same sidecar as the colours because there is no other natural home
     * for a one-line site setting, and resetting it is an empty string.
     */
    public function footerText(): ?string
    {
        $text = $this->metadata()['footerText'] ?? null;

        return (is_string($text) && trim($text) !== '') ? trim($text) : null;
    }

    public function setFooterText(?string $text): ?string
    {
        $meta = $this->metadata();
        $text = $text === null ? null : trim($text);

        if ($text !== null && $text !== '' && mb_strlen($text) > 200) {
            throw new \InvalidArgumentException('The footer text must be 200 characters or fewer.');
        }

        if ($text === '' ) {
            $text = null;
        }

        if ($text === null) {
            unset($meta['footerText']);
        } else {
            $meta['footerText'] = $text;
        }
        $meta['updatedAt'] = now()->toIso8601String();

        $dir = dirname($this->path());
        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new \RuntimeException('Could not create ' . $dir . '.');
        }

        file_put_contents($this->path(), json_encode($meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");

        return $text;
    }

    public function value(string $field): string
    {
        $custom = $this->customised()[$field] ?? null;

        return $custom ?? self::DEFAULTS[$field];
    }

    public function set(array $fields): array
    {
        $stored = [];

        foreach (self::FIELDS as $field) {
            $raw = $fields[$field] ?? null;

            if ($raw === null || $raw === '') {
                continue; // unset means "leave at the stock value"
            }

            $hex = $this->normalise((string) $raw);

            if (!$this->isValidHex($hex)) {
                throw new \InvalidArgumentException(sprintf(
                    '%s must be a hex value like #007bff or #07f.',
                    $field,
                ));
            }

            $stored[$field] = $hex;
        }

        $meta = $this->metadata();
        $meta['colors'] = $stored;
        $meta['updatedAt'] = now()->toIso8601String();

        $dir = dirname($this->path());

        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new \RuntimeException('Could not create ' . $dir . '. Check that public/ is writable.');
        }

        file_put_contents(
            $this->path(),
            json_encode($meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n",
        );

        return $stored;
    }

    public function reset(): bool
    {
        if (!is_file($this->path())) {
            return false;
        }

        return @unlink($this->path());
    }

    /**
     * Drop one field back to its stock value while keeping the others. Used by
     * the per-row reset on the colours settings page.
     */
    public function resetField(string $field): bool
    {
        if (!in_array($field, self::FIELDS, true)) {
            throw new \InvalidArgumentException('Unknown colour field: ' . $field);
        }

        $custom = $this->customised();

        if (!isset($custom[$field])) {
            return false;
        }

        unset($custom[$field]);

        if ($custom === []) {
            return $this->reset();
        }

        $dir = dirname($this->path());

        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new \RuntimeException('Could not create ' . $dir . '.');
        }

        $meta = $this->metadata();
        $meta['colors'] = $custom;
        $meta['updatedAt'] = now()->toIso8601String();

        file_put_contents(
            $this->path(),
            json_encode($meta, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n",
        );

        return true;
    }

    /**
     * Everything the front end needs, in the shape AssetComposer carries on
     * siteConfiguration.
     */
    public function forTheme(): array
    {
        return [
            'primary' => $this->primary(),
            'custom' => $this->hasCustom(),
            'customised' => $this->customised(),
            'values' => $this->values(),
            'footerText' => $this->footerText(),
            'css' => $this->cssVariables(),
            'pageRgb' => [
                'blue' => $this->rgbComponents($this->value('pageBlue')),
                'dark' => $this->rgbComponents($this->value('pageDark')),
            ],
        ];
    }

    /** Every field's effective value, for the admin form. */
    public function values(): array
    {
        $out = [];
        foreach (self::FIELDS as $field) {
            $out[$field] = $this->value($field);
        }
        return $out;
    }

    /**
     * The CSS custom properties to override, split by mode, containing ONLY
     * keys whose base field the operator customised. Shape:
     *
     *   ['shared' => [ '--at-success' => '#...', ...],
     *    'blue'   => [ '--at-page' => '#...', ...],
     *    'dark'   => [ ... ]]
     */
    public function cssVariables(): array
    {
        $custom = $this->customised();
        $shared = [];
        $blue = [];
        $dark = [];

        if (isset($custom['primary'])) {
            $p = $custom['primary'];
            [$r, $g, $b] = $this->components($p);

            $shared += [
                '--at-primary' => $p,
                '--at-primary-50' => $this->tint($p, 0.92),
                '--at-primary-100' => $this->tint($p, 0.80),
                '--at-primary-200' => $this->tint($p, 0.60),
                '--at-primary-300' => $this->tint($p, 0.40),
                '--at-primary-400' => $this->tint($p, 0.20),
                '--at-primary-500' => $p,
                '--at-primary-600' => $this->shade($p, 0.20),
                '--at-primary-700' => $this->shade($p, 0.38),
                '--at-primary-800' => $this->shade($p, 0.55),
                '--at-primary-900' => $this->shade($p, 0.70),
                '--at-side-active-bg' => sprintf('rgba(%d, %d, %d, 0.18)', $r, $g, $b),
            ];

            $blue += [
                '--at-primary-soft' => $this->tint($p, 0.93),
                '--at-primary-contrast' => $this->shade($p, 0.56),
            ];

            $dark += [
                '--at-primary-soft' => sprintf('rgba(%d, %d, %d, 0.18)', $r, $g, $b),
                '--at-primary-contrast' => $p,
                '--at-side-active-text' => $this->tint($p, 0.45),
            ];
        }

        if (isset($custom['sidebar'])) {
            $s = $custom['sidebar'];

            $shared += [
                '--at-side-bg' => $s,
                '--at-side-raised' => $this->tint($s, 0.10),
                '--at-side-hover' => $this->tint($s, 0.28),
                '--at-side-border' => $this->tint($s, 0.45),
            ];
        }

        if (isset($custom['sidebarText'])) {
            $t = $custom['sidebarText'];
            $sideBg = $custom['sidebar'] ?? self::DEFAULTS['sidebar'];

            $shared += [
                '--at-side-text' => $t,
                '--at-side-body' => $this->mix($t, $sideBg, 0.62),
                '--at-side-muted' => $this->mix($t, $sideBg, 0.38),
                '--at-side-faint' => $this->mix($t, $sideBg, 0.82),
            ];
        }

        if (isset($custom['nav'])) {
            $n = $custom['nav'];
            [$r, $g, $b] = $this->components($n);

            $blue += ['--at-nav-bg-blur' => sprintf('rgba(%d, %d, %d, 0.88)', $r, $g, $b)];
            $dark += ['--at-nav-bg-blur' => $n];
        }

        // Effective surfaces: the derived one follows the page, but an explicit
        // surface wins. Used for the file-row tints and the text shades.
        $surfaceBlue = $custom['surfaceBlue'] ?? $this->mixWithWhite($custom['pageBlue'] ?? self::DEFAULTS['pageBlue'], 0.26);
        $surfaceDark = $custom['surfaceDark'] ?? $this->mixWithWhite($custom['pageDark'] ?? self::DEFAULTS['pageDark'], 0.06);

        if (isset($custom['pageBlue'])) {
            $blue += [
                '--at-page' => $custom['pageBlue'],
                '--at-surface' => $surfaceBlue,
                '--at-border' => $this->mixWithBlack($custom['pageBlue'], 0.10),
                '--at-border-strong' => $this->mixWithBlack($custom['pageBlue'], 0.20),
            ];
        }

        if (isset($custom['pageDark'])) {
            $dark += [
                '--at-page' => $custom['pageDark'],
                '--at-surface' => $surfaceDark,
                '--at-border' => $this->mixWithWhite($custom['pageDark'], 0.32),
                '--at-border-strong' => $this->mixWithWhite($custom['pageDark'], 0.68),
            ];
        }

        if (isset($custom['surfaceBlue'])) {
            $blue['--at-surface'] = $custom['surfaceBlue'];
        }

        if (isset($custom['surfaceDark'])) {
            $dark['--at-surface'] = $custom['surfaceDark'];
        }

        if (isset($custom['surfaceBlue']) || isset($custom['pageBlue'])) {
            [$r, $g, $b] = $this->components($surfaceBlue);
            $blue += [
                '--at-file-row' => sprintf('rgba(%d, %d, %d, 0.5)', $r, $g, $b),
                '--at-file-row-hover' => sprintf('rgba(%d, %d, %d, 0.75)', max($r - 30, 0), max($g - 28, 0), max($b - 9, 0)),
            ];
        }

        if (isset($custom['surfaceDark']) || isset($custom['pageDark'])) {
            [$r, $g, $b] = $this->components($surfaceDark);
            $dark += [
                '--at-file-row' => sprintf('rgba(%d, %d, %d, 0.5)', $r, $g, $b),
                '--at-file-row-hover' => sprintf('rgba(%d, %d, %d, 0.58)', max($r - 25, 0), max($g - 25, 0), max($b - 25, 0)),
            ];
        }

        if (isset($custom['textBlue'])) {
            $t = $custom['textBlue'];
            $blue += [
                '--at-text' => $t,
                '--at-text-body' => $this->mix($t, $surfaceBlue, 0.72),
                '--at-text-muted' => $this->mix($t, $surfaceBlue, 0.48),
                '--at-text-faint' => $this->mix($t, $surfaceBlue, 0.30),
            ];
        }

        if (isset($custom['textDark'])) {
            $t = $custom['textDark'];
            $dark += [
                '--at-text' => $t,
                '--at-text-body' => $this->mix($t, $surfaceDark, 0.72),
                '--at-text-muted' => $this->mix($t, $surfaceDark, 0.48),
                '--at-text-faint' => $this->mix($t, $surfaceDark, 0.30),
            ];
        }

        if (isset($custom['borderBlue'])) {
            $blue['--at-border'] = $custom['borderBlue'];
            $blue['--at-border-strong'] = $this->shade($custom['borderBlue'], 0.18);
        }

        if (isset($custom['borderDark'])) {
            $dark['--at-border'] = $custom['borderDark'];
            $dark['--at-border-strong'] = $this->tint($custom['borderDark'], 0.25);
        }

        foreach (['success', 'warning', 'danger'] as $field) {
            if (isset($custom[$field])) {
                $shared['--at-' . $field] = $custom[$field];
            }
        }

        return ['shared' => $shared, 'blue' => $blue, 'dark' => $dark];
    }

    /** tint = mix with white by $amount (0..1, how much white). */
    private function tint(string $hex, float $whiteAmount): string
    {
        return $this->mix($hex, '#ffffff', 1 - $whiteAmount);
    }

    /** shade = mix with black by $amount (0..1, how much black). */
    private function shade(string $hex, float $blackAmount): string
    {
        return $this->mix($hex, '#000000', 1 - $blackAmount);
    }

    private function mixWithWhite(string $hex, float $whiteAmount): string
    {
        return $this->mix($hex, '#ffffff', 1 - $whiteAmount);
    }

    private function mixWithBlack(string $hex, float $blackAmount): string
    {
        return $this->mix($hex, '#000000', 1 - $blackAmount);
    }

    private function mix(string $a, string $b, float $amountOfA): string
    {
        [$r1, $g1, $b1] = $this->components($a);
        [$r2, $g2, $b2] = $this->components($b);

        return sprintf(
            '#%02x%02x%02x',
            (int) round($r1 * $amountOfA + $r2 * (1 - $amountOfA)),
            (int) round($g1 * $amountOfA + $g2 * (1 - $amountOfA)),
            (int) round($b1 * $amountOfA + $b2 * (1 - $amountOfA)),
        );
    }

    private function rgbComponents(string $hex): string
    {
        return implode(', ', $this->components($hex));
    }

    /** @return array{0:int,1:int,2:int} */
    private function components(string $hex): array
    {
        $hex = ltrim($this->normalise($hex), '#');

        return [hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2))];
    }

    private function isValidHex($value): bool
    {
        return is_string($value) && (bool) preg_match('/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', trim($value));
    }

    private function normalise(string $hex): string
    {
        $hex = trim($hex);
        if ($hex !== '' && $hex[0] !== '#') {
            $hex = '#' . $hex;
        }

        if (strlen($hex) === 4) {
            $hex = '#' . $hex[1] . $hex[1] . $hex[2] . $hex[2] . $hex[3] . $hex[3];
        }

        return strtolower($hex);
    }
}

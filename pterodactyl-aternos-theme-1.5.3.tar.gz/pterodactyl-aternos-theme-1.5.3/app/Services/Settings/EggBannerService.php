<?php

namespace Pterodactyl\Services\Settings;

use Illuminate\Support\Facades\DB;

/**
 * The banner shown at the top of a server card, set per egg.
 *
 * Stored in a settings row keyed by egg id rather than a column on `eggs`, for
 * two reasons. It avoids a schema change for a purely cosmetic field, and it
 * means deleting an egg cannot leave a column full of orphaned filenames -- the
 * row and the file are removed together, in remove(), which the egg controller
 * calls on delete.
 *
 * The client learns the url from the server transformer, so a card never has to
 * fetch anything extra: the banner arrives with the server list it is already
 * rendering.
 */
class EggBannerService
{
    use ProbesImageUploads;

    /**
     * A banner is decoration behind a status pill and a power button, so it is
     * smaller than the panel background: it is fetched once per server card on
     * the dashboard, and a page of forty servers multiplies whatever this is.
     */
    public const MAX_BYTES = 2097152; // 2 MB

    private const SETTING_PREFIX = 'egg_banner::';

    public function directory(): string
    {
        return public_path('egg-banners');
    }

    public function absolutePath(string $file): string
    {
        return $this->directory() . '/' . basename($file);
    }

    private function key(int $eggId): string
    {
        return self::SETTING_PREFIX . $eggId;
    }

    /**
     * The stored filename, or null.
     *
     * The existence check is not cached or trusted: an operator can delete the
     * file over SSH, and a card pointing at a 404 renders a broken image where
     * its fallback gradient should be.
     */
    public function file(int $eggId): ?string
    {
        $file = DB::table('settings')->where('key', $this->key($eggId))->value('value');

        if (!$this->isSafeImageName($file, (string) $eggId) || !is_file($this->absolutePath((string) $file))) {
            return null;
        }

        return (string) $file;
    }

    public function url(int $eggId): ?string
    {
        $file = $this->file($eggId);

        return $file === null ? null : asset('egg-banners/' . $file);
    }

    public function has(int $eggId): bool
    {
        return $this->file($eggId) !== null;
    }

    /**
     * @return array{file:string,w:int,h:int,bytes:int}
     */
    public function set(int $eggId, string $sourcePath): array
    {
        $probe = $this->probeImage($sourcePath, self::MAX_BYTES, 'banner');
        $this->ensureDirectory();

        $previous = $this->file($eggId);
        $name = $this->imageName($sourcePath, $probe['ext'], (string) $eggId);
        $target = $this->directory() . '/' . $name;

        if (!@copy($sourcePath, $target)) {
            throw new \RuntimeException('The banner could not be written to ' . $this->directory() . '.');
        }
        @chmod($target, 0644);

        if ($previous !== null && $previous !== $name) {
            @unlink($this->absolutePath($previous));
        }

        $this->put($eggId, $name);

        return [
            'file' => $name,
            'w' => $probe['w'],
            'h' => $probe['h'],
            'bytes' => (int) @filesize($target),
        ];
    }

    /**
     * Remove the banner and its setting. Idempotent: nothing set is a no-op
     * rather than an error, so it is safe to call on every egg deletion.
     */
    public function remove(int $eggId): bool
    {
        $had = false;

        $file = DB::table('settings')->where('key', $this->key($eggId))->value('value');
        if (is_string($file) && $file !== '' && is_file($this->absolutePath($file))) {
            @unlink($this->absolutePath($file));
            $had = true;
        }

        $deleted = DB::table('settings')->where('key', $this->key($eggId))->delete();
        if ($deleted > 0) {
            $had = true;
        }

        // Tidy up any file left behind by an older name, so a sequence of uploads
        // cannot accumulate orphans in a directory served to every visitor.
        foreach ((array) glob($this->directory() . '/' . $eggId . '-*') as $stray) {
            if (is_file($stray) && $eggId . '-' === substr(basename($stray), 0, strlen($eggId) + 1)) {
                @unlink($stray);
            }
        }

        return $had;
    }

    private function put(int $eggId, string $name): void
    {
        $key = $this->key($eggId);

        $existing = DB::table('settings')->where('key', $key)->value('id');
        if ($existing !== null) {
            DB::table('settings')->where('key', $key)->update(['value' => $name]);

            return;
        }

        DB::table('settings')->insert(['key' => $key, 'value' => $name]);
    }

    private function ensureDirectory(): void
    {
        $dir = $this->directory();

        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new \RuntimeException('Could not create ' . $dir . '. Check that public/ is writable.');
        }
    }
}

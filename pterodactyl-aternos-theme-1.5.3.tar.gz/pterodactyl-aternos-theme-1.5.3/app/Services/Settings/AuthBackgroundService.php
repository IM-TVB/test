<?php

namespace Pterodactyl\Services\Settings;

/**
 * The optional background image on the authentication pages.
 *
 * A second StoredBackground rather than a second rule on the first, because the
 * two are independent in both directions and an operator will want them to be:
 * a login screen usually wants different art from the dashboard, and resetting
 * one must not touch the other. They are also separate files, so a stale copy
 * served from a browser cache for one cannot show up as the other.
 *
 * Stored under its own directory rather than alongside the panel background,
 * because reset() deletes everything in the directory except the sidecar. Sharing
 * one directory would make the two resets remove each other's pictures.
 *
 * With nothing set, forTheme() returns a null url and the login screen keeps the
 * blue gradient the theme already draws — the auth page did not have a way to show
 * a background at all before this, because it painted an opaque page colour over
 * the body, and the aside painted a hard-coded gradient over that.
 */
class AuthBackgroundService extends StoredBackground
{
    /**
     * The same ceiling as the panel background. The login page is the first thing
     * every visitor sees, so it is not a good place to be more permissive.
     */
    public const MAX_BYTES = 8388608; // 8 MB

    public function directory(): string
    {
        return public_path('auth-backgrounds');
    }

    protected function metadataFilename(): string
    {
        return 'auth-background.json';
    }

    protected function publicPathPrefix(): string
    {
        return 'auth-backgrounds/';
    }

    protected function label(): string
    {
        return 'login background image';
    }
}

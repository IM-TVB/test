<?php

namespace Pterodactyl\Services\Settings;

use Pterodactyl\Models\User;

/**
 * A user's own profile picture.
 *
 * Modelled on LogoService: a content-hashed file in public/ plus one small record
 * of which file belongs to whom, because the name is what makes a replacement
 * reach the browser without a cache.
 *
 * The record is a settings row keyed by user uuid rather than a column on
 * `users`, for the same reason the egg banners are: it avoids a migration, and it
 * means the file and its record cannot drift apart in a way a deleted column
 * would leave behind. The cost is that nothing cascades -- which is why clear()
 * exists and is called when a user is deleted.
 *
 * A user with no picture is the normal state, and it is represented by an absent
 * row. The sidebar then draws the identicon it always drew, so this is an
 * addition to what is there rather than a replacement of it.
 */
class UserAvatarService
{
    use ProbesImageUploads;

    /**
     * Bigger than the logo's 1 MB: a profile picture is not a 34px mark, and
     * people upload a phone photo. Still bounded, because this file is served to
     * every page view by every user who can see that person.
     */
    public const MAX_BYTES = 2097152; // 2 MB

    /**
     * Smallest side accepted.
     *
     * An avatar is drawn at 34px in the sidebar but up to 96px in some lists, and
     * anything under 64 is visibly soft at the larger size. Refusing beats
     * accepting a 16px icon.
     */
    public const MIN_DIMENSION = 64;

    public function directory(): string
    {
        return public_path('avatars');
    }

    public function absolutePath(string $file): string
    {
        return $this->directory() . '/' . basename($file);
    }

    private function key(User $user): string
    {
        return 'user_avatar::' . $user->uuid;
    }

    private function storedName(User $user): ?string
    {
        $name = \Illuminate\Support\Facades\DB::table('settings')
            ->where('key', $this->key($user))
            ->value('value');

        return is_string($name) ? $name : null;
    }

    /**
     * The URL the browser should fetch, or null when the user has no picture.
     *
     * The existence check is repeated rather than trusted from the row: a file
     * can be deleted over SSH, and an <img> pointed at a 404 is a broken avatar
     * on every page rather than the identicon.
     */
    public function url(User $user): ?string
    {
        $name = $this->storedName($user);

        /*
         * The prefix pattern is the user's uuid, because that is what set() puts
         * in front of the hash. Without it the check demands a bare `hash.ext` and
         * rejects every name this class has ever written -- which came out as
         * "upload succeeded" followed by an avatar that never appeared, and a
         * clear() that deleted the record but left the file.
         */
        if (!$this->isSafeImageName($name, $user->uuid) || !is_file($this->absolutePath((string) $name))) {
            return null;
        }

        return asset('avatars/' . $name);
    }

    public function has(User $user): bool
    {
        return $this->url($user) !== null;
    }

    /**
     * Move an already-validated upload into public/ and record it for this user.
     *
     * @return array{file:string,url:string,w:int,h:int,bytes:int}
     */
    public function set(User $user, string $sourcePath): array
    {
        $probe = $this->probeImage($sourcePath, self::MAX_BYTES, 'profile picture');

        if ($probe['w'] < self::MIN_DIMENSION || $probe['h'] < self::MIN_DIMENSION) {
            throw new \RuntimeException(sprintf(
                'The picture is %dx%d. It needs to be at least %dx%d, or it is blurred in the sidebar.',
                $probe['w'],
                $probe['h'],
                self::MIN_DIMENSION,
                self::MIN_DIMENSION
            ));
        }

        $this->ensureDirectory();

        $previous = $this->storedName($user);

        // Content-addressed with the user's uuid as the prefix, so the name says
        // whose it is and re-uploading the same bytes keeps the same url.
        $name = $this->imageName($sourcePath, $probe['ext'], $user->uuid);
        $target = $this->directory() . '/' . $name;

        if (!@copy($sourcePath, $target)) {
            throw new \RuntimeException('The picture could not be written to ' . $this->directory() . '.');
        }

        @chmod($target, 0644);

        // The uuid prefix again, for the same reason as in url(): a bare
        // `hash.ext` test rejects the name this method wrote a moment ago, so the
        // superseded picture was never removed and a user who changed their
        // picture weekly kept every face they have ever had.
        if (is_string($previous) && $previous !== $name && $this->isSafeImageName($previous, $user->uuid)) {
            @unlink($this->absolutePath($previous));
        }

        \Illuminate\Support\Facades\DB::table('settings')->updateOrInsert(
            ['key' => $this->key($user)],
            ['value' => $name]
        );

        return [
            'file' => $name,
            'url' => $this->url($user),
            'w' => $probe['w'],
            'h' => $probe['h'],
            'bytes' => (int) @filesize($target),
        ];
    }

    /**
     * Remove this user's picture, so the identicon comes back. Idempotent, and
     * safe to call for a user who never had one.
     */
    public function clear(User $user): bool
    {
        $name = $this->storedName($user);
        $removed = false;

        // Same prefix as url(): a name this class wrote has to be recognised as
        // one, or the file is orphaned when the record is removed.
        if (is_string($name) && $this->isSafeImageName($name, $user->uuid)) {
            $path = $this->absolutePath($name);

            if (is_file($path) && @unlink($path)) {
                $removed = true;
            }
        }

        if (\Illuminate\Support\Facades\DB::table('settings')->where('key', $this->key($user))->delete() > 0) {
            $removed = true;
        }

        return $removed;
    }

    private function ensureDirectory(): void
    {
        $dir = $this->directory();

        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new \RuntimeException('Could not create ' . $dir . '. Check that public/ is writable.');
        }
    }
}

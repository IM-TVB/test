<?php

namespace Pterodactyl\Services\Plugins;

use Pterodactyl\Models\Setting;

/**
 * Stores the API keys of external plugin sources.
 *
 * The keys live in the panel's settings table rather than in the JavaScript
 * bundle. A key in the bundle is a key in every visitor's browser, and the panel
 * must be able to hand the key to the server-side proxy that makes the upstream
 * request, never to the client.
 *
 * The `settings` table is (key, value) with no sensitivity flag, and that is
 * acceptable here: the admin settings controllers each map an explicit allowlist
 * of keys rather than dumping the table, and no client endpoint reads it at all.
 * A client can ask *whether* a provider is configured but never *what* its key
 * is -- see availability(), which returns booleans only.
 */
class ProviderKeyService
{
    /**
     * The sources this panel knows how to talk to, and whether each needs a key.
     *
     * `hangar` and `spigot` need none. `curseforge` does, and its API is not
     * CORS-open, so it is called server-side through KeyedProviderProxy rather
     * than from the browser.
     *
     * CurseForge covers Bukkit plugins for this panel, via classId 5. A separate
     * `bukkit` source pointing at dev.bukkit.org was tried and removed: that
     * host is a CurseForge/Overwolf property -- it serves CurseForge's own
     * navigation, signs in through Twitch, and loads assets from forgecdn -- so
     * it is the same operator and the same credential wearing a second name.
     * Two fields for one key is worse than one field.
     *
     * `shape` is what a key actually looks like, shown next to the field. It is
     * documentation, not validation: the only shape actually rejected is a
     * password hash (see looksLikeAPasswordHash), which no upstream will ever
     * issue and which has already been pasted here by mistake more than once.
     */
    public const PROVIDERS = [
        'modrinth' => ['name' => 'Modrinth', 'needs_key' => false, 'hint' => null, 'shape' => null, 'url' => null],
        // 'spigot' is the user-facing source name and is what the client's
        // Provider union matches on; Spiget is only the API that serves it.
        'spigot' => ['name' => 'Spigot', 'needs_key' => false, 'hint' => null, 'shape' => null, 'url' => null],
        'hangar' => ['name' => 'Hangar', 'needs_key' => false, 'hint' => null, 'shape' => null, 'url' => null],
        'curseforge' => [
            'name' => 'CurseForge',
            'needs_key' => true,
            // The read API is api.curseforge.com/v1 and authenticates with
            // x-api-key. CurseForge also runs a separate Upload API on another
            // host that uses X-Api-Token; a token from that one is refused here.
            //
            // The key is generated in the CurseForge for Studios console. The
            // old www.curseforge.com/account/api-proxies page no longer exists
            // (it 404s for a signed-in user), so pointing operators at it sent
            // them to a dead end.
            'hint' => 'Needs a CurseForge API key, generated in the CurseForge for Studios console. The same key covers CurseForge content and Bukkit plugins, which CurseForge also hosts.',
            'shape' => 'generated in the Studios console',
            'url' => 'https://console.curseforge.com/',
        ],
    ];

    /**
     * True for a password hash -- bcrypt or argon2 -- which is what a panel
     * password looks like and what was pasted into this field by mistake.
     *
     * Rejecting these is deliberately narrow. Refusing anything that is not the
     * documented shape would break the day an upstream changes its key format;
     * refusing only a password hash cannot, because no API issues one. It exists
     * because a bcrypt hash was pasted here and the only feedback was an
     * upstream 403, which reads like a panel fault rather than a wrong paste.
     */
    public static function looksLikeAPasswordHash(string $value): bool
    {
        // bcrypt: $2[abxy]$<cost>$<22-char salt><31-char hash> = 60 chars.
        // argon2: $argon2id$v=19$... The 53 after the third '$' is what makes the
        // bcrypt pattern exact rather than merely "starts with $2".
        return (bool) preg_match('/^\$(2[abxy]\$\d{2}\$[.\/A-Za-z0-9]{53}|argon2(id|i|d)\$)/', $value);
    }


    private const PREFIX = 'plugins::provider_key::';

    /**
     * When a stored key was last refused by the provider.
     *
     * Storing a key is not the same as having a working one, and the difference
     * matters because the browser hides any source it is told is unconfigured.
     * Reporting on the mere presence of a key meant a key the provider had
     * already rejected left the source on screen, where every single search then
     * failed with an error the visitor could do nothing about -- the exact state
     * the comment on availability() says to avoid.
     *
     * A timestamp rather than a boolean, so an operator looking at the settings
     * page can tell a key refused an hour ago from one refused last week, and so
     * a stale marker is recognisable as stale.
     */
    private const REJECTED_PREFIX = 'plugins::provider_key_refused::';

    public function key(string $provider): ?string
    {
        $value = Setting::query()->where('key', $this->prefixed($provider))->value('value');

        return is_string($value) && $value !== '' ? $value : null;
    }

    public function set(string $provider, ?string $key): void
    {
        if (!array_key_exists($provider, self::PROVIDERS)) {
            throw new \InvalidArgumentException(sprintf('Unknown provider "%s".', $provider));
        }

        if (!self::PROVIDERS[$provider]['needs_key'] && $key !== null) {
            throw new \InvalidArgumentException(sprintf('The "%s" provider does not take a key.', $provider));
        }

        // Trimmed here as well as in the controller. The controller is the only
        // current caller, so this is belt and braces -- but a key is pasted from
        // a console, and a trailing newline is the single most likely way for one
        // to be rejected for no visible reason. Worth not depending on every
        // future caller remembering.
        $key = $key === null ? null : trim($key);

        // An empty result means there is no key, not a key that happens to be
        // blank. The settings model validates `value` as a string, so storing
        // null here would fail validation rather than quietly clearing the row --
        // and a caller passing whitespace would get an exception instead of the
        // "nothing to save" outcome it means.
        if ($key === '') {
            $this->forget($provider);

            return;
        }

        Setting::query()->updateOrCreate(
            ['key' => $this->prefixed($provider)],
            ['value' => $key]
        );

        // A new key has not been tried yet, so the previous verdict says nothing
        // about it. Leaving the marker would hide a source that may now work.
        $this->markAccepted($provider);
    }

    public function forget(string $provider): void
    {
        Setting::query()->where('key', $this->prefixed($provider))->delete();
        $this->markAccepted($provider);
    }

    /**
     * Record that the provider refused the stored key.
     *
     * Called only for an authentication verdict. A timeout or a 500 says nothing
     * about the key, and hiding the source for those would be wrong.
     */
    public function markRefused(string $provider, ?int $at = null): void
    {
        if (!array_key_exists($provider, self::PROVIDERS)) {
            return;
        }

        Setting::query()->updateOrCreate(
            ['key' => self::REJECTED_PREFIX . $provider],
            ['value' => (string) ($at ?? time())]
        );
    }

    /**
     * Clear a refusal: the key works, or there is no key to be refused.
     */
    public function markAccepted(string $provider): void
    {
        Setting::query()->where('key', self::REJECTED_PREFIX . $provider)->delete();
    }

    /**
     * When the stored key was refused, or null if it never was.
     */
    public function refusedAt(string $provider): ?int
    {
        $value = Setting::query()->where('key', self::REJECTED_PREFIX . $provider)->value('value');

        return is_numeric($value) ? (int) $value : null;
    }

    /**
     * Whether a key is stored *and* the provider has accepted it.
     */
    public function isUsable(string $provider): bool
    {
        $meta = self::PROVIDERS[$provider] ?? null;

        if ($meta === null || !array_key_exists($provider, self::PROVIDERS)) {
            return false;
        }

        if (!$meta['needs_key']) {
            return true;
        }

        return $this->key($provider) !== null && $this->refusedAt($provider) === null;
    }

    /**
     * What the client is allowed to know: which sources exist and which are
     * usable right now. The key value itself is never included.
     *
     * @return array<int, array{id: string, name: string, configured: bool, hint: ?string, refused: bool}>
     */
    public function availability(): array
    {
        return collect(self::PROVIDERS)
            ->map(function (array $meta, string $id) {
                $hasKey = $this->key($id) !== null;
                $refused = $hasKey && $this->refusedAt($id) !== null;

                return [
                    'id' => $id,
                    'name' => $meta['name'],
                    // A source the browser cannot actually use is reported as
                    // unavailable, so the browser hides it. That covers both "no
                    // key" and "the key was refused" -- a chip whose every request
                    // fails is worse than no chip, because the visitor sees a
                    // source they cannot reach and an error they cannot act on.
                    'configured' => $meta['needs_key'] ? ($hasKey && !$refused) : true,
                    'refused' => $refused,
                    'hint' => match (true) {
                        // User-facing, so it must not leak the key or the admin's
                        // mistake beyond what is needed to explain the absence.
                        $refused => 'temporarily unavailable: the API key saved for it was refused by the provider.',
                        $meta['needs_key'] && !$hasKey => $meta['hint'],
                        default => null,
                    },
                ];
            })
            ->values()
            ->all();
    }

    private function prefixed(string $provider): string
    {
        return self::PREFIX . $provider;
    }
}

<?php

namespace Pterodactyl\Http\Controllers\Admin\Nests;

use Illuminate\Http\Request;
use Illuminate\View\View;
use Pterodactyl\Models\Egg;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Eggs\EggUpdateService;
use Pterodactyl\Services\Eggs\EggCreationService;
use Pterodactyl\Services\Eggs\EggDeletionService;
use Pterodactyl\Http\Requests\Admin\Egg\EggFormRequest;
use Pterodactyl\Contracts\Repository\EggRepositoryInterface;
use Pterodactyl\Contracts\Repository\NestRepositoryInterface;
use Pterodactyl\Services\Settings\EggBannerService;

class EggController extends Controller
{
    /**
     * EggController constructor.
     */
    public function __construct(
        protected AlertsMessageBag $alert,
        protected EggCreationService $creationService,
        protected EggDeletionService $deletionService,
        protected EggRepositoryInterface $repository,
        protected EggBannerService $banners,
        protected EggUpdateService $updateService,
        protected NestRepositoryInterface $nestRepository,
        protected ViewFactory $view,
    ) {
    }

    /**
     * Handle a request to display the Egg creation page.
     *
     * @throws \Pterodactyl\Exceptions\Repository\RecordNotFoundException
     */
    public function create(): View
    {
        $nests = $this->nestRepository->getWithEggs();
        \JavaScript::put(['nests' => $nests->keyBy('id')]);

        return view('admin.eggs.new', ['nests' => $nests]);
    }

    /**
     * Handle request to store a new Egg.
     *
     * @throws \Pterodactyl\Exceptions\Model\DataValidationException
     * @throws \Pterodactyl\Exceptions\Service\Egg\NoParentConfigurationFoundException
     */
    public function store(EggFormRequest $request): RedirectResponse
    {
        $data = $request->validated();
        $data['docker_images'] = $this->normalizeDockerImages($data['docker_images'] ?? null);

        $egg = $this->creationService->handle($data);
        $this->alert->success(trans('admin/nests.eggs.notices.egg_created'))->flash();

        return redirect()->route('admin.nests.egg.view', $egg->id);
    }

    /**
     * Handle request to view a single Egg.
     */
    public function view(Egg $egg): View
    {
        return view('admin.eggs.view', [
            'egg' => $egg,
            'banner' => $this->banners->file($egg->id),
            'bannerUrl' => $this->banners->url($egg->id),
            'images' => array_map(
                fn ($key, $value) => $key === $value ? $value : "$key|$value",
                array_keys($egg->docker_images),
                $egg->docker_images,
            ),
        ]);
    }

    /**
     * Handle request to update an Egg.
     *
     * @throws \Pterodactyl\Exceptions\Model\DataValidationException
     * @throws \Pterodactyl\Exceptions\Repository\RecordNotFoundException
     * @throws \Pterodactyl\Exceptions\Service\Egg\NoParentConfigurationFoundException
     */
    public function update(EggFormRequest $request, Egg $egg): RedirectResponse
    {
        $data = $request->validated();
        $data['docker_images'] = $this->normalizeDockerImages($data['docker_images'] ?? null);

        $this->updateService->handle($egg, $data);
        $this->alert->success(trans('admin/nests.eggs.notices.updated'))->flash();

        return redirect()->route('admin.nests.egg.view', $egg->id);
    }

    /**
     * Handle request to destroy an egg.
     *
     * @throws \Pterodactyl\Exceptions\Service\Egg\HasChildrenException
     * @throws \Pterodactyl\Exceptions\Service\HasActiveServersException
     */
    /**
     * Upload or replace the server card banner for this egg.
     *
     * A separate route from update() because that form is not multipart: a file
     * input added to it would look right and silently upload nothing, which is
     * the same failure the branding form had before it was given enctype.
     */
    public function bannerUpdate(Request $request, Egg $egg): RedirectResponse
    {
        $request->validate([
            'banner' => ['required', 'file', 'mimes:png,jpg,jpeg,gif,webp', 'max:' . EggBannerService::MAX_BYTES],
        ], [
            'banner.mimes' => 'The banner must be a PNG, JPEG, GIF or WebP. SVG is not supported — it can carry script, and this file is served to every visitor.',
            'banner.max' => 'The banner must be smaller than 2 MB. It is fetched once per server card on the dashboard.',
        ]);

        $file = $request->file('banner');
        $file->store('banner-staging', 'local');
        $staged = \Illuminate\Support\Facades\Storage::disk('local')
            ->path('banner-staging/' . $file->hashName());

        try {
            $result = $this->banners->set($egg->id, $staged);

            $this->alert->success(sprintf(
                'Banner updated — %dx%d, %.1f KB. Servers on this egg will show it.',
                $result['w'],
                $result['h'],
                $result['bytes'] / 1024,
            ))->flash();
        } catch (\Throwable $e) {
            report($e);
            $this->alert->danger('Could not set the banner: ' . $e->getMessage())->flash();
        } finally {
            @unlink($staged);
        }

        return redirect()->route('admin.nests.egg.view', $egg->id);
    }

    /**
     * Remove the banner, putting the card back to its generated gradient.
     */
    public function bannerRemove(Egg $egg): RedirectResponse
    {
        if ($this->banners->remove($egg->id)) {
            $this->alert->success('Banner removed. Servers on this egg will use the default card.')->flash();
        } else {
            $this->alert->danger('No banner was set for this egg, so nothing was changed.')->flash();
        }

        return redirect()->route('admin.nests.egg.view', $egg->id);
    }

    public function destroy(Egg $egg): RedirectResponse
    {
        // Before the deletion, while the id still resolves: the setting row and
        // the file are keyed by egg id, and nothing else would clean them up.
        $this->banners->remove($egg->id);

        $this->deletionService->handle($egg->id);
        $this->alert->success(trans('admin/nests.eggs.notices.deleted'))->flash();

        return redirect()->route('admin.nests.view', $egg->nest_id);
    }

    /**
     * Normalizes a string of docker image data into the expected egg format.
     */
    protected function normalizeDockerImages(?string $input = null): array
    {
        $data = array_map(fn ($value) => trim($value), explode("\n", $input ?? ''));

        $images = [];
        // Iterate over the image data provided and convert it into a name => image
        // pairing that is used to improve the display on the front-end.
        foreach ($data as $value) {
            $parts = explode('|', $value, 2);
            $images[$parts[0]] = empty($parts[1]) ? $parts[0] : $parts[1];
        }

        return $images;
    }
}

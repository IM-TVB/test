<?php

namespace Pterodactyl\Http\Controllers\Admin\Settings;

use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Settings\UpdateLogoRequest;
use Pterodactyl\Services\Settings\LogoService;
use Throwable;

/**
 * The sidebar logo, set from Admin -> Settings -> Branding.
 *
 * Separate routes from /branding rather than extra fields on it, for the reason
 * the background has its own: clearing the icon must never be able to clear the
 * favicon set or the background, and the two reset buttons stay independent.
 */
class LogoController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private LogoService $logo,
    ) {
    }

    public function index(): View
    {
        return view('admin.settings.logo', [
            'url' => $this->logo->url(),
            'hasImage' => $this->logo->hasImage(),
            'maxBytes' => LogoService::MAX_BYTES,
            'minDimension' => LogoService::MIN_DIMENSION,
            // The letter the sidebar falls back to, computed here rather than
            // in the template: it is the same derivation the navigation makes,
            // and two copies of it would eventually disagree.
            'initial' => strtoupper(mb_substr(trim((string) (config('app.name') ?? 'Panel')), 0, 1)),
        ]);
    }

    public function update(UpdateLogoRequest $request): RedirectResponse
    {
        $file = $request->file('image');

        if ($file === null) {
            $this->alert->warning('No image was uploaded, so nothing was changed.')->flash();

            return redirect()->route('admin.settings.logo');
        }

        // Staged outside public/ and only promoted once it has been probed, so a
        // rejected file never sits in a web-reachable directory.
        $file->store('logo-staging', 'local');
        $staged = \Illuminate\Support\Facades\Storage::disk('local')
            ->path('logo-staging/' . $file->hashName());

        try {
            $result = $this->logo->set($staged);

            $this->alert->success(sprintf(
                'Logo updated — %dx%d, %s, %.1f KB.',
                $result['w'],
                $result['h'],
                strtoupper(pathinfo($result['file'], PATHINFO_EXTENSION)),
                $result['bytes'] / 1024,
            ))->flash();
        } catch (Throwable $e) {
            report($e);
            $this->alert->danger('Could not set the logo: ' . $e->getMessage())->flash();
        } finally {
            @unlink($staged);
        }

        return redirect()->route('admin.settings.logo');
    }

    public function reset(): RedirectResponse
    {
        if ($this->logo->reset()) {
            $this->alert->success('The default logo has been restored.')->flash();
        } else {
            $this->alert->danger('No stored logo was found, so nothing was changed.')->flash();
        }

        return redirect()->route('admin.settings.logo');
    }
}

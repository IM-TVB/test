<?php

namespace Pterodactyl\Http\Controllers\Admin\Settings;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Support\Facades\Storage;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Settings\UpdateBrandingRequest;
use Pterodactyl\Services\Settings\FaviconService;
use Throwable;

class BrandingController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private FaviconService $icons,
    ) {
    }

    public function index(): View
    {
        return view('admin.settings.branding', [
            'color' => $this->icons->color(),
            'name' => $this->icons->metadata()['name'] ?? config('app.name'),
            'canReset' => $this->icons->hasStockSnapshot(),
            'updatedAt' => $this->icons->metadata()['updatedAt'] ?? null,
        ]);
    }

    public function update(UpdateBrandingRequest $request): RedirectResponse
    {
        $color = $this->icons->setColor((string) $request->input('color'));
        $name = trim((string) $request->input('name', '')) ?: null;

        $file = $request->file('icon');

        if ($file !== null) {
            // $file->store() keeps the upload out of the web root. The path it
            // returns is relative to the DISK root, which is not storage_path('app')
            // on Laravel 11+ (it is storage/app/private), so the disk must resolve it.
            $path = $file->store('branding', 'local');
            $absolute = Storage::disk('local')->path($path);

            try {
                $result = $this->icons->regenerate(
                    $absolute,
                    $color,
                    $name,
                    $request->boolean('crop'),
                );

                $this->alert->success(sprintf(
                    'Panel icon updated — %d files generated (%.1f KB). Browsers may need the tab reopened to show it.',
                    $result['files'],
                    $result['bytes'] / 1024,
                ))->flash();
            } catch (Throwable $e) {
                report($e);
                $this->alert->danger('Could not generate the icon: ' . $e->getMessage())->flash();
            } finally {
                Storage::disk('local')->delete($path);
            }
        } else {
            $this->alert->success('Branding colour updated.')->flash();
        }

        return redirect()->route('admin.settings.branding');
    }

    public function reset(Request $request): RedirectResponse
    {
        $request->validate([
            'confirm' => 'required|accepted',
        ], [
            'confirm.accepted' => 'You must confirm before restoring the default icon.',
        ]);

        if ($this->icons->reset()) {
            $this->alert->success('The default panel icon has been restored.')->flash();
        } else {
            $this->alert->danger('No stored copy of the default icon was found, so nothing was changed.')->flash();
        }

        return redirect()->route('admin.settings.branding');
    }
}

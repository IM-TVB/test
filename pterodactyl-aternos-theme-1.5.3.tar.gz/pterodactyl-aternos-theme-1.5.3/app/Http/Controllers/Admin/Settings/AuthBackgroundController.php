<?php

namespace Pterodactyl\Http\Controllers\Admin\Settings;

use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Settings\UpdateAuthBackgroundRequest;
use Pterodactyl\Services\Settings\AuthBackgroundService;
use Illuminate\Support\Facades\Storage;
use Throwable;

/**
 * The login page's background image.
 *
 * Its own controller rather than two more methods on BackgroundController, for
 * the same reason the logo and the background have their own: each has an upload,
 * a tune and a reset, and folding two of each into one class makes every route
 * and every flash message ambiguous about which image it means. Both forms post
 * to this one screen, so nothing is lost by the split.
 */
class AuthBackgroundController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private AuthBackgroundService $background,
    ) {
    }

    public function update(UpdateAuthBackgroundRequest $request): RedirectResponse
    {
        $file = $request->file('image');

        // Staged outside public/ and only promoted once it has been probed, so a
        // rejected file never sits in a web-reachable directory.
        if ($file !== null) {
            $file->store('auth-background-staging', 'local');
            $staged = Storage::disk('local')->path('auth-background-staging/' . $file->hashName());

            try {
                $result = $this->background->set(
                    $staged,
                    $request->filled('dim') ? (float) $request->input('dim') : null,
                    $request->filled('fit') ? (string) $request->input('fit') : null,
                );

                $this->alert->success(sprintf(
                    'Login background updated — %dx%d, %s, %.1f KB.',
                    $result['w'],
                    $result['h'],
                    strtoupper(pathinfo($result['file'], PATHINFO_EXTENSION)),
                    $result['bytes'] / 1024,
                ))->flash();
            } catch (Throwable $e) {
                report($e);
                $this->alert->danger('Could not set the login background: ' . $e->getMessage())->flash();
            } finally {
                @unlink($staged);
            }
        } elseif ($this->background->hasImage()) {
            // No new file, but dim/fit may have been changed. Tuning without an
            // upload is a separate path so it cannot silently no-op.
            try {
                $this->background->tune(
                    $request->filled('dim') ? (float) $request->input('dim') : null,
                    $request->filled('fit') ? (string) $request->input('fit') : null,
                );

                $this->alert->success('Login background appearance updated.')->flash();
            } catch (Throwable $e) {
                report($e);
                $this->alert->danger('Could not update the login background: ' . $e->getMessage())->flash();
            }
        } else {
            $this->alert->warning('No image was uploaded, and there is no login background set to adjust.')->flash();
        }

        return redirect()->route('admin.settings.background');
    }

    /**
     * Removes only the login background.
     *
     * The panel background lives in a different directory, so this cannot reach
     * it — which is the point of the split, and is asserted rather than assumed
     * in the test suite.
     */
    public function reset(): RedirectResponse
    {
        if ($this->background->reset()) {
            $this->alert->success('The login page has its original background back.')->flash();
        } else {
            $this->alert->danger('No stored login background was found, so nothing was changed.')->flash();
        }

        return redirect()->route('admin.settings.background');
    }
}

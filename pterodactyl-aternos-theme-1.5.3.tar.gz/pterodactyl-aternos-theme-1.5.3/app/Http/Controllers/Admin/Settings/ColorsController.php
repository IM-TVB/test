<?php

namespace Pterodactyl\Http\Controllers\Admin\Settings;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Settings\ThemeColorService;
use Throwable;

class ColorsController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private ThemeColorService $colors,
    ) {
    }

    public function index(): View
    {
        return view('admin.settings.colors', [
            'values' => $this->colors->values(),
            'customised' => $this->colors->customised(),
            'custom' => $this->colors->hasCustom(),
            'defaults' => ThemeColorService::DEFAULTS,
            'fields' => ThemeColorService::FIELDS,
            'footerText' => $this->colors->footerText(),
            'updatedAt' => $this->colors->metadata()['updatedAt'] ?? null,
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        $hexRule = ['nullable', 'regex:/^#?[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/'];

        $request->validate(
            array_fill_keys(ThemeColorService::FIELDS, $hexRule),
            array_fill_keys(
                ThemeColorService::FIELDS,
                'The colour must be a hex value like #007bff or #07f.',
            ),
        );

        $request->validate([
            'footer_text' => ['nullable', 'string', 'max:200'],
        ]);

        $fields = [];
        foreach (ThemeColorService::FIELDS as $field) {
            // The checkbox decides whether this field is customised at all.
            // Unticked means "fall back to the stock value", which is how one
            // field is reset without touching the others.
            if ($request->boolean('custom_' . $field)) {
                $fields[$field] = $request->input($field);
            }
        }

        try {
            $stored = $this->colors->set($fields);
            $this->colors->setFooterText($request->input('footer_text'));
            $this->alert->success(
                $stored === []
                    ? 'All colours reset to the defaults.'
                    : 'Colours updated (' . count($stored) . ' customised).'
            )->flash();
        } catch (Throwable $e) {
            report($e);
            $this->alert->danger('Could not save the colours: ' . $e->getMessage())->flash();
        }

        return redirect()->route('admin.settings.colors');
    }

    public function reset(Request $request): RedirectResponse
    {
        $request->validate([
            'confirm' => 'required|accepted',
        ], [
            'confirm.accepted' => 'You must confirm before restoring the default colours.',
        ]);

        if ($this->colors->reset()) {
            $this->alert->success('Every customised colour has been restored to the default.')->flash();
        } else {
            $this->alert->danger('No custom colours were set, so nothing was changed.')->flash();
        }

        return redirect()->route('admin.settings.colors');
    }

    public function resetField(Request $request): RedirectResponse
    {
        $request->validate([
            'field' => ['required', 'string', 'in:' . implode(',', ThemeColorService::FIELDS)],
        ]);

        try {
            if ($this->colors->resetField((string) $request->input('field'))) {
                $this->alert->success($request->input('field') . ' colour restored to the default.')->flash();
            } else {
                $this->alert->info($request->input('field') . ' is not customised, so nothing changed.')->flash();
            }
        } catch (Throwable $e) {
            report($e);
            $this->alert->danger('Could not reset: ' . $e->getMessage())->flash();
        }

        return redirect()->route('admin.settings.colors');
    }
}

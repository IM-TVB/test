<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Services\Plugins\PublicProviderProxy;

/**
 * The second download route, for the sources that need no API key.
 *
 * These three are downloaded by the browser directly whenever it can, which is
 * the normal path and the faster one. This exists for when it cannot: a browser
 * that blocks the request, a network that refuses the CDN, an extension that
 * intercepts it. The panel makes the same request server-side, where none of that
 * applies, and streams the bytes back.
 *
 * The browser sends identifiers only -- never a URL. See PublicProviderProxy for
 * why that distinction is the whole security model here.
 */
class PublicProviderController extends ClientApiController
{
    public function __construct(
        private PublicProviderProxy $proxy,
    ) {
    }

    /**
     * Stream a jar back to the browser.
     *
     * The digest travels with the bytes rather than being looked up separately,
     * for the same reason as the keyed path: the client checks it before
     * uploading to Wings, and a second round trip to re-derive it would be a
     * chance for the two to disagree.
     *
     * @return Response
     */
    public function download(Request $request, string $provider)
    {
        $file = $this->proxy->download($provider, $request->query());

        $headers = [
            'Content-Type' => 'application/java-archive',
            'Content-Length' => (string) $file['size'],
            'Content-Disposition' => sprintf('attachment; filename="%s"', $this->safeFilename($file['filename'])),
            'X-Jar-Sha1' => (string) $file['sha1'],
            'X-Jar-Sha256' => (string) $file['sha256'],
            'X-Jar-Size' => (string) $file['size'],
        ];

        return response($file['body'], 200, $headers);
    }

    /**
     * A Content-Disposition filename is attacker-influenced text in an HTTP
     * header, even when it arrived via our own metadata request. Strip anything
     * that could break out of the quoted string.
     */
    private function safeFilename(string $name): string
    {
        $name = basename($name);
        $name = preg_replace('/[^A-Za-z0-9._+-]/', '_', $name) ?? 'plugin.jar';
        $name = ltrim($name, '.-');

        if ($name === '' || !str_ends_with(strtolower($name), '.jar')) {
            $name .= str_ends_with(strtolower($name), '.jar') ? '' : '.jar';
        }

        return $name;
    }
}

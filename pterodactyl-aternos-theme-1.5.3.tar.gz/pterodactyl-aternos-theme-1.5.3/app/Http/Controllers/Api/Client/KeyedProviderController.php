<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Services\Plugins\KeyedProviderProxy;
use Pterodactyl\Services\Plugins\ProviderKeyService;

/**
 * Client-facing access to the plugin sources that need an API key.
 *
 * The browser holds no credential for these. It asks here, the panel attaches
 * the key and calls the upstream API, and only the normalised results come back.
 */
class KeyedProviderController extends ClientApiController
{
    public function __construct(
        private ProviderKeyService $keys,
        private KeyedProviderProxy $proxy,
    ) {
    }

    public function index(Request $request): JsonResponse
    {
        return new JsonResponse($this->keys->availability());
    }

    public function search(Request $request, string $provider): JsonResponse
    {
        $result = $this->proxy->search($provider, $this->queryFor($request));

        return new JsonResponse([
            'provider' => $provider,
            'hits' => $this->normalise($result['body']),
            'total' => $this->totalOf($result['body']),
        ]);
    }

    /**
     * Detail for one project, used for its description and download URL.
     */
    public function detail(Request $request, string $provider, string $path): JsonResponse
    {
        $result = $this->proxy->detail($provider, $path, $this->queryFor($request));

        return new JsonResponse([
            'provider' => $provider,
            'body' => $result['body'],
        ]);
    }

    /**
     * Stream a jar back to the browser.
     *
     * The bytes come through the panel rather than straight from the CDN because
     * CurseForge requires the key on CDN downloads, and a browser request cannot
     * carry a key the panel is deliberately keeping secret. The panel verifies
     * CurseForge's published checksums before a single byte reaches the client,
     * so what the browser receives has already been checked.
     *
     * @return Response
     */
    public function download(Request $request, string $provider, string $path)
    {
        $file = $this->proxy->download($provider, $path);

        $headers = [
            'Content-Type' => 'application/java-archive',
            'Content-Length' => (string) $file['size'],
            'Content-Disposition' => sprintf('attachment; filename="%s"', $this->safeFilename($file['filename'])),
            // The client checks these itself before uploading to Wings, so they
            // have to travel with the bytes rather than being fetched separately.
            'X-Jar-Sha1' => (string) $file['sha1'],
            'X-Jar-Md5' => (string) $file['md5'],
            'X-Jar-Size' => (string) $file['size'],
        ];

        return response($file['body'], 200, $headers);
    }

    /**
     * A Content-Disposition filename is attacker-influenced text in an HTTP
     * header. Strip anything that could break out of the quoted string.
     */
    private function safeFilename(string $name): string
    {
        $name = basename($name);
        $name = preg_replace('/[^A-Za-z0-9._-]/', '_', $name) ?? 'plugin.jar';

        return $name === '' ? 'plugin.jar' : $name;
    }

    /**
     * Pass the client's search parameters through untouched.
     *
     * Renaming them to the upstream's own vocabulary is KeyedProviderProxy's
     * job, so that the admin settings page gets the same translation when it
     * calls the proxy directly to test a key.
     */
    private function queryFor(Request $request): array
    {
        return $request->only(['query', 'index', 'size', 'gameVersion']);
    }

    /**
     * Flatten CurseForge's response into the fields the card grid needs, so the
     * client does not have to know which API a row came from.
     */
    private function normalise(array $body): array
    {
        $rows = $body['data'] ?? [];

        if (!is_array($rows)) {
            return [];
        }

        return array_values(array_map(fn ($row) => $this->normaliseRow($row), $rows));
    }

    private function normaliseRow(array $row): array
    {
        $file = $row['latestFiles'][0] ?? [];

        return [
            'id' => (int) ($row['id'] ?? 0),
            'slug' => $row['slug'] ?? null,
            'name' => $row['name'] ?? 'Unknown',
            'description' => strip_tags((string) ($row['summary'] ?? '')),
            'downloads' => (int) ($row['downloadCount'] ?? 0),
            'icon_url' => $row['logo']['url'] ?? $row['thumbnailUrl'] ?? null,
            'file_id' => isset($file['id']) ? (int) $file['id'] : null,
            'file_name' => $file['fileName'] ?? null,
            'latest_version' => $file['displayName'] ?? null,
            'game_versions' => array_values($file['gameVersions'] ?? []),
            'authors' => array_values(array_map(
                fn ($a) => is_array($a) ? ($a['name'] ?? null) : null,
                $row['authors'] ?? []
            )),
        ];
    }

    private function totalOf(array $body): int
    {
        $pagination = $body['pagination'] ?? null;

        if (is_array($pagination)) {
            return (int) ($pagination['resultCount'] ?? $pagination['totalCount'] ?? 0);
        }

        $rows = $body['data'] ?? [];

        return is_array($rows) ? count($rows) : 0;
    }
}

<?php

namespace Pterodactyl\Http\Requests\Admin\Plugins;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Pterodactyl\Models\User;
use Pterodactyl\Services\Plugins\ProviderKeyService;

/**
 * Validation for saving a plugin source's API key from the admin settings page.
 */
class UpdateProviderKeyRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null && $this->user()->root_admin;
    }

    public function rules(): array
    {
        return [
            'provider' => ['required', 'string', Rule::in(array_keys(ProviderKeyService::PROVIDERS))],
            // A key is a credential: it is never rendered back into the form, so
            // an empty value means "leave whatever is stored alone" rather than
            // "clear it". Clearing is an explicit action.
            'key' => ['nullable', 'string', 'max:255'],
        ];
    }

    public function messages(): array
    {
        return [
            'provider.in' => 'That plugin source does not exist.',
            'key.not_a_stored_password_hash' => 'That is a password hash from this panel\'s user accounts, not an API key. Copy the key itself from the provider\'s API page.',
        ];
    }

    public function attributes(): array
    {
        return ['key' => 'API key'];
    }

    /**
     * Refuse a password hash copied out of this panel's own users table.
     *
     * This used to reject anything bcrypt-shaped on the grounds that "a password
     * hash is never a valid API key from any provider". That was wrong, and
     * badly so: CurseForge issues keys that *are* bcrypt-shaped -- a `$2a$10$`
     * prefix followed by 53 base64 characters -- which is documented behaviour
     * that has bitten a lot of people, mostly because unquoted shell and .env
     * files eat the `$` runs and silently store a truncated key. Shape-based
     * rejection therefore could not tell a CurseForge key from a password hash,
     * because they are the same shape, so it refused every legitimate key while
     * providing none of the protection it claimed.
     *
     * What replaces it is a question with an answer rather than a guess: does
     * this value match a password hash this panel actually stores? That is
     * unambiguous, and it cannot refuse a real key no matter what format a
     * provider chooses. Providers are free to change their key format without
     * breaking this, which the shape check could not promise.
     *
     * The live "Save & test" round trip remains the real check on a key's
     * validity, and it now records a refusal with an actionable message rather
     * than failing silently later.
     */
    public function withValidator($validator): void
    {
        $validator->after(function ($validator): void {
            $key = trim((string) $this->input('key', ''));

            if ($key !== '' && $this->isAStoredPasswordHash($key)) {
                $validator->errors()->add('key', $this->messages()['key.not_a_stored_password_hash']);
            }
        });
    }

    /**
     * Whether this value is a password hash from one of this panel's accounts.
     *
     * A real comparison against stored hashes, not a shape guess, so it cannot
     * refuse a legitimate key whatever format a provider picks. Scoped by a cheap
     * prefix and length check first so the query only runs for something that
     * could plausibly be a hash at all.
     *
     * This asks the users table rather than a regex on purpose. It is not a hash
     * oracle in any sense that matters: the route is root-admin only, and anyone
     * able to reach it can already read every hash in that column.
     */
    private function isAStoredPasswordHash(string $value): bool
    {
        if (!str_starts_with($value, '$2') || strlen($value) !== 60) {
            return false;
        }

        return User::query()->where('password', $value)->exists();
    }
}

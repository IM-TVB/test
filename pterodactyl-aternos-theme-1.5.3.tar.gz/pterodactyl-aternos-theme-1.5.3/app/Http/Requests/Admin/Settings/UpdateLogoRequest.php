<?php

namespace Pterodactyl\Http\Requests\Admin\Settings;

use Pterodactyl\Http\Requests\Admin\AdminFormRequest;
use Pterodactyl\Services\Settings\LogoService;

class UpdateLogoRequest extends AdminFormRequest
{
    public function rules(): array
    {
        return [
            // The mimes rule is a convenience, not the gate: LogoService probes
            // the real image type with getimagesize() before anything is written.
            // webp is included so the browser-side accept filter and this rule
            // agree. SVG is refused for the same reason as the background's: it
            // can carry script.
            'image' => ['nullable', 'file', 'mimes:png,jpg,jpeg,gif,webp', 'max:' . LogoService::MAX_BYTES],
        ];
    }

    public function messages(): array
    {
        return [
            'image.mimes' => 'The logo must be a PNG, JPEG, GIF or WebP. SVG is not supported — it can carry script.',
            'image.max' => 'The logo must be smaller than 1 MB. It is downloaded on every page of every request.',
        ];
    }

    public function attributes(): array
    {
        return [
            'image' => 'logo',
        ];
    }
}

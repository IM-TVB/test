<?php

namespace Pterodactyl\Http\Requests\Admin\Settings;

use Pterodactyl\Http\Requests\Admin\AdminFormRequest;
use Pterodactyl\Services\Settings\BackgroundService;

class UpdateBackgroundRequest extends AdminFormRequest
{
    public function rules(): array
    {
        return [
            // The mimes rule is a convenience, not the gate: BackgroundService
            // probes the real image type with getimagesize() before anything is
            // written. webp is included here so the browser-side accept filter
            // and this rule agree.
            'image' => ['nullable', 'file', 'mimes:png,jpg,jpeg,gif,webp', 'max:' . BackgroundService::MAX_BYTES],
            'dim' => ['nullable', 'numeric', 'min:' . BackgroundService::MIN_DIM, 'max:' . BackgroundService::MAX_DIM],
            'fit' => ['nullable', 'string', 'in:' . implode(',', BackgroundService::FITS)],
        ];
    }

    public function messages(): array
    {
        return [
            'image.mimes' => 'The background must be a PNG, JPEG, GIF or WebP. SVG is not supported — it can carry script, and this file is served to every visitor.',
            'image.max' => 'The background image must be smaller than 8 MB. It is downloaded on every page view.',
            'fit.in' => 'How the image should fill the background must be cover, contain or tile.',
            'dim.min' => 'The dim amount cannot be less than 0.',
            'dim.max' => 'The dim amount cannot be more than 0.95 — at 1 the image would be completely hidden.',
        ];
    }

    public function attributes(): array
    {
        return [
            'image' => 'background image',
            'dim' => 'dim amount',
            'fit' => 'fill mode',
        ];
    }
}

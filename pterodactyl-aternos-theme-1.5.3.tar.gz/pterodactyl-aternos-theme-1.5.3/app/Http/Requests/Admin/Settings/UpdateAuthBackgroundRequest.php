<?php

namespace Pterodactyl\Http\Requests\Admin\Settings;

use Pterodactyl\Http\Requests\Admin\AdminFormRequest;
use Pterodactyl\Services\Settings\AuthBackgroundService;

class UpdateAuthBackgroundRequest extends AdminFormRequest
{
    public function rules(): array
    {
        return [
            // The mimes rule is a convenience, not the gate: AuthBackgroundService
            // probes the real image type with getimagesize() before anything is
            // written. webp is included here so the browser-side accept filter
            // and this rule agree.
            'image' => ['nullable', 'file', 'mimes:png,jpg,jpeg,gif,webp', 'max:' . AuthBackgroundService::MAX_BYTES],
            'dim' => ['nullable', 'numeric', 'min:' . AuthBackgroundService::MIN_DIM, 'max:' . AuthBackgroundService::MAX_DIM],
            'fit' => ['nullable', 'string', 'in:' . implode(',', AuthBackgroundService::FITS)],
        ];
    }

    /**
     * Deliberately worded as "login background" rather than reusing the panel
     * background's messages.
     *
     * Both images are set from the same screen, so an error that said only
     * "background" would leave an operator with two uploads and one message
     * telling them which of the two was refused. Every message here names the
     * login page.
     */
    public function messages(): array
    {
        return [
            'image.mimes' => 'The login background must be a PNG, JPEG, GIF or WebP. SVG is not supported — it can carry script, and this file is served to every visitor.',
            'image.max' => 'The login background image must be smaller than 8 MB. It is downloaded by every visitor on every login.',
            'fit.in' => 'How the image should fill the login background must be cover, contain or tile.',
            'dim.min' => 'The dim amount cannot be less than 0.',
            'dim.max' => 'The dim amount cannot be more than 0.95 — at 1 the image would be completely hidden.',
        ];
    }

    public function attributes(): array
    {
        return [
            'image' => 'login background image',
            'dim' => 'dim amount',
            'fit' => 'fill mode',
        ];
    }
}

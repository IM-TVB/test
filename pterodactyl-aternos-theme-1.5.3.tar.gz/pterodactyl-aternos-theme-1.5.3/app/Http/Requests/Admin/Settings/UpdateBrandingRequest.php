<?php

namespace Pterodactyl\Http\Requests\Admin\Settings;

use Pterodactyl\Http\Requests\Admin\AdminFormRequest;

class UpdateBrandingRequest extends AdminFormRequest
{
    public function rules(): array
    {
        return [
            'icon' => ['nullable', 'file', 'mimes:png,jpg,jpeg,gif', 'max:4096'],
            'color' => ['required', 'string', 'regex:/^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/'],
            'name' => ['nullable', 'string', 'max:64'],
            'crop' => ['nullable', 'boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'icon.mimes' => 'The icon must be a PNG, JPEG or GIF. SVG is not supported — export a PNG instead.',
            'icon.max' => 'The icon must be smaller than 4 MB.',
            'color.regex' => 'The colour must be a hex value such as #007bff.',
        ];
    }

    public function attributes(): array
    {
        return [
            'icon' => 'icon',
            'color' => 'colour',
        ];
    }
}

<?php

namespace Pterodactyl\Http\Requests\Api\Client\Account;

use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;
use Pterodactyl\Services\Settings\UserAvatarService;
use Illuminate\Validation\Rule;

/**
 * Validates a profile picture upload.
 *
 * The mimes rule is a convenience, not the gate: UserAvatarService probes the
 * real image type with getimagesize() before anything is written. SVG is refused
 * for the same reason as the logo's -- it can carry script, and this file is
 * served to every user who can see the person.
 */
class UpdateAvatarRequest extends ClientApiRequest
{
    public function rules(): array
    {
        return [
            'image' => [
                'required',
                'file',
                'mimes:' . implode(',', ['png', 'jpg', 'jpeg', 'gif', 'webp']),
                'max:' . UserAvatarService::MAX_BYTES,
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'image.required' => 'Choose a picture to upload.',
            'image.mimes' => 'The picture must be a PNG, JPEG, GIF or WebP. SVG is not supported — it can carry script.',
            'image.max' => 'The picture must be smaller than 2 MB.',
        ];
    }

    public function attributes(): array
    {
        return [
            'image' => 'profile picture',
        ];
    }
}

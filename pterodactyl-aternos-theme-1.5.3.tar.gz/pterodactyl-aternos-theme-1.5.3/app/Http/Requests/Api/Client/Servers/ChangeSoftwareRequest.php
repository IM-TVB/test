<?php

namespace Pterodactyl\Http\Requests\Api\Client\Servers;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Pterodactyl\Models\EggVariable;
use Pterodactyl\Models\Server;
use Pterodactyl\Models\ServerVariable;

/**
 * Validates a software change.
 *
 * A software change is a reinstall, and a reinstall deletes the server's files.
 * A backup is therefore *offered* but not required: the panel used to demand a
 * completed backup on record, which on a server with the default backup limit of
 * 0 made the change impossible to perform at all -- the confirm button rendered
 * disabled and clicking it did nothing, with no way for the user to tell why.
 * The operator has decided the destructive step does not need a recovery point
 * to be taken, so `backup` is optional here.
 *
 * What is kept is the acknowledgement. It costs nothing, it is not a backup
 * requirement, and it is the last point at which anyone is told that the world
 * is about to be deleted. The root-admin gate stays too: an egg swap is an
 * administrative action in stock Pterodactyl and no client route accepts an egg
 * id, so allowing every server owner to do this would be a privilege change
 * rather than a UI one.
 */
class ChangeSoftwareRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null && $this->user()->root_admin;
    }

    public function rules(): array
    {
        return [
            'egg_id' => ['required', 'integer', Rule::exists('eggs', 'id')],
            'version' => ['sometimes', 'nullable', 'string', 'max:64'],
            // Optional. When present it must still be a real, restorable backup
            // belonging to this server, so a crafted uuid cannot be used to imply
            // a recovery point that does not exist.
            'backup' => ['sometimes', 'nullable', 'string', 'uuid'],
            /**
             * Whether the reinstall wipes what is already there.
             *
             * Optional, and absent means YES -- the behaviour this endpoint always
             * had. A caller that predates the choice must not find that a software
             * change quietly became non-destructive. Named delete_files rather than
             * the daemon's truncate_directory because that is the question an
             * operator is actually being asked.
             */
            'delete_files' => ['sometimes', 'boolean'],
            'acknowledged' => ['accepted'],
        ];
    }

    public function withValidator($validator): void
    {
        $validator->after(function ($validator) {
            $server = $this->route()->parameter('server');

            if (!is_object($server) || !$server->exists) {
                return;
            }

            if ($this->filled('backup')) {
                // Addressed by uuid, not id: the backup transformer never exposes
                // the numeric id, so uuid is the only handle a client can hold.
                $backup = $server->backups()->where('uuid', $this->input('backup'))->first();

                if (!$backup || !$backup->is_successful || is_null($backup->completed_at)) {
                    $validator->errors()->add('backup', 'That backup does not exist or cannot be restored.');

                    return;
                }
            }

            // A reinstall is only possible on an idle server.
            if (!is_null($server->status)) {
                $validator->errors()->add(
                    'acknowledged',
                    'This server is not in a state that allows its software to be changed right now.'
                );

                return;
            }

            // Refuse a no-op "change" that would needlessly trigger a reinstall.
            //
            // Same software *and* same version is the only true no-op. Judging on
            // the egg alone made it impossible to move a server to a different
            // game version while keeping its software -- which is the most common
            // reason to reinstall at all. The guard called that "already the
            // software this server is running" and the version silently stayed put.
            if ((int) $this->input('egg_id') === (int) $server->egg_id) {
                $requested = $this->input('version');
                $running = $this->runningVersion($server);

                $versionUnchanged = $running === null
                    || $requested === null
                    || $requested === ''
                    || trim((string) $requested) === trim((string) $running);

                if ($versionUnchanged) {
                    $validator->errors()->add(
                        'egg_id',
                        'That is already the software and version this server is running.'
                    );
                }
            }
        });
    }

    /**
     * The game version this server is currently installed at.
     *
     * Read from the server's own variables, which is where a per-server value
     * lives; the egg's variables are the definitions and carry no server value.
     *
     * Null means there is no version to compare, and the caller treats that as a
     * no-op -- refusing is the safe direction, since the alternative is a
     * reinstall triggered by a request that changes nothing.
     */
    private function runningVersion(Server $server): ?string
    {
        $variable = EggVariable::query()
            ->where('egg_id', $server->egg_id)
            ->get()
            ->first(fn ($v) => str_ends_with($v->env_variable, '_VERSION')
                && !str_contains($v->env_variable, 'JARFILE')
                && $v->user_viewable);

        if ($variable === null) {
            return null;
        }

        $value = ServerVariable::query()
            ->where('server_id', $server->id)
            ->where('variable_id', $variable->id)
            ->value('variable_value');

        return is_string($value) && $value !== '' ? $value : null;
    }

    public function messages(): array
    {
        return [
            'acknowledged.accepted' => 'You must confirm that changing software reinstalls the server and deletes its files.',
            'delete_files.boolean' => 'Choose whether the reinstall deletes the existing files or keeps them.',
        ];
    }

    public function attributes(): array
    {
        return [
            'egg_id' => 'software',
            'backup' => 'backup',
        ];
    }
}

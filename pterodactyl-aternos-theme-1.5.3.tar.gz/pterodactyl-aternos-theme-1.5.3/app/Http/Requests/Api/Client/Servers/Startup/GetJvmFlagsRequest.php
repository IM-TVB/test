<?php

namespace Pterodactyl\Http\Requests\Api\Client\Servers\Startup;

use Pterodactyl\Models\Permission;
use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;

/**
 * Reading the JVM flag presets.
 *
 * Separate from the update request, following the read/update pair the startup
 * endpoints already use: a GET carries no preset, so a form that required one
 * would fail its own validation on the read.
 *
 * startup.read, the same permission the Startup page itself is gated on -- the
 * picker lives on that page, and a different permission here would only let the
 * endpoint and the page disagree about who may see this.
 *
 * @see UpdateJvmFlagsRequest
 */
class GetJvmFlagsRequest extends ClientApiRequest
{
    public function permission(): string
    {
        return Permission::ACTION_STARTUP_READ;
    }
}

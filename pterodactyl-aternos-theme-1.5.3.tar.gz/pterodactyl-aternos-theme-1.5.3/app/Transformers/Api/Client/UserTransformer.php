<?php

namespace Pterodactyl\Transformers\Api\Client;

use Illuminate\Support\Str;
use Pterodactyl\Models\User;

class UserTransformer extends BaseClientTransformer
{
    /**
     * Return the resource name for the JSONAPI output.
     */
    public function getResourceName(): string
    {
        return User::RESOURCE_NAME;
    }

    /**
     * Transforms a User model into a representation that can be shown to regular
     * users of the API.
     */
    public function transform(User $model): array
    {
        return [
            'uuid' => $model->uuid,
            'identifier' => $model->identifier,
            'username' => $model->username,
            'email' => $model->email,
            'image' => 'https://gravatar.com/avatar/' . md5(Str::lower($model->email)),
            /*
             * The user's own picture, or null.
             *
             * A separate field from `image` rather than overwriting it: `image` is
             * a Gravatar derived from the email address and other consumers may
             * already depend on it. Null has to mean "the user did not upload
             * one", so the sidebar falls back to the identicon it always drew --
             * a user with no picture is the normal state, not a broken image.
             */
            'avatar_url' => app(\Pterodactyl\Services\Settings\UserAvatarService::class)->url($model),
            '2fa_enabled' => $model->use_totp,
            'created_at' => $model->created_at->toAtomString(),
        ];
    }
}

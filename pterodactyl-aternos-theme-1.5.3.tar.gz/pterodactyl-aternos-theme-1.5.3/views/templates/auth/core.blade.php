{{-- The theme class is applied to <html> by the inline script in
     templates/wrapper.blade.php, so <body> keeps the stock background. --}}
@extends('templates/wrapper', [
    'css' => ['body' => 'bg-neutral-900'],
])

@section('container')
    <div id="app"></div>
@endsection

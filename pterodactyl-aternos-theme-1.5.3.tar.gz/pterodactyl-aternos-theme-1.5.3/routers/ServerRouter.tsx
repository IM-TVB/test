import TransferListener from '@/components/server/TransferListener';
import React, { useEffect, useState } from 'react';
import { NavLink, Route, Switch, useRouteMatch } from 'react-router-dom';
import NavigationBar from '@/components/NavigationBar';
import TransitionRouter from '@/TransitionRouter';
import WebsocketHandler from '@/components/server/WebsocketHandler';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import Spinner from '@/components/elements/Spinner';
import { NotFound, ServerError } from '@/components/elements/ScreenBlock';
import { httpErrorToHuman } from '@/api/http';
import { useStoreState } from 'easy-peasy';
import InstallListener from '@/components/server/InstallListener';
import ErrorBoundary from '@/components/elements/ErrorBoundary';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faBoxOpen,
    faCog,
    faClock,
    faDatabase,
    faExternalLinkAlt,
    faFolderOpen,
    faHistory,
    faNetworkWired,
    faRocket,
    faTerminal,
    faUsers,
    faPuzzlePiece,
    IconDefinition,
} from '@fortawesome/free-solid-svg-icons';
import { useLocation } from 'react-router';
import ConflictStateRenderer from '@/components/server/ConflictStateRenderer';
import PermissionRoute from '@/components/elements/PermissionRoute';
import routes from '@/routers/routes';

/** Icons for the per-server sidebar links, keyed by the route's display name. */
const serverRouteIcons: Record<string, IconDefinition> = {
    Console: faTerminal,
    Files: faFolderOpen,
    Databases: faDatabase,
    Schedules: faClock,
    Users: faUsers,
    Backups: faBoxOpen,
    Network: faNetworkWired,
    Startup: faRocket,
    Settings: faCog,
    Activity: faHistory,
    'Plugins & Mods': faPuzzlePiece,
};

export default () => {
    const match = useRouteMatch<{ id: string }>();
    const location = useLocation();

    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const [error, setError] = useState('');

    const id = ServerContext.useStoreState((state) => state.server.data?.id);
    const uuid = ServerContext.useStoreState((state) => state.server.data?.uuid);
    const name = ServerContext.useStoreState((state) => state.server.data?.name);
    const inConflictState = ServerContext.useStoreState((state) => state.server.inConflictState);
    const serverId = ServerContext.useStoreState((state) => state.server.data?.internalId);
    const getServer = ServerContext.useStoreActions((actions) => actions.server.getServer);
    const clearServerState = ServerContext.useStoreActions((actions) => actions.clearServerState);

    const to = (value: string, url = false) => {
        if (value === '/') {
            return url ? match.url : match.path;
        }
        return `${(url ? match.url : match.path).replace(/\/*$/, '')}/${value.replace(/^\/+/, '')}`;
    };

    useEffect(
        () => () => {
            clearServerState();
        },
        []
    );

    useEffect(() => {
        setError('');

        getServer(match.params.id).catch((error) => {
            console.error(error);
            setError(httpErrorToHuman(error));
        });

        return () => {
            clearServerState();
        };
    }, [match.params.id]);

    const serverNavigation = (
        <>
            {routes.server
                .filter((route) => !!route.name)
                .map((route) => {
                    const icon = route.name ? serverRouteIcons[route.name] : undefined;

                    if (process.env.NODE_ENV !== 'production' && route.name && !icon) {
                        // eslint-disable-next-line no-console
                        console.warn(
                            `[sidebar] no icon mapped for the server route "${route.name}" — add it to serverRouteIcons in ServerRouter.tsx`
                        );
                    }

                    const link = (
                        <NavLink
                            key={route.path}
                            to={to(route.path, true)}
                            exact={route.exact}
                            className={'at-sidebar__link at-sidebar__link--nested'}
                            activeClassName={'at-sidebar__link--active'}
                        >
                            {icon && <FontAwesomeIcon icon={icon} />}
                            <span>{route.name}</span>
                        </NavLink>
                    );

                    return route.permission ? (
                        <Can key={route.path} action={route.permission} matchAny>
                            {link}
                        </Can>
                    ) : (
                        link
                    );
                })}
            {rootAdmin && (
                // eslint-disable-next-line react/jsx-no-target-blank
                <a
                    href={`/admin/servers/view/${serverId}`}
                    target={'_blank'}
                    className={'at-sidebar__link at-sidebar__link--nested'}
                >
                    <FontAwesomeIcon icon={faExternalLinkAlt} />
                    <span>View in Admin</span>
                </a>
            )}
        </>
    );

    return (
        <div className={'at-shell'} key={'server-router'}>
            <NavigationBar sectionLabel={name}>{serverNavigation}</NavigationBar>
            <div className={'at-shell__main'}>
                {!uuid || !id ? (
                    error ? (
                        <ServerError message={error} />
                    ) : (
                        <Spinner size={'large'} centered />
                    )
                ) : (
                    <>
                        <InstallListener />
                        <TransferListener />
                        <WebsocketHandler />
                        {inConflictState &&
                        (!rootAdmin || (rootAdmin && !location.pathname.endsWith(`/server/${id}`))) ? (
                            <ConflictStateRenderer />
                        ) : (
                            <ErrorBoundary>
                                <TransitionRouter>
                                    <Switch location={location}>
                                        {routes.server.map(({ path, permission, component: Component }) => (
                                            <PermissionRoute key={path} permission={permission} path={to(path)} exact>
                                                <Spinner.Suspense>
                                                    <Component />
                                                </Spinner.Suspense>
                                            </PermissionRoute>
                                        ))}
                                        <Route path={'*'} component={NotFound} />
                                    </Switch>
                                </TransitionRouter>
                            </ErrorBoundary>
                        )}
                    </>
                )}
            </div>
        </div>
    );
};

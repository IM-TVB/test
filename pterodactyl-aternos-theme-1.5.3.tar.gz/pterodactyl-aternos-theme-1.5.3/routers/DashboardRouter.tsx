import React from 'react';
import { NavLink, Route, Switch } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHistory, faKey, faServer, faUser, IconDefinition } from '@fortawesome/free-solid-svg-icons';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import NavigationBar from '@/components/NavigationBar';
import DashboardContainer from '@/components/dashboard/DashboardContainer';
import { NotFound } from '@/components/elements/ScreenBlock';
import TransitionRouter from '@/TransitionRouter';
import { useLocation } from 'react-router';
import Spinner from '@/components/elements/Spinner';
import routes from '@/routers/routes';

/**
 * Icons for the account sidebar links, keyed by the route's display name in
 * routers/routes.ts. A name missing from this map still renders, but the row
 * loses its indent alignment — hence the dev warning below.
 */
const accountRouteIcons: Record<string, IconDefinition> = {
    Account: faUser,
    'API Credentials': faKey,
    'SSH Keys': faServer,
    Activity: faHistory,
};

export default () => {
    const location = useLocation();
    const username = useStoreState((state: ApplicationStore) => state.user.data?.username);

    const inAccount = location.pathname.startsWith('/account');

    const accountNavigation = inAccount ? (
        <>
            {routes.account
                .filter((route) => !!route.name)
                .map(({ path, name, exact = false }) => {
                    const to = `/account/${path}`.replace('//', '/');
                    const icon = name ? accountRouteIcons[name] : undefined;

                    if (process.env.NODE_ENV !== 'production' && name && !icon) {
                        // eslint-disable-next-line no-console
                        console.warn(
                            `[sidebar] no icon mapped for the account route "${name}" — add it to accountRouteIcons in DashboardRouter.tsx`
                        );
                    }

                    return (
                        <NavLink
                            key={path}
                            to={to}
                            exact={exact}
                            className={'at-sidebar__link at-sidebar__link--nested'}
                            activeClassName={'at-sidebar__link--active'}
                        >
                            {icon && <FontAwesomeIcon icon={icon} />}
                            <span>{name}</span>
                        </NavLink>
                    );
                })}
        </>
    ) : null;

    return (
        <div className={'at-shell'}>
            <NavigationBar sectionLabel={username}>{accountNavigation}</NavigationBar>
            <div className={'at-shell__main'}>
                <TransitionRouter>
                    <React.Suspense fallback={<Spinner centered />}>
                        <Switch location={location}>
                            <Route path={'/'} exact>
                                <DashboardContainer />
                            </Route>
                            {routes.account.map(({ path, component: Component }) => (
                                <Route key={path} path={`/account/${path}`.replace('//', '/')} exact>
                                    <Component />
                                </Route>
                            ))}
                            <Route path={'*'}>
                                <NotFound />
                            </Route>
                        </Switch>
                    </React.Suspense>
                </TransitionRouter>
            </div>
        </div>
    );
};

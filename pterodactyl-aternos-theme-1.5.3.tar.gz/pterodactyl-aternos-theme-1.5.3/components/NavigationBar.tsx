import * as React from 'react';
import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Menu, Transition } from '@headlessui/react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import tw from 'twin.macro';
import {
    faBars,
    faCogs,
    faHistory,
    faKey,
    faLayerGroup,
    faMoon,
    faSearch,
    faServer,
    faSignOutAlt,
    faSun,
    faTimes,
    faUser,
    IconDefinition,
} from '@fortawesome/free-solid-svg-icons';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import SearchModal from '@/components/dashboard/search/SearchModal';
import useEventListener from '@/plugins/useEventListener';
import useTheme from '@/plugins/useTheme';
import useCollapsibleNav from '@/plugins/useCollapsibleNav';
import http from '@/api/http';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import Avatar from '@/components/Avatar';

const SidebarLink = ({
    to,
    icon,
    label,
    exact,
    onNavigate,
}: {
    to: string;
    icon: IconDefinition;
    label: string;
    exact?: boolean;
    onNavigate: () => void;
}) => (
    <NavLink
        to={to}
        exact={exact}
        className={'at-sidebar__link'}
        activeClassName={'at-sidebar__link--active'}
        onClick={onNavigate}
    >
        <FontAwesomeIcon icon={icon} />
        <span>{label}</span>
    </NavLink>
);

const AccountMenu = ({ onLogout, onNavigate }: { onLogout: () => void; onNavigate: () => void }) => {
    const username = useStoreState((state: ApplicationStore) => state.user.data?.username);
    const email = useStoreState((state: ApplicationStore) => state.user.data?.email);
    const rootAdmin = useStoreState((state: ApplicationStore) => state.user.data?.rootAdmin);

    return (
        <Menu as={'div'} className={'relative w-full'}>
            <Menu.Button className={'at-sidebar__user'}>
                <span className={'at-sidebar__avatar'}>
                    <Avatar.User />
                </span>
                <span className={'at-sidebar__username'}>{username}</span>
            </Menu.Button>

            <Transition
                enter={'transition duration-100 ease-out'}
                enterFrom={'transform scale-95 opacity-0'}
                enterTo={'transform scale-100 opacity-100'}
                leave={'transition duration-75 ease-out'}
                leaveFrom={'transform scale-100 opacity-100'}
                leaveTo={'transform scale-95 opacity-0'}
            >
                {/* Opens upward: it is anchored to the sidebar footer. */}
                <Menu.Items className={'at-menu absolute bottom-full left-0 mb-2 z-50'}>
                    <div className={'at-menu__head'}>
                        <div className={'at-menu__head-name'}>{username}</div>
                        <div className={'at-menu__head-mail'}>{email}</div>
                    </div>

                    <Link to={'/account'} className={'at-menu__item'} onClick={onNavigate}>
                        <FontAwesomeIcon icon={faUser} />
                        Profile
                    </Link>
                    <Link to={'/account/api'} className={'at-menu__item'} onClick={onNavigate}>
                        <FontAwesomeIcon icon={faKey} />
                        API Credentials
                    </Link>
                    <Link to={'/account/ssh'} className={'at-menu__item'} onClick={onNavigate}>
                        <FontAwesomeIcon icon={faServer} />
                        SSH Keys
                    </Link>
                    <Link to={'/account/activity'} className={'at-menu__item'} onClick={onNavigate}>
                        <FontAwesomeIcon icon={faHistory} />
                        Activity Log
                    </Link>
                    {rootAdmin && (
                        <a href={'/admin'} className={'at-menu__item'}>
                            <FontAwesomeIcon icon={faCogs} />
                            Admin Panel
                        </a>
                    )}

                    <div className={'border-t border-neutral-200 my-1.5'} />

                    <button type={'button'} onClick={onLogout} className={'at-menu__item at-menu__item--danger'}>
                        <FontAwesomeIcon icon={faSignOutAlt} />
                        Log Out
                    </button>
                </Menu.Items>
            </Transition>
        </Menu>
    );
};

interface Props {
    /**
     * Contextual links rendered in their own sidebar section directly under the
     * brand — the per-server pages (Console, Files, …). Permission filtering
     * stays with the caller, because only the router holds the server context.
     */
    children?: React.ReactNode;
    /** Heading for that section, e.g. the server name. */
    sectionLabel?: string;
}

/**
 * Aternos-style LEFT navigation.
 *
 * Renders three siblings: a mobile-only top bar (the sidebar is off-canvas
 * below 1024px, so the toggle has to live outside it), the sidebar, and a
 * scrim. The routers wrap their page content in `.at-shell__main`, so on
 * desktop the flex `.at-shell` places the sidebar left of the content.
 */
export default ({ children, sectionLabel }: Props) => {

    const name = useStoreState((state: ApplicationStore) => state.settings.data?.name) || 'Panel';
    // A null url means no logo has been set, and the initial-letter tile below is
    // the fallback. Deliberately not an <img> that fails to load: the tile is a
    // default, and a broken-image icon in the sidebar of every page would be
    // worse than the tile.
    const logoUrl = useStoreState((state: ApplicationStore) => state.settings.data?.logo?.url) || null;
    const rootAdmin = useStoreState((state: ApplicationStore) => state.user.data?.rootAdmin);

    const [open, setOpen] = useState(false);
    const [isLoggingOut, setIsLoggingOut] = useState(false);
    const [searchVisible, setSearchVisible] = useState(false);
    const { theme, toggle: toggleTheme } = useTheme();
    const { collapsed, toggle: toggleCollapsed } = useCollapsibleNav();

    const close = () => setOpen(false);

    // Preserved from SearchContainer, which this replaces in the sidebar.
    useEventListener('keydown', (e: KeyboardEvent) => {
        if (['input', 'textarea'].indexOf(((e.target as HTMLElement).tagName || 'input').toLowerCase()) < 0) {
            if (!searchVisible && e.metaKey && e.key.toLowerCase() === '/') {
                setSearchVisible(true);
            }
        }
    });

    const onTriggerLogout = () => {
        setIsLoggingOut(true);
        http.post('/auth/logout').finally(() => {
            // @ts-expect-error this is valid
            window.location = '/';
        });
    };

    const initial = (name || 'P').trim().charAt(0).toUpperCase();

    /*
     * Two places draw the logo -- the collapsed burger bar and the open sidebar --
     * and they must not drift, so the mark is built once here. The tile keeps its
     * gradient behind the mark: an uploaded logo with transparency then still has
     * a background, and a square logo sits in a square rather than floating.
     */
    const logoMark = (size: 'full' | 'small') => (
        <span className={`at-sidebar__logo at-sidebar__logo--${size}`}>
            {logoUrl ? <img src={logoUrl} alt={''} className={'at-sidebar__logoimg'} /> : initial}
        </span>
    );

    return (
        <>
            {searchVisible && (
                <SearchModal appear visible={searchVisible} onDismissed={() => setSearchVisible(false)} />
            )}

            {/* Mobile-only bar. */}
            <div className={'at-topbar'}>
                <div className={'at-topbar__inner'}>
                    <button
                        type={'button'}
                        className={'at-topbar__burger'}
                        aria-label={'Open navigation'}
                        aria-expanded={open}
                        onClick={() => setOpen(true)}
                    >
                        <FontAwesomeIcon icon={faBars} />
                    </button>
                    {logoMark('small')}
                    <span className={'at-sidebar__name'}>{name}</span>
                </div>
            </div>

            <aside className={`at-sidebar${open ? ' is-open' : ''}`}>
                <SpinnerOverlay visible={isLoggingOut} />

                <div className={'at-sidebar__brand'}>
                    <Link to={'/'} className={'at-sidebar__brandlink'} onClick={close}>
                        {logoMark('full')}
                        <span className={'at-sidebar__name'}>{name}</span>
                    </Link>
                    <button
                        type={'button'}
                        className={'at-sidebar__close'}
                        aria-label={'Close navigation'}
                        onClick={close}
                    >
                        <FontAwesomeIcon icon={faTimes} />
                    </button>
                    {/* Desktop only: folds the sidebar away so the content gets
                        the full width. Below 1024px the sidebar is an
                        off-canvas drawer and the top bar's burger is the
                        control, so this one is hidden there in CSS. */}
                    <button
                        type={'button'}
                        className={'at-sidebar__burger'}
                        aria-label={'Hide the sidebar'}
                        aria-expanded={!collapsed}
                        onClick={toggleCollapsed}
                    >
                        <FontAwesomeIcon icon={faBars} />
                    </button>
                </div>

                <div className={'at-sidebar__nav'}>
                    {children ? (
                        <>
                            <div className={'at-sidebar__section'}>{sectionLabel || 'Server'}</div>
                            {children}
                            <div className={'at-sidebar__divider'} />
                        </>
                    ) : null}

                    <SidebarLink to={'/'} icon={faLayerGroup} label={'Servers'} exact onNavigate={close} />
                    <SidebarLink to={'/account'} icon={faUser} label={'Account'} onNavigate={close} />

                    {rootAdmin && (
                        <>
                            <div className={'at-sidebar__section'}>Administration</div>
                            {/* eslint-disable-next-line react/jsx-no-target-blank */}
                            <a href={'/admin'} className={'at-sidebar__link'}>
                                <FontAwesomeIcon icon={faCogs} />
                                <span>Admin Panel</span>
                            </a>
                        </>
                    )}

                    <div className={'at-sidebar__section'}>Quick actions</div>
                    <button
                        type={'button'}
                        className={'at-sidebar__search'}
                        onClick={() => {
                            setSearchVisible(true);
                            close();
                        }}
                    >
                        <FontAwesomeIcon icon={faSearch} />
                        <span>Search servers</span>
                    </button>
                </div>

                <div className={'at-sidebar__foot'}>
                    <button
                        type={'button'}
                        className={'at-theme-toggle'}
                        onClick={toggleTheme}
                        aria-label={theme === 'dark' ? 'Switch to blue mode' : 'Switch to dark mode'}
                        title={theme === 'dark' ? 'Switch to blue mode' : 'Switch to dark mode'}
                    >
                        {/* Shows the mode you would switch TO. */}
                        <span className={'at-theme-toggle__icon'}>
                            <FontAwesomeIcon icon={theme === 'dark' ? faSun : faMoon} />
                        </span>
                        <span>{theme === 'dark' ? 'Blue mode' : 'Dark mode'}</span>
                    </button>

                    <AccountMenu onLogout={onTriggerLogout} onNavigate={close} />
                </div>
            </aside>

            {/* The way back once the sidebar is folded away. Fixed rather than in
                flow, because at that point the sidebar it belongs to has no
                width to sit in. Hidden below 1024px, where the top bar's own
                burger is the control. */}
            <button
                type={'button'}
                className={`at-nav-restore${collapsed ? ' is-visible' : ''}`}
                aria-label={'Show the sidebar'}
                aria-expanded={!collapsed}
                onClick={toggleCollapsed}
            >
                <FontAwesomeIcon icon={faBars} />
            </button>

            <div
                className={`at-scrim${open ? ' is-open' : ''}`}
                onClick={close}
                role={'presentation'}
                aria-hidden={!open}
            />
        </>
    );
};

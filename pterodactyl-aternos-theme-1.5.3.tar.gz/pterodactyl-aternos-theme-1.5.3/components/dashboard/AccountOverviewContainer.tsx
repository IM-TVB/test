import * as React from 'react';
import ContentBox from '@/components/elements/ContentBox';
import UpdatePasswordForm from '@/components/dashboard/forms/UpdatePasswordForm';
import UpdateEmailAddressForm from '@/components/dashboard/forms/UpdateEmailAddressForm';
import UpdateAvatarForm from '@/components/dashboard/forms/UpdateAvatarForm';
import ConfigureTwoFactorForm from '@/components/dashboard/forms/ConfigureTwoFactorForm';
import PageContentBlock from '@/components/elements/PageContentBlock';
import tw from 'twin.macro';
import { breakpoint } from '@/theme';
import styled from 'styled-components/macro';
import MessageBox from '@/components/MessageBox';
import { useLocation } from 'react-router-dom';
import { useStoreState } from 'easy-peasy';
import Avatar from '@/components/Avatar';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserShield, faEnvelope, faCalendar } from '@fortawesome/free-solid-svg-icons';

/**
 * Profile summary strip above the account forms, in the same tiles the
 * dashboard uses for its server stats, so the two pages read as one product.
 */
const AccountHeader = () => {
    const user = useStoreState((state: any) => state.user.data);

    if (!user) {
        return null;
    }

    const created = user.createdAt ? new Date(user.createdAt).toLocaleDateString() : '—';

    return (
        <div css={tw`grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8`}>
            <div className="at-stat">
                <div className="at-stat__icon" style={{ background: '#e7f1ff' }}>
                    {/* Avatar.User: the uploaded picture, falling back to the
                        identicon. Sizing stays on the wrapper, as everywhere else
                        the Avatar component is used. */}
                    <Avatar.User size={40} />
                </div>
                <div className="at-stat__label">Username</div>
                <div className="at-stat__value">{user.username}</div>
            </div>
            <div className="at-stat">
                <div className="at-stat__icon" style={{ background: '#dcf5e3', color: '#146c2e' }}>
                    <FontAwesomeIcon icon={faEnvelope} />
                </div>
                <div className="at-stat__label">Email</div>
                <div className="at-stat__value" style={{ fontSize: '14px' }}>{user.email}</div>
            </div>
            <div className="at-stat">
                <div className="at-stat__icon" style={{ background: '#fff3d1', color: '#8a6100' }}>
                    <FontAwesomeIcon icon={faUserShield} />
                </div>
                <div className="at-stat__label">2FA</div>
                <div className="at-stat__value">{user.useTotp ? 'On' : 'Off'}</div>
            </div>
            <div className="at-stat">
                <div className="at-stat__icon" style={{ background: '#f3e8ff', color: '#6b21a8' }}>
                    <FontAwesomeIcon icon={faCalendar} />
                </div>
                <div className="at-stat__label">Joined</div>
                <div className="at-stat__value">{created}</div>
            </div>
        </div>
    );
};

const Container = styled.div`
    ${tw`flex flex-wrap`};

    & > div {
        ${tw`w-full`};

        ${breakpoint('sm')`
      width: calc(50% - 1rem);
    `}

        ${breakpoint('md')`
      ${tw`w-auto flex-1`};
    `}
    }
`;

export default () => {
    const { state } = useLocation<undefined | { twoFactorRedirect?: boolean }>();

    return (
        <PageContentBlock title={'Account Overview'}>
            <AccountHeader />
            {state?.twoFactorRedirect && (
                <MessageBox title={'2-Factor Required'} type={'error'}>
                    Your account must have two-factor authentication enabled in order to continue.
                </MessageBox>
            )}

            <Container css={[tw`lg:grid lg:grid-cols-3 mb-10`, state?.twoFactorRedirect ? tw`mt-4` : tw`mt-10`]}>
                {/*
                    First, because it is the only box here that is about who you
                    are rather than how you sign in.
                */}
                <ContentBox showFlashes={'account:avatar'}>
                    <UpdateAvatarForm />
                </ContentBox>
                <ContentBox title={'Update Password'} showFlashes={'account:password'}>
                    <UpdatePasswordForm />
                </ContentBox>
                <ContentBox css={tw`mt-8 sm:mt-0 sm:ml-8`} title={'Update Email Address'} showFlashes={'account:email'}>
                    <UpdateEmailAddressForm />
                </ContentBox>
                <ContentBox css={tw`md:ml-8 mt-8 md:mt-0`} title={'Two-Step Verification'}>
                    <ConfigureTwoFactorForm />
                </ContentBox>
            </Container>
        </PageContentBlock>
    );
};

import React, { useEffect, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import type { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import { faHdd, faLayerGroup, faMemory, faMicrochip } from '@fortawesome/free-solid-svg-icons';
import { Server } from '@/api/server/getServer';
import getServers from '@/api/getServers';
import ServerRow from '@/components/dashboard/ServerRow';
import Spinner from '@/components/elements/Spinner';
import PageContentBlock from '@/components/elements/PageContentBlock';
import useFlash from '@/plugins/useFlash';
import { useStoreState } from 'easy-peasy';
import { usePersistedState } from '@/plugins/usePersistedState';
import Switch from '@/components/elements/Switch';
import tw from 'twin.macro';
import useSWR from 'swr';
import { PaginatedResult } from '@/api/http';
import Pagination from '@/components/elements/Pagination';
import { useLocation } from 'react-router-dom';
import { bytesToString, mbToBytes } from '@/lib/formatters';

/**
 * The admin-set announcement, shown above the stat tiles (same row of stat
 * tiles as Total Servers / CPU / Memory / Disk). Read from the same
 * window.SiteConfiguration the settings store is seeded from.
 */
const AnnouncementBanner = () => {
    const announcement = (window as any).SiteConfiguration?.announcement;

    if (!announcement || !announcement.enabled || !announcement.message) {
        return null;
    }

    const palette = {
        info: { fg: '#0f6fde', bg: '#eaf3ff' },
        success: { fg: '#1d7f3e', bg: '#e8f7ee' },
        warning: { fg: '#9a6a00', bg: '#fff6dd' },
        danger: { fg: '#b3261e', bg: '#fdeceb' },
    }[announcement.type as string] || { fg: '#0f6fde', bg: '#eaf3ff' };

    // An explicit background colour from the admin overrides the style's
    // built-in palette; the text colour is derived from it for contrast.
    if (typeof announcement.color === 'string' && /^#([0-9a-f]{6}|[0-9a-f]{3})$/i.test(announcement.color)) {
        const hex = announcement.color.replace('#', '');
        const full = hex.length === 3 ? hex.split('').map((c: string) => c + c).join('') : hex;
        const r = parseInt(full.slice(0, 2), 16);
        const g = parseInt(full.slice(2, 4), 16);
        const b = parseInt(full.slice(4, 6), 16);
        const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        palette.bg = '#' + full;
        palette.fg = luminance > 0.6 ? '#1f2937' : '#ffffff';
    }

    return (
        <div
            role="alert"
            css={tw`mb-6 flex items-center justify-between rounded-xl px-4 py-3 text-sm font-semibold`}
            style={{ color: palette.fg, background: palette.bg, border: `1px solid ${palette.fg}33` }}
        >
            <span>{announcement.message}</span>
        </div>
    );
};

const StatTile = ({
    icon,
    label,
    value,
    bg,
    color,
}: {
    icon: IconDefinition;
    label: string;
    value: string | number;
    bg: string;
    color: string;
}) => (
    <div className="at-stat">
        <div className="at-stat__icon" style={{ background: bg, color }}>
            <FontAwesomeIcon icon={icon} />
        </div>
        <div className="at-stat__label">{label}</div>
        <div className="at-stat__value">{value}</div>
    </div>
);

export default () => {
    const { search } = useLocation();
    const defaultPage = Number(new URLSearchParams(search).get('page') || '1');

    const [page, setPage] = useState(!isNaN(defaultPage) && defaultPage > 0 ? defaultPage : 1);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const uuid = useStoreState((state) => state.user.data!.uuid);
    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const [showOnlyAdmin, setShowOnlyAdmin] = usePersistedState(`${uuid}:show_all_servers`, false);

    const { data: servers, error } = useSWR<PaginatedResult<Server>>(
        ['/api/client/servers', showOnlyAdmin && rootAdmin, page],
        () => getServers({ page, type: showOnlyAdmin && rootAdmin ? 'admin' : undefined })
    );

    useEffect(() => {
        setPage(1);
    }, [showOnlyAdmin]);

    useEffect(() => {
        if (!servers) return;
        if (servers.pagination.currentPage > 1 && !servers.items.length) {
            setPage(1);
        }
    }, [servers?.pagination.currentPage]);

    useEffect(() => {
        // Don't use react-router to handle changing this part of the URL, otherwise it
        // triggers a needless re-render. We just want to track this in the URL incase the
        // user refreshes the page.
        window.history.replaceState(null, document.title, `/${page <= 1 ? '' : `?page=${page}`}`);
    }, [page]);

    useEffect(() => {
        if (error) clearAndAddHttpError({ key: 'dashboard', error });
        if (!error) clearFlashes('dashboard');
    }, [error]);

    // Stat tiles are derived from the servers on the current page. The list
    // endpoint does not expose live power state, so there is deliberately no
    // "online now" tile here — ServerRow shows per-server status instead.
    const items = servers?.items ?? [];
    const totalMemory = items.reduce((acc, server) => acc + server.limits.memory, 0);
    const totalCpu = items.reduce((acc, server) => acc + server.limits.cpu, 0);
    const totalDisk = items.reduce((acc, server) => acc + server.limits.disk, 0);

    return (
        <PageContentBlock title={'Dashboard'} showFlashKey={'dashboard'}>
            <AnnouncementBanner />
            {servers && items.length > 0 && (
                <div css={tw`grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6`}>
                    <StatTile
                        icon={faLayerGroup}
                        label={'Total Servers'}
                        value={servers.pagination.total}
                        bg={'#e7f1ff'}
                        color={'#0062cc'}
                    />
                    <StatTile
                        icon={faMicrochip}
                        label={'CPU Cores'}
                        value={totalCpu}
                        bg={'#fff3d1'}
                        color={'#8a6100'}
                    />
                    <StatTile
                        icon={faMemory}
                        label={'Memory'}
                        value={totalMemory === 0 ? 'Unlimited' : bytesToString(mbToBytes(totalMemory))}
                        bg={'#dcf5e3'}
                        color={'#146c2e'}
                    />
                    <StatTile
                        icon={faHdd}
                        label={'Disk'}
                        value={totalDisk === 0 ? 'Unlimited' : bytesToString(mbToBytes(totalDisk))}
                        bg={'#f3e8ff'}
                        color={'#6b21a8'}
                    />
                </div>
            )}

            {rootAdmin && (
                <div css={tw`mb-2 flex justify-end items-center`}>
                    <p css={tw`uppercase text-xs text-neutral-400 mr-2`}>
                        {showOnlyAdmin ? "Showing others' servers" : 'Showing your servers'}
                    </p>
                    <Switch
                        name={'show_all_servers'}
                        defaultChecked={showOnlyAdmin}
                        onChange={() => setShowOnlyAdmin((s) => !s)}
                    />
                </div>
            )}
            {!servers ? (
                <Spinner centered size={'large'} />
            ) : (
                <Pagination data={servers} onPageSelect={setPage}>
                    {({ items: pageItems }) =>
                        pageItems.length > 0 ? (
                            <div css={tw`grid gap-5 sm:grid-cols-2 xl:grid-cols-3`}>
                                {pageItems.map((server) => (
                                    <ServerRow key={server.uuid} server={server} />
                                ))}
                            </div>
                        ) : (
                            <div className="at-empty">
                                <div className="at-empty__icon">
                                    <FontAwesomeIcon icon={faLayerGroup} css={tw`text-2xl`} />
                                </div>
                                <div className="at-empty__title">No servers yet</div>
                                <p className="at-empty__text">
                                    {showOnlyAdmin
                                        ? 'There are no other servers to display.'
                                        : 'There are no servers associated with your account. Use the Create Server button to add one.'}
                                </p>
                            </div>
                        )
                    }
                </Pagination>
            )}
        </PageContentBlock>
    );
};

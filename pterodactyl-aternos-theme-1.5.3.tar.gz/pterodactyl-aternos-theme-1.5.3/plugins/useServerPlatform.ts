import { useCallback, useEffect, useState } from 'react';

/**
 * Remembers the Minecraft version chosen for the add-on browser, per server.
 *
 * Only the version lives here. The software itself used to be part of this hook,
 * held as a "family" key that the page guessed at and the sidebar could change;
 * both are gone. Software is now read from GET /software, which reports the
 * server's real egg, so there is nothing left to guess and nothing to keep in
 * sync between two components.
 *
 * The stored shape is still `{ version }`. Values written by the older hook also
 * carried a `family` key; reading ignores it, so anyone who had a choice saved
 * keeps their version across this change and only loses the stale family field
 * on their next write.
 *
 * localStorage is per browser, not per user, so two people on the same server
 * can end up with different versions. That is deliberate: it needs no schema
 * change and no new endpoint, and the version here only filters which add-ons
 * are browsable, never where they are installed.
 */

const key = (identifier?: string) => `pterodactyl:software-version:${identifier ?? 'unknown'}`;

const read = (identifier?: string): string => {
    try {
        const parsed = JSON.parse(window.localStorage.getItem(key(identifier)) ?? '{}');

        if (parsed && typeof parsed.version === 'string') return parsed.version;
    } catch (e) {
        /* storage disabled or corrupt value */
    }

    return '';
};

export default (identifier?: string, fallback = '') => {
    const [version, setVersionState] = useState<string>(fallback);

    // Re-read whenever the server changes, so one server's version cannot leak
    // into another.
    useEffect(() => {
        setVersionState(read(identifier) || fallback);
    }, [identifier, fallback]);

    const setVersion = useCallback(
        (value: string) => {
            setVersionState(value);
            try {
                window.localStorage.setItem(key(identifier), JSON.stringify({ version: value }));
            } catch (e) {
                /* storage disabled — the value still applies to this page view */
            }
        },
        [identifier]
    );

    return { version, setVersion };
};

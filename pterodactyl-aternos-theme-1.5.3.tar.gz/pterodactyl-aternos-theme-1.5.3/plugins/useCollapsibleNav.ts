import { useCallback, useEffect, useState } from 'react';

/**
 * Desktop sidebar collapse.
 *
 * Two independent pieces of state, deliberately not merged:
 *
 *   `open`      the mobile off-canvas drawer, below 1024px
 *   `collapsed` the desktop sidebar, folded away to give content the full width
 *
 * They look similar and behave nothing alike — one overlays the content, the
 * other reflows it — and merging them produces a sidebar that is half-open at
 * one breakpoint or the other.
 *
 * The class lives on <html> so the pre-paint script in wrapper.blade.php can
 * apply it before the first frame. Applying it from React instead means the
 * sidebar renders full width and then snaps shut a moment later, on every load,
 * for anyone who chose to collapse it.
 */

const STORAGE_KEY = 'pterodactyl:nav-collapsed';
const CLASS = 'at-nav-collapsed';

/**
 * Reads the class the inline script already applied to <html>, for the same
 * reason useTheme does: the DOM is the source of truth, so the two cannot drift.
 */
const readCollapsed = (): boolean => document.documentElement.classList.contains(CLASS);

const apply = (collapsed: boolean) => {
    const root = document.documentElement;

    root.classList.toggle(CLASS, collapsed);

    try {
        window.localStorage.setItem(STORAGE_KEY, collapsed ? '1' : '0');
    } catch (e) {
        /* storage disabled — the toggle still works for this page view */
    }
};

export default () => {
    const [collapsed, setCollapsed] = useState<boolean>(readCollapsed);

    // Another component (or the pre-paint script on a bfcache restore) can change
    // it, so mirror the DOM rather than trusting local state.
    useEffect(() => {
        const observer = new MutationObserver(() => setCollapsed(readCollapsed()));
        observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });

        return () => observer.disconnect();
    }, []);

    const toggle = useCallback(() => {
        setCollapsed((current) => {
            const next = !current;
            apply(next);

            return next;
        });
    }, []);

    return { collapsed, toggle };
};

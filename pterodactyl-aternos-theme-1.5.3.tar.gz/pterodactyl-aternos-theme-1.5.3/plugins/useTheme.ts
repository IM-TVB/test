import { useCallback, useEffect, useState } from 'react';

/**
 * The panel's two themes.
 *
 * `blue` is the light one. It was called `light` until its palette went blue,
 * and the name was changed at the same time so the identifier and the colour
 * could not drift apart again. The CSS class went with it: `.aternos-theme` no
 * longer exists, so a page still carrying it gets no theme styling at all.
 */
export type Theme = 'blue' | 'dark';

const STORAGE_KEY = 'pterodactyl:theme';
const BLUE = 'aternos-blue';
const DARK = 'aternos-dark';

/**
 * The pre-rename class and stored value.
 *
 * Anyone who visited before the rename has `light` in localStorage and possibly
 * `aternos-theme` on <html>. The inline script in wrapper.blade.php clears both
 * before first paint, so by the time this module runs the DOM is already clean.
 * It is still removed in applyTheme() below, because a page restored from the
 * back/forward cache can be handed to React with the old class still on it.
 */
const LEGACY_CLASS = 'aternos-theme';
const LEGACY_VALUE = 'light';

/**
 * Reads the theme from the class the inline script already applied to <html>.
 * Reading the DOM rather than localStorage keeps the two in sync even if
 * something else changed the class.
 */
const readTheme = (): Theme => (document.documentElement.classList.contains(DARK) ? 'dark' : 'blue');

const applyTheme = (theme: Theme) => {
    const root = document.documentElement;

    root.classList.remove(BLUE, DARK, LEGACY_CLASS);
    root.classList.add(theme === 'dark' ? DARK : BLUE);

    try {
        window.localStorage.setItem(STORAGE_KEY, theme);
    } catch (e) {
        /* storage disabled — the toggle still works for this page view */
    }
};

/**
 * Normalises a stored value from any era of this panel to the current one.
 *
 * Exported for the migration test, which drives it against every value the
 * panel has ever written rather than against the happy path only.
 */
export const normalise = (stored: string | null): Theme => {
    if (stored === 'dark') return 'dark';
    if (stored === LEGACY_VALUE || stored === 'blue' || stored === null) return 'blue';

    /* An unrecognised value falls back to the default rather than throwing:
       localStorage is user-writable, so this is reachable. */
    return 'blue';
};

/**
 * Blue/dark theme toggle. The class lives on <html> so it can be applied before
 * first paint; localStorage persists the choice across reloads.
 */
export default () => {
    const [theme, setTheme] = useState<Theme>(readTheme);

    // Keep multiple components in sync if the theme changes elsewhere.
    useEffect(() => {
        const observer = new MutationObserver(() => setTheme(readTheme()));
        observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });

        return () => observer.disconnect();
    }, []);

    const toggle = useCallback(() => {
        setTheme((current) => {
            const next: Theme = current === 'dark' ? 'blue' : 'dark';
            applyTheme(next);

            return next;
        });
    }, []);

    return { theme, toggle };
};

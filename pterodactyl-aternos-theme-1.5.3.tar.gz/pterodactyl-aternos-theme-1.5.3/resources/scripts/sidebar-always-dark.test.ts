/**
 * The sidebar is dark in both modes.
 *
 * The request was one line -- "make at-sidebar always dark" -- and the
 * implementation risk is not the colours, it is someone later adding a
 * `--at-surface` to a sidebar rule and silently re-introducing a white sidebar.
 * A screenshot would not catch that, so these assertions read the stylesheet.
 *
 * The mechanism is token indirection, not a pile of overrides. The sidebar's
 * colours live in the one block that `.aternos-blue` and `.aternos-dark` share,
 * and are never redefined in either mode block. Redefining one would win on
 * specificity and light the sidebar again, so "never redefined per mode" is the
 * property worth pinning -- not the individual hex values.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const source = readFileSync(join(__dirname, 'assets/aternos.css'), 'utf8');

/**
 * Comments removed before anything is scanned.
 *
 * The sidebar tokens are documented in a comment that names them, and
 * `--at-side-*` inside prose matches a token pattern -- so an unstripped scan
 * reads a comment as a redefinition and reports a failure that does not exist.
 * The alternative, rewording the comments to avoid token-shaped text, makes the
 * documentation worse to protect a regex.
 */
const themeCss = source.replace(/\/\*[\s\S]*?\*\//g, '');

/** The sidebar and the account dropdown, which opens out of its footer. */
const chrome = (() => {
    const start = source.indexOf('/* --- Sidebar --- */');
    const end = source.indexOf('/* --- Mobile top bar');

    if (start < 0 || end < 0 || end < start) {
        throw new Error('cannot locate the sidebar span in the stylesheet');
    }

    return source.slice(start, end).replace(/\/\*[\s\S]*?\*\//g, '');
})();

const escaped = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const block = (selector: string, before = '') => {
    const found = themeCss.match(
        new RegExp(`${before}${escaped(selector)}\\s*\\{([\\s\\S]*?)\\n\\}`)
    );

    if (!found) throw new Error(`no block for ${selector}`);

    return found[1];
};

const shared = block('.aternos-blue,\n.aternos-dark');

/* The two mode blocks must be found by a selector that cannot collide with the
   shared one. The shared selector list *ends* in `.aternos-dark {`, so a plain
   search for `.aternos-dark` matches the shared block and reads all twelve
   sidebar tokens as "redefined in dark mode" -- a failure that describes nothing.
   Requiring a blank line before the selector skips the continuation line, which
   is always preceded by `.aternos-blue,`. */
const light = block('.aternos-blue', '\n\n');
const dark = block('.aternos-dark', '\n\n');

const tokensIn = (src: string) => new Set(src.match(/--at-[a-z0-9-]+/g) ?? []);
const usedInChrome = new Set(chrome.match(/var\((--at-[a-z0-9-]+)\)/g)?.map((v) => v.slice(4, -1)) ?? []);

const toRgb = (value: string): [number, number, number] => {
    const v = value.trim();

    if (v.startsWith('#')) {
        const h = v.slice(1);

        return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)) as [number, number, number];
    }

    const rgb = v.match(/rgba?\(([^)]+)\)/);
    if (rgb) {
        return rgb[1].split(',').slice(0, 3).map((x) => parseInt(x, 10)) as [number, number, number];
    }

    const hsl = v.match(/hsl\((\d+),\s*(\d+)%,\s*(\d+)%\)/);
    if (hsl) {
        const hDeg = parseInt(hsl[1], 10) / 360;
        const l = parseInt(hsl[3], 10) / 100;
        const s = parseInt(hsl[2], 10) / 100;
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        const conv = (t: number) => {
            let x = t;
            if (x < 0) x += 1;
            if (x > 1) x -= 1;
            if (x < 1 / 6) return p + (q - p) * 6 * x;
            if (x < 1 / 2) return q;
            if (x < 2 / 3) return p + (q - p) * (2 / 3 - x) * 6;

            return p;
        };

        return [
            Math.round(conv(hDeg + 1 / 3) * 255),
            Math.round(conv(hDeg) * 255),
            Math.round(conv(hDeg - 1 / 3) * 255),
        ];
    }

    throw new Error(`cannot parse colour: ${v}`);
};

const luminance = ([r, g, b]: [number, number, number]) => {
    const ch = (x: number) => {
        const v = x / 255;

        return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
    };

    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b);
};

const contrast = (a: string, b: string) => {
    const la = luminance(toRgb(a));
    const lb = luminance(toRgb(b));

    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
};

const side = (name: string): string => {
    const found = shared.match(new RegExp(`--at-side-${name}:\\s*([^;]+);`));

    if (!found) throw new Error(`no --at-side-${name} in the shared block`);

    return found[1].trim();
};

describe('the sidebar cannot follow the theme mode', () => {
    it('every sidebar token is defined in the block both modes share', () => {
        const used = [...usedInChrome].filter((t) => t.startsWith('--at-side-'));

        // Guarded first: an empty scan would make the loop below pass vacuously,
        // which is the failure mode this file exists to prevent.
        expect(used.length).toBeGreaterThan(8);

        const sharedTokens = tokensIn(shared);

        used.forEach((token) => {
            expect(sharedTokens).toContain(token);
        });
    });

    it('no sidebar token is redefined in either mode block', () => {
        // The actual guarantee. A single redefinition here would win on
        // specificity and put a light sidebar back in light mode.
        const redefined = [...tokensIn(light), ...tokensIn(dark)].filter((t) =>
            t.startsWith('--at-side-')
        );

        expect(redefined).toEqual([]);
    });

    it('the sidebar uses no mode-dependent token at all', () => {
        // The only page tokens left are deliberate: the blue focus ring and the
        // drawer shadow, both of which read correctly on a dark surface.
        const allowed = new Set(['--at-primary', '--at-shadow-lg']);
        const leaked = [...usedInChrome].filter(
            (t) => !t.startsWith('--at-side-') && !allowed.has(t)
        );

        expect(leaked).toEqual([]);
    });

    it('the token that made it light is gone', () => {
        // --at-nav-bg was #ffffff in light mode. It is what this change removed.
        expect(themeCss).not.toMatch(/--at-nav-bg:/);
        expect(themeCss).not.toMatch(/var\(--at-nav-bg\)/);
    });
});

describe('the sidebar is dark and readable', () => {
    it('the background is the dark one', () => {
        const bg = toRgb(side('bg'));
        const l = luminance(bg);

        expect(l).toBeLessThan(0.05);
    });

    it('the sidebar stands clear of a light page', () => {
        // The thing this change introduces. In dark mode the sidebar sat about
        // 1.7:1 from its own page; against a light page it has to actually read
        // as a separate surface.
        const page = light.match(/--at-page:\s*([^;]+);/)?.[1].trim() as string;

        expect(contrast(side('bg'), page)).toBeGreaterThan(4.5);
    });

    it.each([
        ['username and brand', 'text', 'bg', 4.5],
        ['menu item body', 'body', 'bg', 4.5],
        ['section heading', 'faint', 'bg', 4.5],
        ['the active link', 'active-text', 'bg', 4.5],
    ])('%s is legible on the sidebar', (_label, fg, bg, min) => {
        expect(contrast(side(fg), side(bg))).toBeGreaterThanOrEqual(min);
    });

    it('the logout hover is legible on its own tinted background', () => {
        // rgba() over the sidebar, so the backdrop has to be composited rather
        // than read straight off the token. Getting this wrong is what made an
        // earlier reading of this pair look like a failure when it was not.
        const [br, bg2, bb] = toRgb(side('bg'));
        const tint = /^rgba\(\s*(\d+),\s*(\d+),\s*(\d+),\s*([\d.]+)\s*\)/.exec(side('danger-bg'));

        expect(tint).not.toBeNull();

        const [, r, g, b, a] = tint as RegExpExecArray;
        const alpha = parseFloat(a);

        // Written out per channel rather than mapped over [0,1,2]: indexing a
        // tuple by a plain number is a type error, and the cast that silences it
        // would hide a real mistake in the three near-identical expressions.
        const over = (top: string, bottom: number) =>
            Math.round(parseInt(top, 10) * alpha + bottom * (1 - alpha));

        const composited: [number, number, number] = [over(r, br), over(g, bg2), over(b, bb)];

        const fg = toRgb(side('danger-text'));
        const la = luminance(fg);
        const lb = luminance(composited);

        expect((Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05)).toBeGreaterThanOrEqual(4.5);
    });
});

describe('the change did not spread past the sidebar', () => {
    it('the mobile top bar still follows the mode', () => {
        // The top bar sits in the content area, holds the theme toggle, and
        // should be light in light mode. It is the obvious thing to over-apply
        // this to.
        expect(themeCss).toMatch(/\.at-topbar\s*\{[^}]*background:\s*var\(--at-nav-bg-blur\)/);
    });

    it('and the toggle that lives in it still has a mode-dependent icon', () => {
        expect(themeCss).toMatch(/\.at-theme-toggle__icon\s*\{[^}]*background:\s*var\(--at-surface-3\)/);
    });

    it('the page and surface tokens are untouched by the sidebar work', () => {
        // If these ever move, something other than the sidebar is being themed.
        // Both pinned by value because the light palette has been retuned
        // repeatedly since this suite was written -- to medium contrast, then to
        // blue, then again once a screenshot showed the cards were still too
        // white for the panel to read as blue. The sidebar must still be
        // measured against the real page and the real card.
        expect(light).toMatch(/--at-page:\s*#78b1f2;/);
        expect(light).toMatch(/--at-surface:\s*#9dc4f1;/);
    });
});

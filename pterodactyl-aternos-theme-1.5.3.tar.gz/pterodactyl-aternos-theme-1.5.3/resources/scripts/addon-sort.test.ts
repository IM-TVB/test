/**
 * The merged ordering.
 *
 * The bug this guards against is specific: every source was sorted by downloads
 * correctly, and then the streams were interleaved round-robin, so the first row
 * was "Modrinth's most downloaded" rather than "the most downloaded". Asking a
 * source for one page and then re-ordering it cannot recover anything, so the
 * ordering has to be chosen before the request as well as after it.
 */
import { searchAddOns } from './api/server/plugins/providers';

jest.mock('./api/server/plugins/modrinth', () => ({
    search: jest.fn(),
    countAddonsForVersion: jest.fn(),
}));
// The upstream modules do not agree on their export name -- modrinth exports
// `search`, the others export `searchHangar` / `searchSpigot` / `searchCurseForge`
// -- so each mock has to mirror the real name. Getting this wrong resolves to
// undefined at call time, not at mock time, so the failure surfaces as an
// unrelated-looking TypeError deep inside the search function.
jest.mock('./api/server/plugins/spiget', () => ({ searchSpigot: jest.fn() }));
jest.mock('./api/server/plugins/hangar', () => ({ searchHangar: jest.fn() }));
jest.mock('./api/server/plugins/curseforge', () => ({ searchCurseForge: jest.fn() }));

import { search as searchModrinth } from './api/server/plugins/modrinth';
import { searchHangar } from './api/server/plugins/hangar';

const modrinthHit = (project_id: string, downloads: number, title = project_id) => ({
    project_id,
    title,
    description: '',
    downloads,
    icon_url: null,
    game_versions: [],
});

const hangarHit = (slug: string, downloads: number, name = slug) => ({
    slug,
    name,
    description: '',
    downloads,
    iconUrl: null,
    supportedVersions: [],
    latestVersion: null,
    installable: true,
});

const base = {
    query: '',
    loaders: [],
    gameVersion: '',
    supports: 'plugins' as const,
    limit: 20,
};

const names = (hits: { title: string }[]) => hits.map((h) => h.title);

describe('merged ordering', () => {
    beforeEach(() => jest.clearAllMocks());

    it('ranks every source together by downloads', async () => {
        // Modrinth's best is 1M, Hangar's best is 5M. Round-robin would put
        // Modrinth first; a real popularity ranking must not.
        (searchModrinth as jest.Mock).mockResolvedValue({
            hits: [modrinthHit('mr-top', 1_000_000)],
        });
        (searchHangar as jest.Mock).mockResolvedValue({ hits: [hangarHit('hg-top', 5_000_000)] });

        const { hits } = await searchAddOns({ ...base, providers: ['modrinth', 'hangar'] });

        expect(names(hits)).toEqual(['hg-top', 'mr-top']);
    });

    it('interleaves when the caller asks for a mix', async () => {
        (searchModrinth as jest.Mock).mockResolvedValue({
            hits: [modrinthHit('mr-top', 1_000_000), modrinthHit('mr-second', 900_000)],
        });
        (searchHangar as jest.Mock).mockResolvedValue({
            hits: [hangarHit('hg-top', 5_000_000), hangarHit('hg-second', 800_000)],
        });

        const { hits } = await searchAddOns({ ...base, providers: ['modrinth', 'hangar'], sort: 'mixed' });

        expect(names(hits)).toEqual(['mr-top', 'hg-top', 'mr-second', 'hg-second']);
    });

    it('sorts alphabetically by name, case-insensitively', async () => {
        (searchModrinth as jest.Mock).mockResolvedValue({
            hits: [
                modrinthHit('a', 900_000, 'Zoomify'),
                modrinthHit('b', 1_000_000, 'authMe'),
                modrinthHit('c', 10, 'LuckPerms'),
            ],
        });

        const { hits } = await searchAddOns({ ...base, providers: ['modrinth'], sort: 'name' });

        // A plain string sort would put Zoomify before authMe.
        expect(names(hits)).toEqual(['authMe', 'LuckPerms', 'Zoomify']);
    });

    it('defaults to downloads rather than the old interleave', async () => {
        (searchModrinth as jest.Mock).mockResolvedValue({ hits: [modrinthHit('mr', 10)] });
        (searchHangar as jest.Mock).mockResolvedValue({ hits: [hangarHit('hg', 99)] });

        const { hits } = await searchAddOns({ ...base, providers: ['modrinth', 'hangar'] });

        expect(names(hits)).toEqual(['hg', 'mr']);
    });

    it('treats a missing download count as zero instead of dropping the row', async () => {
        (searchModrinth as jest.Mock).mockResolvedValue({
            // Spiget and CurseForge both occasionally omit the field.
            hits: [{ ...modrinthHit('no-count', 0), downloads: undefined }, modrinthHit('has-count', 5)],
        });

        const { hits } = await searchAddOns({ ...base, providers: ['modrinth'] });

        expect(hits).toHaveLength(2);
        expect(names(hits)).toEqual(['has-count', 'no-count']);
    });

    it('asks for a most-downloaded page rather than re-ordering a relevance page', async () => {
        // With no query, Modrinth must be asked for its popular page.
        (searchModrinth as jest.Mock).mockResolvedValue({ hits: [] });
        (searchHangar as jest.Mock).mockResolvedValue({ hits: [] });

        await searchAddOns({ ...base, providers: ['modrinth', 'hangar'] });

        expect((searchModrinth as jest.Mock).mock.calls[0][1]).toMatchObject({ sort: 'downloads' });
        expect((searchHangar as jest.Mock).mock.calls[0][1]).toMatchObject({ sort: 'downloads' });
    });

    it('falls back to relevance when a query is typed', async () => {
        // "luck perms" should surface LuckPerms, not whichever plugin happens to
        // have the most downloads, so relevance wins even though the merged list
        // is ordered by downloads.
        (searchModrinth as jest.Mock).mockResolvedValue({ hits: [] });
        (searchHangar as jest.Mock).mockResolvedValue({ hits: [] });

        await searchAddOns({ ...base, query: 'luck perms', providers: ['modrinth', 'hangar'] });

        expect((searchModrinth as jest.Mock).mock.calls[0][1]).toMatchObject({ sort: 'relevance' });
    });

    it('still reports a source that failed', async () => {
        (searchModrinth as jest.Mock).mockResolvedValue({ hits: [modrinthHit('mr', 10)] });
        (searchHangar as jest.Mock).mockRejectedValue(new Error('down'));

        const { hits, failed } = await searchAddOns({ ...base, providers: ['modrinth', 'hangar'] });

        // A plain Error() with no response and no navigator, which is what a jest
        // rejection looks like. Classified as 'blocked' because nothing answered
        // and the device is notionally online -- the same shape a browser-side
        // blocker produces.
        expect(failed).toEqual([{ provider: 'hangar', reason: 'blocked' }]);
        expect(names(hits)).toEqual(['mr']);
    });

    it('distinguishes a source that answered with an error', async () => {
        const refused: any = new Error('upstream 503');
        refused.response = { status: 503 };

        (searchModrinth as jest.Mock).mockResolvedValue({ hits: [modrinthHit('mr', 10)], total: 1 });
        (searchHangar as jest.Mock).mockRejectedValue(refused);

        const { failed } = await searchAddOns({ ...base, providers: ['modrinth', 'hangar'] });

        // The reason is the whole point of the shape: "could not be reached" and
        // "answered 503" need opposite responses from the reader.
        expect(failed).toEqual([{ provider: 'hangar', reason: 'refused', status: 503 }]);
    });
});

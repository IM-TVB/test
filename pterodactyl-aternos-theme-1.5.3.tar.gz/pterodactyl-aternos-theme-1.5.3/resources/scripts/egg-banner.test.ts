/**
 * The per-egg server card banner.
 *
 * Three files have to agree for a banner to appear: the admin form that uploads
 * it, the transformer that tells the client about it, and the card that paints
 * it. Any one of them being wrong looks identical from the outside -- a card
 * with its gradient and no indication why -- so these assertions are mostly
 * about the joins rather than about any single file.
 *
 * The `background` shorthand is the specific thing worth pinning. It has now
 * broken this feature twice in two different places: the panel background, and
 * this card. It resets every background longhand it does not mention, so a
 * banner written that way disappears with no error.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

/**
 * __dirname is <root>/resources/scripts, so the PHP and Blade files this suite
 * reads are two levels up, not one. Expressed as a helper rather than as
 * scattered '../../' so the depth is stated once.
 */
const root = (p: string) => readFileSync(join(__dirname, '..', '..', p), 'utf8');
const read = (p: string) => readFileSync(join(__dirname, p), 'utf8');

const transformer = root('app/Transformers/Api/Client/ServerTransformer.php');
const eggController = root('app/Http/Controllers/Admin/Nests/EggController.php');
const eggView = root('resources/views/admin/eggs/view.blade.php');
const service = root('app/Services/Settings/EggBannerService.php');
const routes = root('routes/admin.php');
const getServer = read('api/server/getServer.ts');
const serverRow = read('components/dashboard/ServerRow.tsx');

describe('the admin can set a banner for any egg', () => {
    it('the egg page offers the upload', () => {
        expect(eggView).toContain("route('admin.nests.egg.banner'");
        expect(eggView).toContain('name="banner"');
    });

    it('on a form that is actually multipart', () => {
        // The Configuration form on the same page is not multipart. A file input
        // added to that one would look correct and upload nothing.
        const form = eggView.slice(eggView.indexOf("route('admin.nests.egg.banner'") - 200);

        expect(form.slice(0, 400)).toContain('enctype="multipart/form-data"');
    });

    it('and a way to remove it', () => {
        expect(eggView).toContain("route('admin.nests.egg.banner.remove'");
        expect(eggView).toContain('@method(\'DELETE\')');
    });

    it('the remove button only appears when there is something to remove', () => {
        // Offering "remove" for a banner that does not exist produces an error
        // message instead of doing nothing, which reads as a broken page.
        const remove = eggView.slice(eggView.indexOf("route('admin.nests.egg.banner.remove'") - 60);

        expect(remove.slice(0, 60)).toContain('@if($banner)');
    });

    it('the routes exist and are the egg\'s own', () => {
        expect(routes).toContain("'/egg/{egg:id}/banner'");
        expect(routes).toContain('admin.nests.egg.banner');
        expect(routes).toContain('admin.nests.egg.banner.remove');
    });

    it('deleting an egg takes its banner with it', () => {
        // The setting row and the file are keyed by egg id. Once the egg is gone
        // nothing else can resolve that id, so this has to happen in destroy().
        const destroy = eggController.slice(eggController.indexOf('public function destroy'));

        expect(destroy.slice(0, 400)).toContain('banners->remove');
    });
});

describe('the client is told about it', () => {
    it('the transformer sends a banner for every server', () => {
        // Sent with the list the card is already rendering. A per-card fetch
        // would mean a request per server on the dashboard.
        expect(transformer).toContain("'egg_banner' =>");
        expect(transformer).toContain('EggBannerService');
    });

    it('keyed on the egg, not the server', () => {
        // A per-server banner would be a different feature. This one is per egg,
        // so the lookup has to be the egg's id.
        expect(transformer).toMatch(/url\(\$server->egg_id\)/);
    });

    it('and the frontend type says it can be absent', () => {
        expect(getServer).toContain('eggBanner: string | null;');
    });

    it('the normaliser preserves null rather than coercing it', () => {
        // `|| ''` would turn an absent banner into an empty string, and the card
        // would ask the browser to load an image from the current page's URL.
        const line = getServer.split('\n').find((l) => l.includes('eggBanner: typeof'));

        expect(line).toBeDefined();
        expect(line).toContain(': null');
        expect(line).not.toContain("|| ''");
    });
});

describe('the card paints it without losing its fallback', () => {
    it('uses backgroundImage, never a background shorthand, when a banner exists', () => {
        // The shorthand resets every background longhand it does not mention, so
        // writing the image that way removes the image. This has bitten twice.
        const style = serverRow.slice(serverRow.indexOf('const bannerStyle'));

        expect(style).toContain('backgroundImage:');
        // A plain substring, not a regex: the shorthand appears as
        // `: { background: gradient }` on the fallback branch, which is correct,
        // so what is forbidden is the shorthand on the *banner* branch.
        expect(style).not.toContain(': {\n              background: url(');
        expect(style).not.toMatch(/banner\s*\?\s*\{\s*background:\s*url/);
    });

    it('layers the image over the gradient rather than replacing it', () => {
        const style = serverRow.slice(serverRow.indexOf('const bannerStyle'));

        // Two layers, so a banner that 404s or is still loading leaves the
        // gradient visible instead of an empty bar.
        expect(style).toContain('${gradient}');
        expect(style).toMatch(/url\("\$\{banner\}"\), \$\{gradient\}/);
    });

    it('still generates a gradient when no banner is set', () => {
        const style = serverRow.slice(serverRow.indexOf('const bannerStyle'));

        expect(style).toMatch(/:\s*\{\s*background:\s*gradient\s*\}/);
    });

    it('and the gradient is derived per server, as before', () => {
        // The hue seeding is what makes each card distinct when no egg banner
        // exists. It must not have been replaced by a single flat colour.
        expect(serverRow).toContain('const hue = seed % 360;');
    });
});

describe('the service is what makes the url safe to hand out', () => {
    it('the filename is a content hash prefixed with the egg id', () => {
        // The prefix is what lets remove() find an orphan from an older name, and
        // the hash is what busts caches when the image is replaced.
        expect(service).toContain(
            "\$this->imageName(\$sourcePath, \$probe['ext'], (string) \$eggId)"
        );
    });

    it('and the stored name is shape-checked before it becomes a url', () => {
        // The card puts this straight into a style attribute. Without the check, a
        // hand-edited settings row could put arbitrary CSS in front of every
        // visitor who sees a server on that egg.
        expect(service).toContain('isSafeImageName($file, (string) $eggId)');
    });

    it('a file deleted out from under it yields no url', () => {
        // Then the card falls back to its gradient rather than showing a broken
        // image icon.
        expect(service).toMatch(/isSafeImageName\(\$file, \(string\) \$eggId\)[^\n]*\n?[^\n]*!is_file/);
    });
});

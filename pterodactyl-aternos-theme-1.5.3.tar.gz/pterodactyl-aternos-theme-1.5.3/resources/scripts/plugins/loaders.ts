/**
 * Which add-on platforms a given server software can load.
 *
 * This is a lookup table and a string match, and it lives in its own module for
 * two reasons. It is the thing that decides whether a search result is shown at
 * all, so it needs to be readable and testable on its own; and when it lived
 * inside a component, importing it into a test pulled the component's whole
 * Babel pipeline in with it, which is why the waterfall entry below went
 * untested for as long as it was missing.
 *
 * The table's job is to answer "which of Modrinth's platform categories would a
 * plugin have to declare to be loadable here". An EMPTY answer is not "unknown,
 * show everything" by accident -- it is a real state, and the filter treats it
 * as standing down, because there is no right answer for a software nobody has
 * heard of. That makes a missing entry dangerous rather than harmless: a known
 * software absent from this table gets the empty answer, and the filter switches
 * off. Every software the panel offers must appear below.
 */

/** Software name (lower case) to the Modrinth loader categories it accepts. */
const LOADERS_BY_SOFTWARE: Record<string, string[]> = {
    paper: ['paper', 'spigot', 'bukkit'],
    spigot: ['spigot', 'bukkit'],
    purpur: ['purpur', 'paper', 'spigot', 'bukkit'],
    bungeecord: ['bungeecord', 'velocity'],
    // Waterfall is a Bungeecord fork and its plugins carry categories:waterfall.
    // It was missing here AND from KNOWN_LOADERS, so loadersFor('Waterfall')
    // resolved to [] and a Waterfall proxy was shown every Bukkit plugin as
    // installable. Its own category is listed first so the fork's is preferred.
    waterfall: ['waterfall', 'bungeecord'],
    velocity: ['velocity'],
    sponge: ['sponge'],
    // Modrinth has no `leaf` loader category -- querying categories:leaf returns
    // zero hits -- so a Leaf server is filtered by the loaders its plugins
    // actually declare. Leaf is a Paper fork that ships every Purpur patch and
    // the full Paper API, so all four categories are correct here.
    leaf: ['paper', 'spigot', 'bukkit', 'purpur'],
    forge: ['forge'],
    neoforge: ['neoforge'],
    fabric: ['fabric'],
    quilt: ['quilt'],
};

/**
 * Loader categories, used to recover a mapping for a software whose name is not
 * in the table -- an egg this panel has never seen, or a renamed fork.
 */
const KNOWN_LOADERS = [
    'paper', 'spigot', 'bukkit', 'purpur', 'bungeecord', 'velocity', 'waterfall',
    'sponge', 'forge', 'neoforge', 'fabric', 'quilt',
];

/**
 * The loader categories this software accepts, or [] when it is not recognised.
 *
 * A substring scan rather than an exact match, so "Purpur 1.20" and "paper-1.20"
 * both resolve without an entry each.
 */
export const loadersFor = (name: string): string[] => {
    const direct = LOADERS_BY_SOFTWARE[name.trim().toLowerCase()];

    if (direct) {
        return direct;
    }

    const lower = name.toLowerCase();

    return KNOWN_LOADERS.filter((loader) => lower.includes(loader));
};

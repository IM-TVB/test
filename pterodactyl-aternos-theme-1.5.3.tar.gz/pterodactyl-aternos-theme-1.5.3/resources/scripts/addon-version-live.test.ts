/**
 * Runs the real fit pass against the live APIs, with no mocks.
 *
 * The unit tests use fixtures shaped like what the sources return, which is only
 * as good as my reading of them. This asks Modrinth for the same version list the
 * picker now asks for, runs the real logic over it, and prints what a Leaf
 * 1.21.11 server would be recommended.
 *
 * Run: npx jest addon-version-live --testPathPattern=addon-version-live
 */

import { versionsFor } from '@/api/server/plugins/providers';
import { ModrinthHit } from '@/api/server/plugins/modrinth';

jest.setTimeout(120_000);

const LEAF: { loaders: string[]; gameVersions: string[] } = {
    // loadersFor('leaf')
    loaders: ['paper', 'spigot', 'bukkit', 'purpur'],
    gameVersions: ['1.21.11'],
};

const projects = [
    { slug: 'luckperms', name: 'LuckPerms' },
    { slug: 'worldedit', name: 'WorldEdit' },
    { slug: 'viaversion', name: 'ViaVersion' },
    { slug: 'viabackwards', name: 'ViaBackwards' },
    { slug: 'geyser', name: 'Geyser' },
    { slug: 'essentialsx', name: 'EssentialsX' },
    { slug: 'placeholderapi', name: 'PlaceholderAPI' },
];

/**
 * Asked directly rather than through versionsFor, which swallows its own errors.
 * versionsFor returning [] means two very different things -- "this project has
 * no versions" and "the network is down" -- and only the first is a failure of
 * the logic under test. Without this the suite goes red whenever Modrinth is
 * briefly unreachable, and a red suite gets ignored, which costs more than it
 * buys.
 */
const reachable = async (): Promise<boolean> => {
    try {
        // No User-Agent, deliberately. It is on the Fetch spec's forbidden header
        // list, so a browser silently drops it and axios reports "Headers
        // User-Agent forbidden" -- the exact bug that shipped the Spigot provider
        // broken, because the integration test ran in Node where the header is
        // allowed. fetch-headers.test.ts enforces this across the tree.
        const res = await fetch('https://api.modrinth.com/v2/project/luckperms');

        return res.ok;
    } catch {
        return false;
    }
};

describe('what a Leaf 1.21.11 server is actually offered', () => {
    it('recommends a build for this platform and this Minecraft version', async () => {
        if (!(await reachable())) {
            // eslint-disable-next-line no-console
            console.log('      SKIPPED: api.modrinth.com is not answering, so this says nothing about the logic');
            return;
        }

        const report: string[] = [];

        for (const project of projects) {
            const versions = await versionsFor(
                {
                    key: `modrinth:${project.slug}`,
                    provider: 'modrinth',
                    title: project.name,
                    description: '',
                    downloads: 0,
                    iconUrl: null,
                    raw: { project_id: project.slug } as ModrinthHit,
                    projectId: project.slug,
                },
                LEAF
            );
            const recommended = versions.find((v) => v.recommended);

            // eslint-disable-next-line no-console
            console.log(
                `      ${project.name.padEnd(15)} ${String(versions.length).padStart(3)} versions  ` +
                    `recommended: ${recommended ? recommended.version : '(none)'}` +
                    (recommended && recommended.unavailableReason ? `  !! ${recommended.unavailableReason}` : '')
            );

            report.push(project.name);

            if (versions.length === 0) {
                throw new Error(`${project.name}: no versions at all`);
            }

            if (!recommended) {
                throw new Error(`${project.name}: nothing recommended`);
            }

            // The whole point: the recommendation has to be installable, and
            // installable means "runs here".
            if (!recommended.installable) {
                throw new Error(
                    `${project.name}: recommended ${recommended.version} but it is not installable -- ` +
                        `${recommended.unavailableReason}`
                );
            }
        }

        expect(report).toHaveLength(projects.length);
    });
});

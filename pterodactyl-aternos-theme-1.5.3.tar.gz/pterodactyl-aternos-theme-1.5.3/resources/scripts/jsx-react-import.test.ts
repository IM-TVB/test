/**
 * Every .tsx file that contains real JSX must have `React` bound in scope.
 *
 * This panel compiles JSX with the classic runtime, so `<div/>` lowers to
 * React.createElement(). A file that imports only named hooks
 * (`import { useState } from 'react'`) type-checks and bundles cleanly, then
 * throws "ReferenceError: React is not defined" at runtime -- which
 * ErrorBoundary renders as "An error was encountered by the application while
 * rendering this view. Try refreshing the page." Neither tsc nor webpack
 * catches it; it only appears in a browser.
 *
 * That exact omission shipped on the Plugins & Mods page, so it is asserted
 * here instead of being left to be rediscovered.
 *
 * JSX is located with the TypeScript AST rather than a regex: a pattern like
 * /<[A-Za-z][\w.]*[\s/>]/ also matches generics such as styled.input<Props> and
 * flagged two element files that contain no JSX at all.
 */
import { readdirSync, readFileSync, statSync } from 'fs';
import { join } from 'path';
import * as ts from 'typescript';

const ROOT = __dirname;
const SKIP = new Set(['node_modules', 'dist', 'build']);

/**
 * True when the file contains a JSX element AND the default React binding.
 * `import * as React` counts: a namespace import does bind the identifier.
 */
const bindsReact = (source: string): boolean =>
    /^import\s+(\*\s+as\s+React|React\b)[\s\S]*?from\s+['"]react['"]/m.test(source);

const walk = (dir: string, out: string[] = []): string[] => {
    for (const entry of readdirSync(dir)) {
        if (SKIP.has(entry)) continue;
        const full = join(dir, entry);
        if (statSync(full).isDirectory()) {
            walk(full, out);
        } else if (full.endsWith('.tsx')) {
            out.push(full);
        }
    }

    return out;
};

const containsJsx = (source: string, file: string): boolean => {
    const ast = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
    let found = false;

    const visit = (node: ts.Node) => {
        if (found) return;
        if (ts.isJsxElement(node) || ts.isJsxSelfClosingElement(node) || ts.isJsxFragment(node)) {
            found = true;
            return;
        }
        ts.forEachChild(node, visit);
    };

    visit(ast);

    return found;
};

describe('JSX files bind React', () => {
    const files = walk(ROOT);
    const offenders: string[] = [];
    let withJsx = 0;

    it('finds tsx files and some of them contain JSX', () => {
        for (const file of files) {
            if (!containsJsx(readFileSync(file, 'utf8'), file)) continue;
            withJsx += 1;
            if (!bindsReact(readFileSync(file, 'utf8'))) {
                offenders.push(file.replace(ROOT, ''));
            }
        }

        expect(files.length).toBeGreaterThan(0);
        // Guards the detector itself: if this drops to zero the AST walk is
        // broken and the test below would pass vacuously.
        expect(withJsx).toBeGreaterThan(10);
    });

    it('no tsx file with JSX is missing a React binding', () => {
        expect(offenders).toEqual([]);
    });
});

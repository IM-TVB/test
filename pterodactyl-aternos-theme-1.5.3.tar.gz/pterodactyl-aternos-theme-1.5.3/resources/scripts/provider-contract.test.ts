/**
 * The provider ids the panel reports must be the ones the client understands.
 *
 * This is a contract across two languages with no shared type: the ids come from
 * ProviderKeyService::PROVIDERS (PHP) and the union from providers.ts (TypeScript).
 * Nothing in the compiler connects them, and the failure is silent and odd --
 * when the service said "spiget" and the client expected "spigot", the provider
 * was reported as available and then quietly filtered out of the client's list,
 * leaving a chip that rendered but was switched off. So the sets are compared
 * here by reading both files.
 */
import { readFileSync } from 'fs';
import { join } from 'path';

// __dirname is resources/scripts, so two levels up is the panel root.
const panelRoot = join(__dirname, '..', '..');

const serviceSource = readFileSync(
    join(panelRoot, 'app/Services/Plugins/ProviderKeyService.php'),
    'utf8'
);

const clientSource = readFileSync(join(__dirname, 'api/server/plugins/providers.ts'), 'utf8');

// Matches the key of each entry only. The first version of this expected
// `=> ['name'` on the same line, which silently dropped a provider because
// that entry is written across several lines -- so the parser read the service
// as having three providers and reported a mismatch that did not exist.
const serviceIds = [...serviceSource.matchAll(/^\s{8}'([a-z]+)' => \[/gm)].map((m) => m[1]);
const clientUnion = /export type Provider =([^;]+);/.exec(clientSource);
const clientIds = [...(clientUnion?.[1] ?? '').matchAll(/'([a-z]+)'/g)].map((m) => m[1]);

describe('plugin provider contract', () => {
    it('parses both sides of the contract', () => {
        expect(serviceIds.length).toBeGreaterThan(2);
        expect(clientIds.length).toBeGreaterThan(2);
    });

    it('the panel reports exactly the providers the client knows', () => {
        expect([...serviceIds].sort()).toEqual([...clientIds].sort());
    });

    it('the names line up too, so a chip cannot be labelled from the wrong entry', () => {
        for (const id of serviceIds) {
            const name = new RegExp(`'${id}' => \\[[\\s\\S]{0,120}?'name' => '([^']+)'`).exec(serviceSource);
            expect(name).not.toBeNull();
            expect(name![1]).toBeTruthy();
        }
    });
});

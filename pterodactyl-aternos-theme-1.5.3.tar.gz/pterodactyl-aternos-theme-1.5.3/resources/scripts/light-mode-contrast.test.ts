/**
 * Light-mode contrast, measured rather than eyeballed.
 *
 * Both faults here were invisible in code review and obvious on screen. The
 * numbers come from sampling a screenshot of this panel's console, so they are
 * what a user actually saw -- not what the stylesheet appears to promise.
 *
 *   console status card label   #cad1d8 on #f8fafc   1.47:1   FAIL
 *   console status card value   #7b8793 on #f8fafc   3.50:1   large text only
 *   chart cards                 #515f6c on a #f4f6f9 page -- a dark block
 *
 * WCAG AA wants 4.5:1 for body text and 3:1 for large text.
 *
 * The root cause of the first is structural rather than a wrong hex:
 * tailwind.config.js registers ONE palette under both names (`gray: gray,
 * neutral: gray`), so `text-gray-200` and `text-neutral-200` are the same colour
 * written two ways -- but they are two different classes, and only the `neutral`
 * spelling was remapped for light mode. So this asserts the two spellings stay
 * in step, which is the property that actually broke.
 */

import { readdirSync, readFileSync } from 'fs';
import { join } from 'path';

const themeCss = readFileSync(join(__dirname, 'assets/aternos.css'), 'utf8');

/* Block extraction for the tests that need to compare modes.
   The `\n\n` prefix is load-bearing: the shared selector list *ends* in
   `.aternos-dark {`, so an unanchored search for the dark block returns the
   shared one, and every "dark is unchanged" assertion then passes against the
   wrong tokens. */
const cssForMode = (selector: string, before = '') => {
    const escaped = selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const found = themeCss.match(new RegExp(`${before}${escaped}\\s*\\{([\\s\\S]*?)\\n\\}`));

    if (!found) throw new Error(`no block for ${selector}`);

    return found[1];
};

// The two mode blocks need the `\n\n` guard; the shared one is preceded by the
// file's header comment instead, so it is matched plainly -- its full selector
// is unique either way.
const darkBlock = cssForMode('.aternos-dark', '\\n\\n');
const sharedBlock = cssForMode('.aternos-blue,\n.aternos-dark');
const consoleCss = readFileSync(
    join(__dirname, 'components/server/console/style.module.css'),
    'utf8'
);

/** The light-mode token values, so the test tracks the palette rather than a copy. */
function token(name: string): string {
    const light = themeCss.match(/\.aternos-blue \{([\s\S]*?)\n\}/);
    if (!light) throw new Error('no .aternos-blue token block');

    const found = light[1].match(new RegExp(`--at-${name}:\\s*([^;]+);`));
    if (!found) throw new Error(`no --at-${name} in the light block`);

    return found[1].trim();
}

function toRgb(value: string): [number, number, number] {
    const v = value.trim();

    if (v.startsWith('#')) {
        const h = v.slice(1);

        return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)) as [number, number, number];
    }

    const hsl = v.match(/hsl\((\d+),\s*(\d+)%,\s*(\d+)%\)/);
    if (hsl) {
        // LCH-free conversion is unnecessary here; a plain HSL round trip is
        // enough because the test only compares against other tokens.
        const hDeg = parseInt(hsl[1], 10) / 360;
        const l = parseInt(hsl[3], 10) / 100;
        const s = parseInt(hsl[2], 10) / 100;

        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;

        const conv = (t: number) => {
            let v2 = t;
            if (v2 < 0) v2 += 1;
            if (v2 > 1) v2 -= 1;
            if (v2 < 1 / 6) return p + (q - p) * 6 * v2;
            if (v2 < 1 / 2) return q;
            if (v2 < 2 / 3) return p + (q - p) * (2 / 3 - v2) * 6;

            return p;
        };

        return [
            Math.round(conv(hDeg + 1 / 3) * 255),
            Math.round(conv(hDeg) * 255),
            Math.round(conv(hDeg - 1 / 3) * 255),
        ];
    }

    const rgb = v.match(/rgba?\(([^)]+)\)/);
    if (rgb) {
        return rgb[1].split(',').slice(0, 3).map((x) => parseInt(x, 10)) as [number, number, number];
    }

    throw new Error(`cannot parse colour: ${v}`);
}

const luminance = ([r, g, b]: [number, number, number]) => {
    const ch = (x: number) => {
        const v = x / 255;

        return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
    };

    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b);
};

const contrast = (a: string, b: string) => {
    const la = luminance(toRgb(a));
    const lb = luminance(toRgb(b));
    const hi = Math.max(la, lb);
    const lo = Math.min(la, lb);

    return (hi + 0.05) / (lo + 0.05);
};

describe('light-mode text contrast', () => {
    const surface2 = token('surface-2');

    it('the console card label is readable', () => {
        // Was #cad1d8 on #f8fafc = 1.47:1, from text-gray-200 unmapped.
        expect(contrast(token('text-body'), surface2)).toBeGreaterThanOrEqual(4.5);
    });

    it('the console card value is readable', () => {
        // Was #7b8793 on #f8fafc = 3.50:1, from text-gray-50 unmapped.
        expect(contrast(token('text'), surface2)).toBeGreaterThanOrEqual(4.5);
    });

    it('muted text still clears large-text contrast', () => {
        expect(contrast(token('text-muted'), surface2)).toBeGreaterThanOrEqual(3);
    });
});

describe('the gray and neutral spellings stay in step', () => {
    // The structural fault. tailwind.config.js aliases one palette to both
    // names, so each pair must be remapped together or one spelling keeps its
    // dark-mode value on a light page.
    const pairs: [string, string][] = [
        ['100', '100'],
        ['200', '200'],
        ['300', '300'],
        ['400', '400'],
        ['500', '500'],
    ];

    it.each(pairs)('text-gray-%s and text-neutral-%s are both remapped', (grayStep, neutralStep) => {
        const gray = new RegExp(`\\.aternos-blue \\.text-gray-${grayStep}\\s*\\{`);
        const neutral = new RegExp(`\\.aternos-blue \\.text-neutral-${neutralStep}\\s*\\{`);

        expect(themeCss).toMatch(gray);
        expect(themeCss).toMatch(neutral);
    });

    it('every text-gray-* step the panel actually uses is covered', () => {
        // If someone adds text-gray-600 to a component, this is what catches it.
        // Recursive, because most of them live two or three directories down
        // (components/server/console/StatBlock.tsx, not components/).
        const used = new Set<string>();

        const walk = (dir: string): void => {
            let entries: import('fs').Dirent[];
            try {
                entries = readdirSync(dir, { withFileTypes: true });
            } catch {
                return;
            }

            entries.forEach((entry) => {
                const full = join(dir, entry.name);
                if (entry.isDirectory()) {
                    walk(full);

                    return;
                }

                if (!/\.tsx?$/.test(entry.name)) {
                    return;
                }

                const src = readFileSync(full, 'utf8');
                (src.match(/text-gray-\d{2,3}/g) ?? []).forEach((m) => used.add(m));
            });
        };

        walk(join(__dirname, 'components'));
        walk(join(__dirname, 'plugins'));
        walk(join(__dirname, 'api'));

        // Asserted before the loop: an empty scan would make every expectation in
        // it pass vacuously, which is the failure mode this whole file exists to
        // avoid.
        expect(used.size).toBeGreaterThan(3);

        const uncovered = [...used].filter(
            (cls) => !new RegExp(`\\.aternos-blue \\.${cls}\\s*\\{`).test(themeCss)
        );

        expect(uncovered).toEqual([]);
    });
});

describe('the chart cards are not baked to one palette', () => {
    // @apply inlines the colour, so no bg-gray-600 class reaches the DOM for a
    // light-mode override to catch. That is why these three cards were #515f6c --
    // the panel's own gray-600 -- sitting on a white page as dark blocks.
    it('uses theme tokens rather than a palette name', () => {
        expect(consoleCss).toMatch(/background-color:\s*var\(--at-surface\)/);
        expect(consoleCss).toMatch(/border-color:\s*var\(--at-border-strong\)/);
    });

    it('no longer applies a fixed gray background', () => {
        expect(consoleCss).not.toMatch(/\.chart_container\s*\{[^}]*bg-gray-600/);
    });

    it('the terminal stays dark, which is correct and must not be themed away', () => {
        // A terminal is dark in both modes, like the search bar. Themed "fixed"
        // along with the cards it would become unreadable.
        //
        // Asserted as "the container's own background is not a theme surface",
        // not merely "bg-black is still mentioned" -- a later declaration in the
        // same rule wins, so @apply bg-black can be present and overridden, and
        // checking only for the @apply would pass either way.
        // Sliced between two landmarks rather than brace-matched: this file
        // indents in 4-space steps and `.chart_container` sits at column 0, so
        // any assumption about where a closing brace lands is a guess.
        const start = consoleCss.indexOf('& > .container {');
        const end = consoleCss.indexOf('& #terminal', start);

        expect(start).toBeGreaterThan(-1);
        expect(end).toBeGreaterThan(start);

        const terminalBlock = consoleCss.slice(start, end);
        expect(terminalBlock).not.toMatch(/background[^:]*:\s*var\(--at-surface/);
        expect(terminalBlock).toMatch(/@apply[^;]*bg-black/);
    });
});

describe('the light palette sits in the medium-contrast band', () => {
    // A deliberate choice, made after measuring the previous setting: text at
    // 17.85:1 on surfaces 1.08:1 from the page. Harsh where it carried
    // information, invisible where it separated surfaces. The bands below are
    // what "medium" means here, so a later tweak cannot quietly drift back to
    // either near-black-on-white or an unreadable grey-on-grey.

    const surface = token('surface');

    it('text is readable but no longer near-black', () => {
        const r = contrast(token('text'), surface);

        // Was 17.85:1. Above 14 and the old harshness is back; below 7 and the
        // primary text has stopped being primary.
        expect(r).toBeGreaterThanOrEqual(7);
        expect(r).toBeLessThanOrEqual(14);
    });

    it('body and muted text both meet AA', () => {
        expect(contrast(token('text-body'), surface)).toBeGreaterThanOrEqual(4.5);
        expect(contrast(token('text-muted'), surface)).toBeGreaterThanOrEqual(4.5);
    });

    it('each step of the ramp is distinguishable from the one below it', () => {
        // The old ramp had body and muted only a shade apart in practice, which
        // is why the console cards read as one undifferentiated grey.
        const steps = ['text', 'text-body', 'text-muted', 'text-faint'];

        for (let i = 0; i < steps.length - 1; i++) {
            expect(contrast(token(steps[i]), token(steps[i + 1]))).toBeGreaterThanOrEqual(1.25);
        }
    });

    it('borders are actually visible against a card', () => {
        // Was 1.22:1. A boundary nobody can see is not a boundary.
        expect(contrast(token('border'), surface)).toBeGreaterThanOrEqual(1.25);
        expect(contrast(token('border-strong'), surface)).toBeGreaterThanOrEqual(1.45);
    });
});

describe('the remap sections hold no stray palette values', () => {
    // When the light palette was retuned, several rules still hardcoded the old
    // values -- `.text-neutral-200` and `.text-neutral-800` were both pinned to
    // #1f2937 -- so the old near-black survived in whichever component used them
    // while the tokens said something else. They are all tokens now.
    const section = (() => {
        const start = themeCss.indexOf('3. TEXT remap');
        const borders = themeCss.indexOf('5. BORDER remap');
        const end = themeCss.indexOf('/* ---', borders);

        if (start < 0 || borders < 0 || end < 0) {
            throw new Error('cannot locate the remap sections');
        }

        // Comments stripped for the same reason as everywhere else: prose that
        // quotes a hex reads as a value.
        return themeCss.slice(start, end).replace(/\/\*[\s\S]*?\*\//g, '');
    })();

    it('the only literals left are the deliberately-dark backgrounds', () => {
        const found = [...new Set(section.match(/#[0-9a-f]{3,6}\b/gi) ?? [])].map((h) =>
            h.toLowerCase()
        );

        // #0f172a and #e5e7eb are the code-chip and .bg-black backgrounds, which
        // are meant to stay dark in light mode.
        expect(found.sort()).toEqual(['#0f172a', '#e5e7eb']);
    });

    it('nothing in the text remap is a literal at all', () => {
        const text = (() => {
            const start = themeCss.indexOf('3. TEXT remap');
            const end = themeCss.indexOf('4. SURFACE remap');

            return themeCss.slice(start, end).replace(/\/\*[\s\S]*?\*\//g, '');
        })();

        expect(text).not.toMatch(/#[0-9a-f]{3,6}\b/i);
    });
});

describe('light mode is blue, not grey', () => {
    // The request was a blue light mode, replacing the grey one. Every
    // accessibility assertion above would still pass on a grey palette, so none
    // of them notice if the blue is quietly removed -- these do.
    const hueOf = (value: string) => {
        const [r, g, b] = toRgb(value).map((c) => c / 255) as [number, number, number];
        const max = Math.max(r, g, b);
        const min = Math.min(r, g, b);
        const d = max - min;

        if (d === 0) return -1;   // fully achromatic: no hue at all

        let h: number;
        if (max === r) h = ((g - b) / d) % 6;
        else if (max === g) h = (b - r) / d + 2;
        else h = (r - g) / d + 4;

        h *= 60;

        return h < 0 ? h + 360 : h;
    };

    const chromaOf = (value: string) => {
        const [r, g, b] = toRgb(value);
        const max = Math.max(r, g, b);
        const min = Math.min(r, g, b);

        return max === 0 ? 0 : (max - min) / max;
    };

    // The page, the borders and the text all have to be blue. The card is
    // excluded: it is near-white on purpose, and a blue card on a blue page
    // would flatten the whole thing.
    // Per-layer chroma floors, not one blanket number. The floors say what each
    // layer is FOR: the page and the card carry the theme's colour, the borders
    // must still read as lines, the text is navy. A single floor either fails
    // the lighter layers or lets the darker ones stay grey.
    //
    // `surface` was deliberately absent from this list until a screenshot of the
    // console showed the panel reading as white with blue in the gaps: the
    // cards cover most of the viewport, so a near-white card left only about 7%
    // of the visible page blue. It is now held to a floor like any other layer.
    // Floors raised twice, both times because a screenshot showed the blue was
    // too weak to read: first from "no chroma" to "some", then from "some" to
    // these. A pale wash fails every one of them.
    const layers: [string, string, number][] = [
        ['page', 'page', 0.3],
        ['surface', 'surface', 0.25],
        ['surface-2', 'surface-2', 0.25],
        ['surface-3', 'surface-3', 0.25],
        ['border', 'border', 0.3],
        ['border-strong', 'border-strong', 0.35],
        ['text', 'text', 0.4],
        ['text-body', 'text-body', 0.4],
        ['text-muted', 'text-muted', 0.4],
        ['text-faint', 'text-faint', 0.4],
    ];

    it.each(layers)('%s sits in the blue hue range', (_label, name, _floor) => {
        const h = hueOf(token(name));

        expect(h).toBeGreaterThan(190);
        expect(h).toBeLessThan(250);
    });

    it.each(layers)('%s is not actually grey', (_label, name, floor) => {
        // Hue alone is not enough: a colour with 0.5% chroma technically has a
        // hue and still looks grey.
        expect(chromaOf(token(name))).toBeGreaterThanOrEqual(floor);
    });

    it('the card is blue too, so the panel reads blue', () => {
        // Reversed twice. The first version asserted the card stayed near-white,
        // which produced a panel measuring 7% blue; the second allowed 7% chroma
        // and still read as a pale wash. 25% is what it actually takes.
        expect(chromaOf(token('surface'))).toBeGreaterThanOrEqual(0.25);
    });

    it('the card is still a light surface, not a dark one in disguise', () => {
        // The lightness floor, and the reason it had to come down from 0.80.
        // A light colour cannot hold much chroma, so a blue that actually reads
        // as blue cannot sit at 0.80 luminance. This is the line between "blue
        // light mode" and "a second dark mode", and 0.45 is where it sits: the
        // card measures 0.53.
        expect(luminance(toRgb(token('surface')))).toBeGreaterThan(0.45);
        expect(luminance(toRgb(token('surface')))).toBeLessThan(0.75);
    });

    it('the card is separated from the page by the borders, not by tone', () => {
        // With both surfaces blue the tonal step between them is small, so the
        // borders have to carry the edge. This is the constraint the reversal
        // moved onto them.
        expect(contrast(token('border'), token('surface'))).toBeGreaterThanOrEqual(1.25);
        expect(contrast(token('border-strong'), token('surface'))).toBeGreaterThanOrEqual(1.45);
        expect(contrast(token('surface'), token('page'))).toBeLessThan(1.25);
    });

    it('dark mode is untouched by the blue', () => {
        // Not a hue assertion. The dark palette was blue before this change --
        // it is hsl(209, ...) throughout, and 209 is inside the range the test
        // above calls blue, so "dark has no blue hue" would be asserting a
        // falsehood. What "untouched" means is that the values did not move,
        // so they are pinned directly.
        expect(darkBlock).toMatch(/--at-page:\s*hsl\(209, 20%, 25%\);/);
        expect(darkBlock).toMatch(/--at-surface:\s*hsl\(209, 18%, 30%\);/);
        expect(darkBlock).toMatch(/--at-surface-2:\s*hsl\(209, 14%, 37%\);/);
        expect(darkBlock).toMatch(/--at-surface-3:\s*hsl\(211, 12%, 43%\);/);
        expect(darkBlock).toMatch(/--at-border:\s*hsl\(211, 10%, 53%\);/);
        expect(darkBlock).toMatch(/--at-border-strong:\s*hsl\(210, 16%, 82%\);/);
        expect(darkBlock).toMatch(/--at-text:\s*hsl\(214, 15%, 91%\);/);
    });

    it('the sidebar is still not blue, because it is not a light surface', () => {
        // The sidebar is dark in BOTH modes and shares one block. The blue work
        // was to the light palette, so the sidebar tokens must be exactly what
        // they were -- if this block picked up the light blue the always-dark
        // sidebar would quietly change colour.
        expect(sharedBlock).toMatch(/--at-side-bg:\s*hsl\(210, 24%, 16%\);/);
        expect(sharedBlock).toMatch(/--at-side-text:\s*hsl\(214, 15%, 91%\);/);
        expect(sharedBlock).toMatch(/--at-side-border:\s*hsl\(211, 10%, 53%\);/);
    });
});

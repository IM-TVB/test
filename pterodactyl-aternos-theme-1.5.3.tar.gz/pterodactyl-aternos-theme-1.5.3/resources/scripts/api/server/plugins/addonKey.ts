/**
 * One function that decides "is this the same add-on as that?".
 *
 * The installed list and the search results are two independent descriptions of
 * the same thing: one is a filename on disk, the other is a project's name from
 * a provider API. To tell them apart you have to reduce both to a single
 * comparable string, and when those two reductions are written separately they
 * quietly disagree. That is not hypothetical -- of five real jars on this
 * server, two failed to match their own project:
 *
 *   FastAsyncWorldEdit-Bukkit-2.15.4.jar  ->  fastasyncworldedit-bukkit  vs  fastasyncworldedit
 *   Simple-Tpa-8.0.jar                    ->  simple-tpa                vs  simpletpa
 *
 * The first is a platform suffix the filename carries and the name does not; the
 * second is punctuation that one side spells with a hyphen and the other without.
 * Both are ordinary, and both silently cost the user the ability to see that a
 * plugin is already installed.
 *
 * So the rule lives here once and both sides call it. Same lesson as the Spigot
 * jar filename, where a marker built inline stopped matching the filename built
 * elsewhere and the badge vanished for every Spigot plugin.
 */

/**
 * Suffixes that appear in a jar filename but never in the project's name.
 *
 * These are platform and loader markers: the same plugin compiled for Bukkit,
 * Paper, BungeeCord and so on. Modrinth, Spigot and Hangar all ship
 * `<name>-<platform>-<version>.jar` for at least some of their projects, and the
 * search result only ever knows the bare name.
 */
const PLATFORM_SUFFIXES = [
    'bungeecord',
    'bungee',
    'waterfall',
    'velocity',
    'purpur',
    'folia',
    'spigot',
    'bukkit',
    'paper',
    'sponge',
    'neoforge',
    'forge',
    'fabric',
    'quilt',
    'liteloader',
];

/** Longest platform name, so the suffix check reads as "at most this long". */
const SUFFIX_GUARD = 10;

/**
 * Reduce a filename or a project name to a comparable key.
 *
 * Steps, in order:
 *   1. drop a trailing `-version` (`5.5.71`, `2.15.4`, `2023.1`)
 *   2. drop a `-disabled` marker the panel adds
 *   3. drop one trailing platform suffix, but only if a real name remains
 *   4. remove all punctuation and lowercase
 *
 * Step 4 is what makes `Simple-Tpa` and `SimpleTpa` the same key, and it is also
 * why a hyphen in a project name is not load-bearing.
 *
 * Step 3 deliberately requires at least three characters to survive, so a project
 * actually named "Bukkit" keeps its name instead of being reduced to nothing.
 */
export const addonKey = (value: string): string => {
    const base = value
        .replace(/\.jar$/i, '')
        .replace(/-disabled$/i, '')
        .replace(/-\d[\w.+-]*$/i, '')
        .trim();

    let name = base;

    for (const suffix of PLATFORM_SUFFIXES) {
        const pattern = new RegExp(`[-_ ]${suffix}$`, 'i');

        if (pattern.test(name)) {
            const trimmed = name.replace(pattern, '').trim();

            if (trimmed.length >= 3) {
                name = trimmed;
            }

            break;
        }
    }

    return name
        .toLowerCase()
        // Combining marks are dropped so an accented name matches its plain
        // spelling, matching what the filename sanitiser already does.
        .normalize('NFKD')
        .replace(/[̀-ͯ]/g, '')
        .replace(/[^a-z0-9]+/g, '');
};

/**
 * Every key an installed file should be findable by.
 *
 * More than one, because reducing to a single key is lossy: `Foo-Bukkit` and
 * `Foo-Paper` both reduce to `foo`, so whichever was written last would win and
 * the other would lose its badge. Including the unreduced form as well means a
 * project whose name genuinely contains a platform word still matches.
 */
export const addonKeyAliases = (value: string): string[] => {
    const reduced = addonKey(value);
    const unreduced = value
        .replace(/\.jar$/i, '')
        .replace(/-disabled$/i, '')
        .replace(/-\d[\w.+-]*$/i, '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '');

    return unreduced === reduced ? [reduced] : [reduced, unreduced];
};

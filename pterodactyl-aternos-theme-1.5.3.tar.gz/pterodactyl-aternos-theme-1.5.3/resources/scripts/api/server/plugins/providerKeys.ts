import http from '@/api/http';

/**
 * Provider API keys, stored panel-side and fetched per request.
 *
 * Keys are never bundled into the JavaScript: a key in the bundle is a key in
 * every visitor's browser. They are held in the panel's settings table, marked
 * sensitive so the panel does not expose them through its settings API, and read
 * server-side only.
 *
 * At the moment this holds one key, for CurseForge, whose API refuses
 * every request without one.
 */

export interface ProviderKeyInfo {
    id: string;
    name: string;
    configured: boolean;
    /** Shown in the UI so an operator can tell a missing key from a failure. */
    hint: string | null;
}

const asProviderKeys = (data: any): ProviderKeyInfo[] =>
    Array.isArray(data) ? (data as ProviderKeyInfo[]) : [];

export const getProviderKeys = async (): Promise<ProviderKeyInfo[]> => {
    const { data } = await http.get('/api/client/plugins/providers');

    return asProviderKeys(data);
};

export const getProviderKey = async (id: string): Promise<string | null> => {
    const keys = await getProviderKeys();
    const found = keys.find((k) => k.id === id);

    return found?.configured ? id : null;
};

import { AxiosProgressEvent } from 'axios';
import axios from 'axios';

/**
 * Modrinth v2 API client.
 *
 * Modrinth sends permissive CORS headers, so the browser can talk to it directly.
 * That keeps this feature entirely client-side: no new panel endpoints, no
 * database migration, and no server-side API key to leak.
 *
 * Docs: https://docs.modrinth.com/api
 */

const BASE = 'https://api.modrinth.com/v2';
const CDN = 'https://cdn.modrinth.com';

export type ModrinthProjectType = 'plugin' | 'mod' | 'modpack' | 'resourcepack' | 'shader';

export interface ModrinthHit {
    project_id: string;
    slug: string;
    title: string;
    description: string;
    categories: string[];
    versions: string[];
    follows: number;
    downloads: number;
    icon_url: string | null;
    color: string | null;
    date_modified: string;
    project_type: ModrinthProjectType;
    game_versions: string[];
    loaders: string[];
}

export interface ModrinthSearchResponse {
    hits: ModrinthHit[];
    offset: number;
    limit: number;
    total_hits: number;
}

export interface ModrinthFile {
    hashes: { sha1: string; sha512: string };
    url: string;
    filename: string;
    primary: boolean;
    size: number;
}

export interface ModrinthVersion {
    id: string;
    project_id: string;
    name: string;
    version_number: string;
    changelog: string;
    game_versions: string[];
    version_type: 'release' | 'beta' | 'alpha';
    loaders: string[];
    featured: boolean;
    date_published: string;
    downloads: number;
    files: ModrinthFile[];
    dependencies: { version_id: string | null; project_id: string; dependency_type: string }[];
}

export interface SearchOptions {
    /** e.g. ['paper', 'spigot', 'bukkit'] — filtered client-side, see below. */
    loaders?: string[];
    /** e.g. ['1.20.4'] — the first entry is sent as a server-side facet. */
    gameVersions?: string[];
    projectType?: ModrinthProjectType;
    limit?: number;
    offset?: number;
    /** Modrinth sort index. 'downloads' gives the Aternos-style default list. */
    sort?: 'relevance' | 'downloads' | 'follows' | 'newest' | 'updated';
}

/**
 * Build the server-side facet list.
 *
 * Modrinth ANDs the inner arrays and accepts exactly ONE `key:value` per entry.
 * Space-separated OR values (`"categories:paper spigot"`) are rejected with
 * **HTTP 400**, so multi-loader OR is done client-side against each hit's
 * `categories` array instead. Sending it anyway would fail every search on a
 * Bukkit/BungeeCord server.
 */
const buildFacets = (opts: SearchOptions): string[][] => {
    const facets: string[][] = [];

    if (opts.projectType) {
        facets.push([`project_type:${opts.projectType}`]);
    }
    if (opts.gameVersions?.length) {
        facets.push([`versions:${opts.gameVersions[0]}`]);
    }

    return facets;
};

/** Does a search hit support any of the wanted loaders? */
export const hitMatchesLoaders = (hit: ModrinthHit, loaders: string[]): boolean => {
    if (loaders.length === 0) {
        return true;
    }

    const wanted = loaders.map((l) => l.toLowerCase());

    return (hit.categories ?? []).some((c) => wanted.includes(c.toLowerCase()));
};

/**
 * Fetch a page of results.
 *
 * NOTE: the loader filter runs client-side (Modrinth rejects multi-value OR
 * facets), so `limit`/`offset` apply to the UNFILTERED set. Callers that
 * paginate must therefore page over the filtered results themselves, or they
 * will show short pages and duplicates where the filter crosses a boundary.
 */
export const search = async (query: string, opts: SearchOptions = {}): Promise<ModrinthSearchResponse> => {
    const { data } = await axios.get<ModrinthSearchResponse>(`${BASE}/search`, {
        params: {
            query,
            limit: opts.limit ?? 20,
            offset: opts.offset ?? 0,
            index: opts.sort ?? 'relevance',
            facets: JSON.stringify(buildFacets(opts)),
        },
    });

    if (opts.loaders?.length) {
        data.hits = data.hits.filter((hit) => hitMatchesLoaders(hit, opts.loaders!));
    }

    return data;
};

/**
 * How many add-ons Modrinth has for one Minecraft version on this software.
 *
 * Uses the loader facet server-side rather than filtering hits in the browser,
 * so `total_hits` is already the real number. That matters: Aternos shows the
 * same figure, and counting the first page of results instead would report a
 * capped number that silently disagreed with the grid.
 */
export const countAddonsForVersion = async (
    version: string,
    loaders: string[],
    projectType: 'plugin' | 'mod'
): Promise<number> => {
    const facets: string[][] = [[`project_type:${projectType}`], [`versions:${version}`]];

    // A loader set has to be one facet; the inner values are ORed, and facets
    // themselves are ANDed, so this means "any of these loaders".
    if (loaders.length > 0) {
        facets.push(loaders.map((l) => `categories:${l}`));
    }

    const { data } = await axios.get<{ total_hits: number }>(`${BASE}/search`, {
        params: { limit: 1, facets: JSON.stringify(facets) },
    });

    return data.total_hits;
};

/**
 * Every published version of a project, newest first.
 *
 * $filters is what the server can actually run, and it is worth sending: for
 * LuckPerms the unfiltered list is 102 versions spanning NeoForge, Fabric, Forge,
 * Velocity, Bungee and Bukkit, and the head of it -- a NeoForge mod build -- is
 * what a naive "first row" reads as the version to install. Filtered for a Leaf
 * 1.21.11 server the same project returns 3, all Bukkit, all supporting 1.21.11.
 *
 * The game version is only sent when the user actually chose one, so a server
 * that never set a version still sees everything the project ships.
 */
export const getVersions = async (
    projectId: string,
    filters: { loaders?: string[]; gameVersions?: string[] } = {}
): Promise<ModrinthVersion[]> => {
    const params: Record<string, string> = {};

    if (filters.loaders && filters.loaders.length > 0) {
        params.loaders = JSON.stringify(filters.loaders);
    }

    if (filters.gameVersions && filters.gameVersions.length > 0) {
        params.game_versions = JSON.stringify(filters.gameVersions);
    }

    const { data } = await axios.get<ModrinthVersion[]>(`${BASE}/project/${projectId}/version`, { params });

    return data;
};

/**
 * Choose the best version for a server.
 *
 * When the user picked a Minecraft version it is a hard requirement: a
 * loader-compatible build that does not support that version is refused rather
 * than installed, because a mismatched plugin usually fails at runtime with a
 * stack trace the user then has to diagnose. With no version chosen, the loader
 * alone decides.
 *
 * Returns null when nothing matches, so the caller can refuse instead of guessing.
 */
export const pickVersion = (
    versions: ModrinthVersion[],
    opts: { loaders: string[]; gameVersions: string[] }
): ModrinthVersion | null => {
    if (versions.length === 0) {
        return null;
    }

    const byDate = (a: ModrinthVersion, b: ModrinthVersion) =>
        new Date(b.date_published).getTime() - new Date(a.date_published).getTime();

    const loaders = opts.loaders.map((l) => l.toLowerCase());
    const games = opts.gameVersions;
    const versionRequired = games.length > 0;

    const matchesLoader = (v: ModrinthVersion) =>
        loaders.length === 0 || v.loaders.some((l) => loaders.includes(l.toLowerCase()));
    const matchesGame = (v: ModrinthVersion) =>
        !versionRequired || v.game_versions.some((g) => games.includes(g));

    const candidates: ModrinthVersion[][] = [
        versions.filter((v) => matchesLoader(v) && matchesGame(v) && v.version_type === 'release'),
        versions.filter((v) => matchesLoader(v) && matchesGame(v)),
    ];

    // Only widen to "any version" when the user did not constrain it.
    if (!versionRequired) {
        candidates.push(versions.filter((v) => matchesLoader(v) && v.version_type === 'release'));
        candidates.push(versions.filter((v) => matchesLoader(v)));
    }

    candidates.push(versions.filter((v) => matchesGame(v) && v.version_type === 'release'));

    for (const group of candidates) {
        if (group.length > 0) {
            return [...group].sort(byDate)[0];
        }
    }

    return null;
};

/**
 * Hex SHA-1 of a buffer, matching the `hashes.sha1` Modrinth publishes.
 *
 * WebCrypto only exposes SHA-1 over a secure context, so this rejects loudly
 * rather than returning a bogus digest that would fail verification later.
 */
export const sha1Hex = async (buffer: ArrayBuffer): Promise<string> => {
    if (!globalThis.crypto?.subtle) {
        throw new Error(
            'This browser cannot verify downloads (crypto.subtle is unavailable). Serve the panel over HTTPS.'
        );
    }

    const digest = await crypto.subtle.digest('SHA-1', buffer);
    const view = new Uint8Array(digest);

    return Array.from(view)
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
};

/**
 * Download a project file and confirm it matches the published hash before it
 * is handed to Wings. Returns the bytes ready to upload.
 */
export const downloadVerified = async (
    file: ModrinthFile,
    onProgress?: (percent: number) => void
): Promise<Blob> => {
    const { data, headers } = await axios.get(file.url, {
        responseType: 'blob',
        onDownloadProgress: (event: AxiosProgressEvent) => {
            if (onProgress && event.total) {
                onProgress(Math.round((event.loaded / event.total) * 100));
            }
        },
    });

    const actual = await sha1Hex(await data.arrayBuffer());
    if (actual.toLowerCase() !== file.hashes.sha1.toLowerCase()) {
        throw new Error(
            `Checksum mismatch for ${file.filename} — the download was corrupted or tampered with, so it was not installed.`
        );
    }

    if (onProgress) {
        onProgress(100);
    }

    return data;
};

export const cdnUrl = (path: string): string => `${CDN}${path}`;

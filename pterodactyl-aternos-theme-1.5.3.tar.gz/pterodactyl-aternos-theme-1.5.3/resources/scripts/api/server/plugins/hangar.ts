import axios from 'axios';
import { looksLikeJar, sizeOf, toArrayBuffer } from './blob';

/**
 * Hangar — Paper's official plugin registry (https://hangar.papermc.io).
 *
 * This is the modern home of Bukkit-family plugins. bukkit.org itself is not
 * usable: it answers 403 behind a Cloudflare challenge on every request and has
 * no API, and its catalogue has been superseded by SpigotMC since 2014. Hangar is
 * where those plugins are published now, and it is the friendlier of the
 * alternative registries because it is the only one of the three that does all of:
 *
 *  - CORS. hangar.papermc.io sends `access-control-allow-origin: *`, and
 *    hangarcdn.papermc.io reflects the requesting origin, so the browser can
 *    both search and download. CurseForge's API needs a per-account key,
 *    and spigotmc.org answers 403 to a cross-origin jar download.
 *  - Version accuracy. A project's `supportedPlatforms` lists the Minecraft
 *    versions it declares, so results can be filtered by the version the user
 *    picked. Spiget returns `tested_versions: null` for most resources.
 *  - Integrity. Each hosted file carries a `sha256Hash`, so the download can be
 *    verified the way Modrinth's SHA-1 is. Spiget publishes no hash at all.
 *
 * Limitation kept visible in the UI: a project may publish its jar on an
 * external site instead of Hangar. Those are marked and cannot be installed from
 * here, because there is no URL this panel can fetch.
 */

const API = 'https://hangar.papermc.io/api/v1';
const CDN = 'https://hangarcdn.papermc.io';

export interface HangarHit {
    /** "owner/slug", the identifier every other call needs. */
    slug: string;
    name: string;
    description: string;
    downloads: number;
    iconUrl: string | null;
    /** Minecraft versions the project declares support for. */
    supportedVersions: string[];
    /** Newest published version name, if the project has any. */
    latestVersion: string | null;
    /** False when the jar lives on an external site, so it is not installable. */
    installable: boolean;
}

interface HangarDownload {
    downloadUrl: string | null;
    externalUrl: string | null;
    fileInfo: { name: string; sizeBytes: number; sha256Hash: string } | null;
}

const hangar = axios.create({
    // Without this the calls below are relative and axios throws
    // "Invalid URL": every Hangar request failed while the search looked like a
    // provider outage rather than a missing base URL.
    baseURL: API,
    timeout: 20000,
    headers: { Accept: 'application/json' },
});

const readPlatform = (raw: any, platform: 'PAPER'): HangarDownload =>
    ((raw?.downloads ?? {})[platform] ?? {}) as HangarDownload;

export interface HangarSearchOptions {
    limit?: number;
    offset?: number;
    sort?: 'downloads' | 'updated';
}

export interface HangarSearchResult {
    hits: HangarHit[];
    total: number;
}

/**
 * Search Hangar. An empty query lists the most-downloaded projects, which is
 * what the plugins page shows on first load.
 *
 * `sort` is not optional in Hangar's API: omitting it answers 400, so a default
 * is supplied here rather than left to the caller.
 */
export const searchHangar = async (
    query: string,
    opts: HangarSearchOptions = {}
): Promise<HangarSearchResult> => {
    const limit = opts.limit ?? 20;
    const offset = opts.offset ?? 0;
    const term = query.trim();

    const { data } = await hangar.get<any>('/projects', {
        params: {
            limit,
            offset,
            sort: opts.sort === 'updated' ? '-updated' : '-downloads',
            ...(term ? { query: term } : {}),
        },
    });

    const results = data?.result ?? [];

    // Hangar's project record has no download URL, so each hit costs one more
    // request for its newest version. That is bounded by the page size and is
    // what makes installable-vs-external and the version name knowable.
    const hits = await Promise.all(
        results.map(async (p: any): Promise<HangarHit> => {
            const slug = `${p.namespace?.owner ?? ''}/${p.namespace?.slug ?? ''}`;
            const supported = Object.values(p.supportedPlatforms ?? {}).flat() as string[];

            let latest: { name: string; installable: boolean } | null = null;
            try {
                const v = await hangar.get<any>(`/projects/${slug}/versions`, { params: { limit: 1 } });
                const raw = (v.data?.result ?? [])[0];
                if (raw) {
                    latest = { name: raw.name, installable: !!readPlatform(raw, 'PAPER').downloadUrl };
                }
            } catch (e) {
                // A project whose version list fails is still worth showing;
                // it just cannot be installed from here.
                latest = null;
            }

            return {
                slug,
                name: p.name ?? slug,
                description: p.description ?? '',
                downloads: p.stats?.downloads ?? 0,
                iconUrl: p.avatarUrl ?? null,
                supportedVersions: [...new Set(supported)],
                latestVersion: latest?.name ?? null,
                installable: latest?.installable ?? false,
            };
        })
    );

    return { hits, total: data?.pagination?.count ?? hits.length };
};

/** The newest version that Hangar actually hosts, with its hash and filename. */
export interface HangarVersion {
    /** Opaque handle: the name Hangar published it under. */
    name: string;
    createdAt: string;
    downloads: number;
    gameVersions: string[];
    installable: boolean;
}

/**
 * Every published version of a project, newest first.
 *
 * Same shape as getHangarLatestFile()'s data but keeping all of it rather than
 * the first installable row, because the point of this is to let someone pick a
 * version rather than be handed the newest one.
 *
 * `installable` is per version, not per project: Hangar lets a project publish a
 * version with no PAPER download (external only, or a platform we do not
 * handle), and offering a download button for one of those produces a failure
 * after the click rather than before it.
 */
export const getHangarVersions = async (slug: string, limit = 25): Promise<HangarVersion[]> => {
    const { data } = await hangar.get<any>(`/projects/${slug}/versions`, {
        params: { limit: Math.min(Math.max(limit, 1), 50) },
    });

    const raw = data?.result;
    if (!Array.isArray(raw)) return [];

    const versions: HangarVersion[] = [];

    for (const entry of raw) {
        const name = String(entry?.name ?? '').trim();
        if (name === '') continue;

        const paper = readPlatform(entry, 'PAPER');

        versions.push({
            name,
            createdAt: String(entry?.createdAt ?? ''),
            downloads: Number(entry?.downloads?.overall ?? 0) || 0,
            gameVersions: Array.isArray(entry?.gameVersions) ? entry.gameVersions.map(String) : [],
            installable: !!paper.downloadUrl && !!paper.fileInfo,
        });
    }

    return versions;
};

/**
 * Resolve one named version to its download.
 *
 * Separate from the list because installing a chosen version must not re-ask for
 * the newest: a caller that picked 1.2.3 and silently received 2.0.0 would be
 * worse than no version picker at all.
 */
export const getHangarFile = async (
    slug: string,
    versionName: string
): Promise<{ url: string; filename: string; sha256: string; sizeBytes: number; version: string } | null> => {
    const { data } = await hangar.get<any>(`/projects/${slug}/versions/${encodeURIComponent(versionName)}`);

    const paper = readPlatform(data, 'PAPER');
    if (!paper.downloadUrl || !paper.fileInfo) return null;

    return {
        url: paper.downloadUrl,
        filename: paper.fileInfo.name,
        sha256: paper.fileInfo.sha256Hash,
        sizeBytes: paper.fileInfo.sizeBytes,
        version: String(data?.name ?? versionName),
    };
};

export const getHangarLatestFile = async (
    slug: string
): Promise<{ url: string; filename: string; sha256: string; sizeBytes: number; version: string } | null> => {
    const { data } = await hangar.get<any>(`/projects/${slug}/versions`, { params: { limit: 5 } });

    // Newest first, but skip anything published externally: there is no URL the
    // browser can fetch, so it cannot be installed.
    for (const raw of data?.result ?? []) {
        const paper = readPlatform(raw, 'PAPER');
        if (!paper.downloadUrl || !paper.fileInfo) continue;

        return {
            url: paper.downloadUrl,
            filename: paper.fileInfo.name,
            sha256: paper.fileInfo.sha256Hash,
            sizeBytes: paper.fileInfo.sizeBytes,
            version: raw.name,
        };
    }

    return null;
};

const toHex = (buffer: ArrayBuffer) =>
    [...new Uint8Array(buffer)].map((b) => b.toString(16).padStart(2, '0')).join('');

/**
 * Download a Hangar jar and verify its SHA-256 against the hash Hangar
 * publishes for that exact file.
 */
export const downloadHangarJar = async (
    file: { url: string; sha256: string; filename: string },
    onProgress?: (percent: number) => void
): Promise<{ blob: Blob; filename: string }> => {
    onProgress?.(15);

    const response = await axios.get(file.url, {
        responseType: 'blob',
        timeout: 120000,
        onDownloadProgress: (event) => {
            if (event.total) {
                onProgress?.(15 + Math.round((event.loaded / event.total) * 0.55));
            }
        },
    });

    const blob = response.data as Blob;

    if (!blob || sizeOf(blob) === 0) {
        throw new Error('The download was empty.');
    }

    if (!(await looksLikeJar(blob))) {
        throw new Error('The download was not a jar file (a web page came back instead).');
    }

    onProgress?.(72);

    // The full buffer is hashed rather than a slice: a truncated download would
    // otherwise produce a mismatch that looks like tampering.
    const digest = toHex(await toArrayBuffer(blob));

    if (file.sha256 && digest.toLowerCase() !== file.sha256.toLowerCase()) {
        throw new Error(
            'The download did not match the checksum Hangar publishes for this file, so it was not installed.'
        );
    }

    onProgress?.(75);

    return { blob, filename: file.filename };
};

import axios from 'axios';
import { FileObject } from '@/api/server/files/loadDirectory';
import loadDirectory from '@/api/server/files/loadDirectory';
import deleteFiles from '@/api/server/files/deleteFiles';
import getFileUploadUrl from '@/api/server/files/getFileUploadUrl';
import { ModrinthFile, ModrinthHit, ModrinthVersion, downloadVerified, getVersions, pickVersion } from './modrinth';
import { AddOnHit, AddOnVersion } from './providers';
import { downloadSpigotJar } from './spiget';
import { downloadHangarJar, getHangarFile, getHangarLatestFile } from './hangar';
import { sizeOf } from './blob';
import { CurseForgeHit, downloadCurseForgeJar } from './curseforge';
import { AddOnUnavailableError, downloadViaPanel, providerPageUrl, withPanelFallback } from './panelFallback';
import { spigotFilename, spigotVersionName } from './spigetFilename';

export interface InstallProgress {
    phase: 'resolving' | 'downloading' | 'verifying' | 'uploading' | 'done';
    percent: number;
    message: string;
}

export interface InstallResult {
    filename: string;
    size: number;
    version: string;
    gameVersions: string[];
    loaders: string[];
}

/** One add-on already present in the server's add-on directory. */
export interface InstalledAddon {
    /** The raw directory entry, for keys and the full filename. */
    file: FileObject;
    /** Filename with the extension and any -disabled marker stripped, for display. */
    name: string;
    /** True when install() named it so the server software would refuse to load it. */
    disabled: boolean;
}

/**
 * List what is already installed in a directory.
 *
 * The directory is always passed in by the caller, taken from the server's real
 * software via GET /software. Nothing here infers it: a wrong guess reads the
 * wrong folder and reports an empty or misleading list.
 */
export const listInstalled = async (uuid: string, directory: string): Promise<InstalledAddon[]> => {
    const listing = await loadDirectory(uuid, directory);

    return (listing as FileObject[])
        .filter((entry) => entry.isFile && entry.name.toLowerCase().endsWith('.jar'))
        .map((file) => ({
            file,
            name: file.name.replace(/\.jar$/i, '').replace(/-disabled$/i, ''),
            disabled: /-disabled\.jar$/i.test(file.name),
        }));
};

/**
 * Build the name a project is stored under, so a later listing can recognise
 * that it is already installed. `disabled` marks a build the server software
 * would refuse to load.
 */
const targetFilename = (hit: ModrinthHit, version: ModrinthVersion, disabled: boolean): string => {
    const safeTitle = hit.title.replace(/[^\w.-]+/g, '-').replace(/^-+|-+$/g, '').toLowerCase();
    const safeVersion = version.version_number.replace(/[^\w.+-]+/g, '-');
    const suffix = disabled ? '-disabled' : '';

    return `${safeTitle}-${safeVersion}${suffix}.jar`;
};

/**
 * Resolve, download, verify, and install a project version.
 *
 * The download goes straight from the provider's CDN to the browser and then on
 * to Wings via a pre-signed URL, so the file never passes through the panel.
 * Modrinth's SHA-1 is checked before upload; Spiget publishes no checksum, so
 * that path verifies the file is a real jar instead (see downloadSpigotJar).
 */
export const installFromProvider = async (
    uuid: string,
    directory: string,
    hit: AddOnHit,
    opts: {
        loaders: string[];
        gameVersions: string[];
        onProgress?: (p: InstallProgress) => void;
        /**
         * A specific version to install, from the version picker. Absent means
         * "whatever a plain install would have chosen", which is every caller
         * that is not the picker.
         */
        chosen?: AddOnVersion | null;
    }
): Promise<InstallResult> => {
    const onProgress = opts.onProgress ?? (() => undefined);
    const chosen = opts.chosen ?? null;

    if (hit.provider === 'modrinth') {
        return install(uuid, directory, hit, opts);
    }

    if (hit.provider === 'hangar') {
        return installHangar(uuid, directory, hit, onProgress, chosen);
    }

    if (hit.provider === 'curseforge') {
        return installCurseForge(uuid, directory, hit, onProgress, chosen);
    }

    const id = hit.spigetId!;

    onProgress({ phase: 'downloading', percent: 15, message: `Downloading ${hit.spigotName ?? hit.title}…` });

    const panelName = async (version: number | null) =>
        spigotFilename(
            hit.spigotName ?? hit.title,
            id,
            await spigotVersionName(id, version)
        );

    const { blob, filename } = chosen
        ? /*
           * A chosen Spigot version skips the direct route entirely.
           *
           * cdn.spiget.org serves the resource's NEWEST jar at /{id}.jar and 404s
           * for per-version paths, so the direct download of an older version does
           * not fail -- it succeeds and returns the wrong jar. withPanelFallback
           * would then treat that success as done and the user would get the
           * newest version while the picker said they picked another. So this
           * path is not a fallback here, it is the only route.
           */
          await downloadViaPanel(
              hit,
              { id, version: chosen.id },
              {
                  filename: () => panelName(Number(chosen.id)),
                  onProgress: (message) => onProgress({ phase: 'downloading', percent: 15, message }),
              }
          )
        : await withPanelFallback(
              hit,
              async () =>
                  downloadSpigotJar(
                      id,
                      hit.spigotName ?? hit.title,
                      hit.spigetVersionId ?? null,
                      (percent: number) =>
                          onProgress({
                              phase: 'downloading',
                              percent: 15 + Math.round(percent * 0.55),
                              message: `Downloading ${hit.spigotName ?? hit.title}… ${percent}%`,
                          })
                  ),
              { id },
              {
                  // The panel knows only the resource id, and would name the file
                  // spigot-<id>.jar. Resolving the version here costs one request,
                  // and only on this path -- which is the whole reason it is a
                  // function.
                  filename: () => panelName(hit.spigetVersionId ?? null),
                  onProgress: (message) => onProgress({ phase: 'downloading', percent: 15, message }),
              }
          );

    onProgress({ phase: 'verifying', percent: 75, message: 'Verified as a jar — uploading…' });

    const uploadUrl = await getFileUploadUrl(uuid);

    await axios.post(uploadUrl, { files: new File([blob], filename) }, {
        headers: { 'Content-Type': 'multipart/form-data' },
        params: { directory },
    });

    onProgress({ phase: 'done', percent: 100, message: `Installed ${filename}` });

    return {
        filename,
        size: blob.size,
        // Spiget exposes no per-version metadata, so these describe what we
        // actually installed rather than what the user asked for.
        version: 'latest',
        gameVersions: [],
        loaders: [],
    };
};

const upload = async (uuid: string, directory: string, blob: Blob, filename: string) => {
    const uploadUrl = await getFileUploadUrl(uuid);

    await axios.post(uploadUrl, { files: new File([blob], filename) }, {
        headers: { 'Content-Type': 'multipart/form-data' },
        params: { directory },
    });
};

/**
 * Hangar: the newest version Hangar actually hosts, verified against the SHA-256
 * it publishes for that exact file. A project whose jar lives on an external
 * site has no URL to fetch and is refused here rather than at the API.
 */
const installHangar = async (
    uuid: string,
    directory: string,
    hit: AddOnHit,
    onProgress: (p: InstallProgress) => void,
    chosen: AddOnVersion | null = null
): Promise<InstallResult> => {
    onProgress({
        phase: 'resolving',
        percent: 5,
        message: chosen
            ? `Resolving Hangar build ${chosen.version}…`
            : 'Finding the latest Hangar build…',
    });

    // A chosen version is resolved by name and never re-resolved to "latest" --
    // asking for the newest again would hand back a different build than the one
    // the picker said was chosen.
    const file = chosen
        ? await getHangarFile(hit.hangarSlug!, chosen.id)
        : await getHangarLatestFile(hit.hangarSlug!);

    if (!file) {
        throw new Error('This project publishes its jar on an external site, so it cannot be installed from here.');
    }

    onProgress({ phase: 'downloading', percent: 15, message: `Downloading ${file.filename}…` });

    const { blob, filename } = await withPanelFallback(
        hit,
        async () =>
            downloadHangarJar(file, (percent: number) =>
                onProgress({ phase: 'downloading', percent: 15 + Math.round(percent * 0.55), message: `Downloading ${file.filename}… ${percent}%` })
            ),
        { slug: hit.hangarSlug!, version: file.version },
        {
            onProgress: (message) => onProgress({ phase: 'downloading', percent: 15, message }),
        }
    );

    onProgress({ phase: 'verifying', percent: 75, message: 'SHA-256 verified — uploading…' });
    await upload(uuid, directory, blob, filename);

    onProgress({ phase: 'done', percent: 100, message: `Installed ${filename}` });

    return { filename, size: blob.size, version: file.version, gameVersions: [], loaders: [] };
};

/**
 * CurseForge: the project's newest file for its Bukkit category, fetched through
 * the panel.
 *
 * The panel has already checked the bytes against CurseForge's published SHA-1
 * before sending them, and this repeats the size check on arrival, so a
 * truncation between panel and browser is caught rather than uploaded.
 */
const installCurseForge = async (
    uuid: string,
    directory: string,
    hit: AddOnHit,
    onProgress: (p: InstallProgress) => void,
    chosen: AddOnVersion | null = null
): Promise<InstallResult> => {
    if (!hit.curseforgeId) {
        throw new Error('This project does not publish a downloadable file.');
    }

    // A CurseForge file IS a version, so a chosen row carries the file id the
    // download needs. Falling back to the search hit's file id would install the
    // newest build while the picker said otherwise.
    const fileId = chosen ? Number(chosen.id) : hit.curseforgeFileId;

    if (!fileId) {
        throw new Error('This project does not publish a downloadable file.');
    }

    // CurseForge already downloads through the panel, so there is no second route
    // to try here. What it does need is a way out: when the key is missing or
    // upstream refuses, the user should be able to reach CurseForge's own page
    // rather than being left with a bare failure.
    let blob: Blob;
    let filename: string;

    try {
        ({ blob, filename } = await downloadCurseForgeJar(
            hit.curseforgeId,
            fileId,
            (percent: number) =>
                onProgress({
                    phase: 'downloading',
                    percent: percent,
                    // The real filename only exists once the response headers have
                    // arrived, so the label comes from the search result instead.
                    message: `Downloading ${(hit.raw as CurseForgeHit).fileName ?? 'the file'}… ${percent}%`,
                })
        ));
    } catch (directError) {
        throw new AddOnUnavailableError(
            `Could not download ${hit.title} from CurseForge.`,
            directError,
            null
        ).withPage(providerPageUrl(hit));
    }

    onProgress({ phase: 'verifying', percent: 80, message: 'Verified against CurseForge’s checksum — uploading…' });
    await upload(uuid, directory, blob, filename);

    onProgress({ phase: 'done', percent: 100, message: `Installed ${filename}` });

    return {
        filename,
        size: sizeOf(blob),
        version: (hit.raw as CurseForgeHit).latestVersion ?? 'latest',
        gameVersions: hit.gameVersions ?? [],
        loaders: [],
    };
};

/**
 * Resolve, download, verify, and install a project version.
 *
 * The SHA-1 is checked before upload — a mismatch aborts rather than installing
 * a file the user did not get from Modrinth.
 */
export const install = async (
    uuid: string,
    directory: string,
    merged: AddOnHit,
    opts: {
        loaders: string[];
        gameVersions: string[];
        onProgress?: (p: InstallProgress) => void;
        /** A specific version from the picker; null means pick the best one. */
        chosen?: AddOnVersion | null;
    },
    disabled = false
): Promise<InstallResult> => {
    const onProgress = opts.onProgress ?? (() => undefined);
    const hit = merged.raw as ModrinthHit;

    onProgress({ phase: 'resolving', percent: 5, message: 'Finding a compatible version…' });

    const versions = await getVersions(hit.project_id);

    // A chosen version is looked up by its own id and never re-picked from the
    // list. Running pickVersion over the list again would ignore the choice
    // entirely and hand back the newest compatible build, so the picker would say
    // one version and the server would get another.
    const version = opts.chosen
        ? versions.find((v) => v.id === opts.chosen!.id)
        : pickVersion(versions, { loaders: opts.loaders, gameVersions: opts.gameVersions });

    if (!version) {
        throw new Error(
            opts.chosen
                ? `${hit.title} no longer publishes version ${opts.chosen.version}.`
                : `${hit.title} has no build for ${opts.gameVersions.join('/') || 'this version'} on ${opts.loaders.join('/') || 'this platform'}.`
        );
    }

    const file: ModrinthFile | undefined = version.files.find((f) => f.primary) ?? version.files[0];
    if (!file) {
        throw new Error(`${hit.title} ${version.version_number} has no downloadable file.`);
    }

    onProgress({ phase: 'downloading', percent: 15, message: `Downloading ${file.filename}…` });

    // The panel is asked for this exact version, not for the project's newest
    // one. Re-resolving "latest" server-side would hand back a jar for whatever
    // platform happens to be newest, which is often not the one just picked here.
    const { blob } = await withPanelFallback(
        merged,
        async () => ({
            blob: await downloadVerified(file, (percent) => {
                onProgress({
                    phase: 'downloading',
                    percent: 15 + Math.round(percent * 0.55),
                    message: `Downloading ${file.filename}… ${percent}%`,
                });
            }),
            filename: file.filename,
        }),
        { versionId: version.id },
        {
            onProgress: (message) => onProgress({ phase: 'downloading', percent: 15, message }),
        }
    );

    onProgress({ phase: 'verifying', percent: 75, message: 'Checksum verified — uploading…' });

    const filename = targetFilename(hit, version, disabled);
    const uploadUrl = await getFileUploadUrl(uuid);

    await axios.post(uploadUrl, { files: new File([blob], filename) }, {
        headers: { 'Content-Type': 'multipart/form-data' },
        params: { directory },
    });

    onProgress({ phase: 'done', percent: 100, message: `Installed ${filename}` });

    return {
        filename,
        size: file.size,
        version: version.version_number,
        gameVersions: version.game_versions,
        loaders: version.loaders,
    };
};

export const uninstall = async (uuid: string, directory: string, filename: string): Promise<void> => {
    await deleteFiles(uuid, directory, [filename]);
};

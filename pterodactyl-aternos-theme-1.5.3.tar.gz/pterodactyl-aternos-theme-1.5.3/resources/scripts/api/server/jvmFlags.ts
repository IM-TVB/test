import { AxiosError } from 'axios';
import http from '@/api/http';

/**
 * The JVM flags a server's startup runs with.
 *
 * The flag sets themselves are not listed here. They are defined server-side in
 * JvmFlagsService, which is also what writes them, and a client-side copy would be
 * a second list to keep in step -- and the one that matters is the one that ends
 * up in the command, not the one on screen.
 */
export interface JvmFlagPreset {
    key: string;
    label: string;
    blurb: string;
    /** The exact flags this preset applies, for showing what will change. */
    flags: string;
    /** Flags a current JVM ignores from this set, named rather than hidden. */
    dropped_on_modern_jvm: string[];
    /** The heap size the set was written for. */
    target_heap_mb: number;
    /** False when this server's heap is below that, which is worth saying. */
    suited_to_this_server: boolean;
}

export interface JvmFlagOptions {
    /**
     * False when the startup is not a java command, so there is no flag run to
     * rewrite. The picker says so rather than offering a control that does
     * nothing.
     */
    supported: boolean;
    reason: string | null;
    presets: JvmFlagPreset[];
    /**
     * Which preset produced the stored startup. Null means the command matches no
     * preset -- an admin edited it, or the egg changed -- and the flags are shown
     * so the user can see what is actually running.
     */
    current: {
        preset: string | null;
        flags: string | null;
        is_default: boolean;
    };
    heap_mb: number;
}

/**
 * Read the presets and the current choice.
 *
 * A failure is not silently an empty picker: the caller has to be able to say
 * "could not load" instead of "this server has no JVM flags", which are very
 * different and mean opposite things to someone about to press start.
 */
export const getJvmFlags = async (uuid: string): Promise<JvmFlagOptions> => {
    try {
        const { data } = await http.get<JvmFlagOptions>(`/api/client/servers/${uuid}/jvm-flags`);

        return data;
    } catch (e) {
        if (e instanceof AxiosError && e.response?.data?.errors) {
            throw new Error(
                e.response.data.errors.map((err: { detail: string }) => err.detail).join(', ')
            );
        }

        throw e;
    }
};

/**
 * Choose a flag set.
 *
 * The key is a preset name, never a flag string: the panel substitutes the flags
 * from its own list. These flags end up inside a shell invocation, so anything
 * that reached them from the client would be a command injection.
 *
 * Takes effect on the next start -- Wings re-reads the configuration from the
 * panel before booting -- so this is safe to call while the server is running.
 */
export const setJvmFlags = async (uuid: string, preset: string): Promise<JvmFlagOptions> => {
    const { data } = await http.put<JvmFlagOptions>(`/api/client/servers/${uuid}/jvm-flags`, {
        preset,
    });

    return data;
};

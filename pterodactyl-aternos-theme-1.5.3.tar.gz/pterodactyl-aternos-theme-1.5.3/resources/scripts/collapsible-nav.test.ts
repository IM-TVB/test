/**
 * The desktop sidebar collapse.
 *
 * The burger itself is two buttons and a class, and the ways it can be wrong are
 * all invisible in the source: a class applied a beat after first paint (a
 * visible snap on every load), two burgers fighting over the same drawer at one
 * breakpoint, or a collapsed sidebar that leaves a dead gap where it used to be.
 *
 * The last one is why the rule is `display: none` rather than a width change.
 * `.at-shell` is a flex row and the content is `flex: 1`, so removing the
 * sidebar from flow is sufficient for the content to take the space. Anything
 * that animated the width instead would have to be told about the new width,
 * and everything in the theme would have to know about it too.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const css = readFileSync(join(__dirname, 'assets/aternos.css'), 'utf8');
const nav = readFileSync(join(__dirname, 'components/NavigationBar.tsx'), 'utf8');
const hook = readFileSync(join(__dirname, 'plugins/useCollapsibleNav.ts'), 'utf8');
const wrapper = readFileSync(join(__dirname, '../views/templates/wrapper.blade.php'), 'utf8');

describe('the choice is applied before the first frame', () => {
    it('the pre-paint script reads it', () => {
        // Applied from the bundle instead, the sidebar renders at full width and
        // then snaps shut a moment later on every load, for anyone who chose to
        // collapse it. That reads as a glitch, not as their setting.
        expect(wrapper).toContain("window.localStorage.getItem('pterodactyl:nav-collapsed')");
        expect(wrapper).toContain("classList.add('at-nav-collapsed')");
    });

    it('it is inside the same script that applies the theme, before it closes', () => {
        // Two scripts would mean one runs after paint, which is the thing being
        // avoided.
        const start = wrapper.indexOf('pterodactyl:nav-collapsed');
        const end = wrapper.indexOf('</script>', start);

        expect(start).toBeGreaterThan(-1);
        expect(end).toBeGreaterThan(start);
    });

    it('and a disabled localStorage leaves the sidebar expanded rather than throwing', () => {
        const block = wrapper.slice(wrapper.indexOf('pterodactyl:nav-collapsed') - 120, wrapper.indexOf('</script>', wrapper.indexOf('pterodactyl:nav-collapsed')));

        expect(block).toMatch(/try\s*\{[\s\S]*catch/);
    });
});

describe('the hook and the script agree', () => {
    it('same storage key, same class', () => {
        const key = 'pterodactyl:nav-collapsed';
        const cls = 'at-nav-collapsed';

        expect(hook).toContain(`'${key}'`);
        expect(wrapper).toContain(`'${key}'`);
        expect(hook).toContain(`'${cls}'`);
        expect(wrapper).toContain(`'${cls}'`);
    });

    it('the hook reads the DOM rather than localStorage', () => {
        // The pre-paint script is the one that knows the truth; reading
        // localStorage independently would let the two disagree.
        expect(hook).toContain('classList.contains(CLASS)');
    });

    it('it writes both the class and the stored value', () => {
        expect(hook).toContain('classList.toggle(CLASS, collapsed)');
        expect(hook).toContain('localStorage.setItem(STORAGE_KEY');
    });
});

describe('collapsing the sidebar leaves no gap', () => {
    it('the rule removes it from flow entirely', () => {
        expect(css).toMatch(/\.at-nav-collapsed \.at-sidebar\s*\{\s*display:\s*none;/);
    });

    it('and the content is the thing that grows into the space', () => {
        // If the content were a fixed width, hiding the sidebar would leave a
        // hole rather than giving the space back.
        expect(css).toMatch(/\.at-shell__main[^{]*\{[^}]*flex:\s*1/);
    });
});

describe('there is one control per breakpoint, not two', () => {
    it('the drawer burger is hidden when the sidebar can be collapsed', () => {
        // Below 1024px the sidebar is an off-canvas drawer opened from the top
        // bar. Leaving the collapse burger visible there would put two hamburgers
        // on screen, each opening something different.
        //
        // Located by the rule it contains, not by index: there are several
        // `@media (max-width: 1023px)` blocks in this file and picking the last
        // one finds an unrelated rule further down.
        const blocks = [...css.matchAll(/@media \(max-width: 1023px\) \{([\s\S]*?)\n\}/g)]
            .map((m) => m[1])
            .filter((body) => body.includes('.at-sidebar__burger'));

        expect(blocks).toHaveLength(1);
        expect(blocks[0]).toMatch(/\.at-sidebar__burger[\s\S]*display:\s*none/);
        expect(blocks[0]).toMatch(/\.at-nav-restore[\s\S]*display:\s*none/);
    });

    it('and the top bar is still the drawer control there', () => {
        expect(css).toMatch(/\.at-topbar\s*\{\s*display:\s*none;/);
        expect(nav).toContain("className={'at-topbar__burger'}");
    });
});

describe('both controls are reachable and announced', () => {
    it('each burger has a label and an expanded state', () => {
        // aria-expanded is the only thing telling a screen reader whether the
        // sidebar is currently there. Counted rather than matched once: this file
        // briefly carried TWO restore buttons, stacked on the same spot and both
        // in the tab order, and a "does it appear at least once" assertion is
        // exactly what failed to notice.
        expect(nav.match(/aria-expanded=\{!collapsed\}/g)).toHaveLength(2);
        expect(nav.match(/className=\{'at-sidebar__burger'\}/g)).toHaveLength(1);
        expect(nav.match(/className=\{`at-nav-restore/g)).toHaveLength(1);
        expect(nav).toMatch(/at-sidebar__burger[\s\S]{0,220}aria-expanded=\{!collapsed\}/);
        expect(nav).toMatch(/at-nav-restore[\s\S]{0,220}aria-expanded=\{!collapsed\}/);
    });

    it('the labels say which way the toggle goes', () => {
        expect(nav).toContain("aria-label={'Hide the sidebar'}");
        expect(nav).toContain("aria-label={'Show the sidebar'}");
    });

    it('the restore button only exists when the sidebar is gone', () => {
        // Rendered unconditionally and shown by CSS, so it is never in the tab
        // order while the sidebar is on screen.
        expect(nav).toMatch(/className=\{`at-nav-restore\$\{collapsed \? ' is-visible' : ''\}`\}/);
        // Anchored to the base rule, not just any block mentioning the selector.
        // Unanchored, this matched the media-query block -- which is also
        // `display: none` -- and so passed on a base rule changed to `display: grid`.
        expect(css).toMatch(/\n\.at-nav-restore \{\n    display: none;/);
        expect(css).toMatch(/\.at-nav-restore\.is-visible \{\n    display: grid;\n\}/);
    });
});

describe('the sidebar colours are used, not the page ones', () => {
    it('the in-sidebar burger follows the always-dark sidebar', () => {
        // The sidebar is dark in BOTH modes and is styled from --at-side-* tokens.
        // Using a page token here would put dark navy on a dark background the
        // moment the light theme is active -- invisible, and only on that theme.
        const burger = css.slice(css.indexOf('.at-sidebar__burger'), css.indexOf('.at-nav-restore'));

        expect(burger).toMatch(/color:\s*var\(--at-side-muted\)/);
        expect(burger).toMatch(/background:\s*var\(--at-side-hover\)/);
    });

    it('the floating restore button sits over the page, so it uses page tokens', () => {
        const restore = css.slice(css.indexOf('.at-nav-restore {'), css.indexOf('@media (max-width: 1023px) {\n    /* The drawer owns'));

        expect(restore).toMatch(/background:\s*var\(--at-surface\)/);
        expect(restore).toMatch(/color:\s*var\(--at-text-body\)/);
    });
});

/**
 * Why a source can drop out of a search, and saying so.
 *
 * This exists because the panel once told a user "Spigot could not be reached
 * just now" for a request that had never left their machine. A blocker ate it.
 * The message named a cause the page had no way of knowing, and the user was left
 * waiting for an outage that was never going to end.
 *
 * The three causes are indistinguishable from the page's side unless the reason
 * is kept: an HTTP error, an offline device, and a request refused before it was
 * sent all arrive as "the promise rejected". Only the last is the one where
 * retrying is pointless and the user has to change something.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const providers = readFileSync(join(__dirname, 'api/server/plugins/providers.ts'), 'utf8');
const container = readFileSync(join(__dirname, 'components/server/plugins/PluginsContainer.tsx'), 'utf8');

describe('a dropped source keeps its reason', () => {
    it('every catch records one', () => {
        // A bare `catch(() => failed.push(name))` is the original defect: the
        // name is kept and the cause is thrown away.
        expect(providers).not.toMatch(/\.catch\(\(\) => \{\s*\n\s*failed\.push/);

        const catches = providers.match(/failed\.push\(\{ provider: '/g) ?? [];

        expect(catches).toHaveLength(4);
    });

    it('and records it as a named field, not a spread', () => {
        // `...classify(e)` spreads a STRING, which yields {0:'b',1:'l',...}. That
        // was written, caught, and is pinned here because it type-checks fine and
        // produces a nonsense object at runtime.
        expect(providers).not.toContain('...classify(e)');
        expect(providers).toMatch(/reason: classify\(e\)/);
    });
});

describe('a blocked request is told apart from an outage', () => {
    it('an HTTP status means the source answered', () => {
        expect(providers).toMatch(/typeof e\?\.response\?\.status === 'number'\) \{\s*\n\s*return 'refused';/);
    });

    it('being offline is its own case', () => {
        expect(providers).toMatch(/navigator\.onLine === false[\s\S]{0,80}return 'network';/);
    });

    it('and online-with-no-response is reported as blocked', () => {
        // The case that actually bit: online, but the request never left. No
        // status, because nothing answered.
        expect(providers).toMatch(/return 'blocked';/);
    });

    it('the wording tells the user what to do', () => {
        // "Could not be reached" is a guess. This says a blocker is the usual
        // cause, which is the difference between waiting and switching something
        // off.
        expect(providers).toContain('was blocked before it left your browser');
        expect(providers).toContain('ad blocker or privacy extension');
    });
});

describe('the page shows the reason, not a guess', () => {
    it('the notice renders the classified reason', () => {
        expect(container).toContain('describeFailure(f)');
        expect(container).not.toContain('could not be reached just now.');
    });

    it('and the state carries the reason through', () => {
        expect(container).toMatch(/useState<ProviderFailure\[\]>\(\[\]\)/);
        expect(container).toContain('setDeadProviders(result.failed)');
    });
});

/**
 * How the background image reaches the page.
 *
 * The scrim is emitted server-side in wrapper.blade.php rather than applied by
 * React, for one reason: it has to be in the head before first paint. Done from
 * the bundle it would show the plain background for a moment on every page
 * load, which is the same flash the theme script above it exists to prevent.
 *
 * That decision puts the composition in a Blade template, where there is no unit
 * to test. So these assertions are structural -- they read the template and check
 * the properties that matter. They are weaker than a rendered-page test and it
 * is worth saying so: a Blade directive change that kept the strings below would
 * still pass. The PHP suite covers the service; this covers the wiring.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const wrapper = readFileSync(join(__dirname, '../views/templates/wrapper.blade.php'), 'utf8');
const themeCss = readFileSync(join(__dirname, 'assets/aternos.css'), 'utf8');
const config = readFileSync(join(__dirname, '../../config/theme.php'), 'utf8');

/** The emitted style block, from the @if to its @endif. */
const block = (() => {
    const start = wrapper.indexOf("@if(!empty($siteConfiguration['background']['url']))");

    if (start < 0) throw new Error('no background guard in the wrapper');

    const end = wrapper.indexOf('@endif', start);

    if (end < 0) throw new Error('unterminated background block');

    return wrapper.slice(start, end);
})();

describe('the default panel is untouched', () => {
    it('nothing is emitted unless a url is set', () => {
        // The important one. `url` is null when no image exists, and null has to
        // mean "emit no rule" rather than "emit a rule with an empty url" --
        // the latter would put url('') in every visitor's stylesheet.
        expect(block).toMatch(/@if\(!empty\(\$siteConfiguration\['background'\]\['url'\]\)\)/);
    });

    it('the stylesheet has no hardcoded background image of its own', () => {
        // If the theme carried a url, an operator clearing the background would
        // still see a picture.
        expect(themeCss).not.toMatch(/url\((?!['"]?data:)['"]?\/backgrounds\//);
    });
});

describe('the scrim is emitted per mode, not once for both', () => {
    it('both theme classes get their own rule', () => {
        expect(block).toContain('.aternos-blue body {');
        expect(block).toContain('.aternos-dark body {');
    });

    it('each uses its own page colour from config', () => {
        // A single shared scrim would be right in one theme and visibly wrong in
        // the other, because the two page colours are nothing alike.
        expect(block).toContain("config('theme.background_page.blue')");
        expect(block).toContain("config('theme.background_page.dark')");
        expect(config).toMatch(/'blue'\s*=>\s*'[\d, ]+'/);
        expect(config).toMatch(/'dark'\s*=>\s*'[\d, ]+'/);
    });

    it('the two config values are actually different', () => {
        const values = [...config.matchAll(/'(?:blue|dark)'\s*=>\s*'([\d, ]+)'/g)].map((m) => m[1]);

        expect(values).toHaveLength(2);
        expect(values[0]).not.toBe(values[1]);
    });
});

describe('the scrim is what keeps the text readable', () => {
    it('the alpha IS dim, not its complement', () => {
        // The gradient's alpha is how much page colour sits over the photo, so
        // it is `dim` itself. This was briefly documented the other way round --
        // "a layer at (1 - dim) opacity" -- which would mean dim=0 left a bare
        // photograph behind the text and dim=0.95 hid the operator's image
        // almost completely, the exact inverse of what the admin copy promises.
        // The implementation and the slider agree; only the comment was wrong,
        // and this is here so it cannot drift back.
        expect(block).toMatch(/\$rgb, \$atBgScrim, \$rgb, \$atBgScrim, \$atBgUrl/);
        expect(block).not.toMatch(/1 - \$atBgScrim/);
    });

    it('and dim is clamped before it is used', () => {
        expect(block).toMatch(/\$atBgScrim\s*=\s*round\(max\(0\.0,\s*min\(0\.95/);
    });

    it('the gradient is layered over the image, not beside it', () => {
        // A comma between the two layers; a space would replace the image with a
        // gradient and the operator's photo would silently not appear.
        expect(block).toMatch(/linear-gradient\(rgba\([\s\S]*?\), rgba\([\s\S]*?\), url\(/);
    });
});

describe('nothing operator-supplied reaches the stylesheet raw', () => {
    it('the url is quoted inside url()', () => {
        // Quoting happens in the sprintf format string, since the layer list is
        // built by a closure so the two modes can share it.
        expect(block).toMatch(/url\('%s'\)/);
    });

    it('and it comes from the service, not from request input', () => {
        // BackgroundService builds it as asset('backgrounds/' . $file) where $file
        // is a content hash plus an extension from a fixed allowlist, so it
        // cannot contain a quote to break out of the url() above. Asserted here
        // as a reminder, because that safety lives in another file.
        expect(block).toMatch(/\$atBgUrl\s*=\s*\$atBg\['url'\]/);
    });
});

describe('the theme does not stomp the image it is given', () => {
    /*
     * This is the bug that made the feature appear to do nothing.
     *
     * The theme's body rule was `background: var(--at-page)` -- the shorthand,
     * which resets every background longhand it does not mention, so it set
     * background-image back to `none`. The operator's image is emitted as an
     * inline <style> in the head, and that lands BEFORE this stylesheet at equal
     * specificity, so the theme won. The image was served, reachable over HTTP,
     * correctly named in the payload, and never displayed. Nothing errored.
     *
     * So the property to pin is that the body rule sets only a colour. Any use
     * of the shorthand there silently disables the whole feature again.
     */
    const bodyRule = (() => {
        const found = themeCss.match(/\.aternos-blue body,\s*\.aternos-dark body\s*\{([^}]*)\}/);

        if (!found) throw new Error('no body rule in the theme');

        return found[1];
    })();

    it('the body rule sets a background-COLOR, not the shorthand', () => {
        expect(bodyRule).toMatch(/background-color:\s*var\(--at-page\)/);
        expect(bodyRule).not.toMatch(/(^|[^-])background:\s/);
    });

    it('nothing between the body and the content paints over it', () => {
        // Even with the declaration fixed, a full-bleed opaque background on a
        // descendant would hide the image just as effectively. body and html are
        // excluded on purpose: the image and the colour are both on the body, and
        // background-image paints over background-color on the same element.
        const covers = ['#app', '.at-shell', '.at-shell__main', '.at-page', '.at-content'];
        const offenders: string[] = [];

        covers.forEach((selector) => {
            const pattern = new RegExp(
                `\\.aternos-(?:blue|dark)\\s+${selector.replace('.', '\\.')}\\s*\\{([^}]*)\\}`,
                'g'
            );

            for (const match of themeCss.matchAll(pattern)) {
                const opaque = /background(-color)?\s*:\s*(?![^;]*none)(?![^;]*transparent)/;
                if (opaque.test(match[1])) {
                    offenders.push(selector);
                }
            }
        });

        expect(offenders).toEqual([]);
    });

    it('the emitted rule leaves the body colour alone as a fallback', () => {
        // If the image 404s or is still loading, background-image simply does
        // not paint and the page colour shows through. Setting it to transparent
        // would leave a white flash instead.
        expect(block).not.toMatch(/background-color:\s*transparent/);
    });
});

describe('the url survives being echoed into a <style> block', () => {
    /*
     * The second bug, and the one that made this look like a no-op even after the
     * shorthand was fixed.
     *
     * `{{ }}` escapes an apostrophe to &#039;. <style> is a raw-text element where
     * entities are NOT decoded, so the browser received url(&#039;https://...&#039;)
     * -- an invalid url. The image was uploaded, on disk, reachable over HTTP,
     * correctly named in the payload, and never displayed. It is invisible in
     * the source, because the source looks fine.
     *
     * The rendered page is the only place it shows, which is why this asserts the
     * emitted form rather than reading the PHP that builds it.
     */
    it('the background-image is echoed unescaped', () => {
        // Both modes, and the {!! !!} must be closed with !!} -- an unbalanced
        // pair does not fail here, it fails to compile the whole view.
        const emissions = [...block.matchAll(/background-image:\s*(\{[\s\S]*?\})/g)].map((m) => m[1]);

        expect(emissions).toHaveLength(2);
        emissions.forEach((e) => {
            expect(e).toMatch(/^\{!!/);
            expect(e).toMatch(/!!\}$/);
        });
    });

    it('nothing else in the block is left unbalanced', () => {
        // Cheap guard against the {{ / {!! mix-up that just happened: an
        // opening with no matching close throws at compile time and takes the
        // entire page down, not just this feature.
        const opens = (block.match(/\{!!/g) ?? []).length + (block.match(/\{\{/g) ?? []).length;
        const closes = (block.match(/!!\}/g) ?? []).length + (block.match(/\}\}/g) ?? []).length;

        expect(opens).toBe(closes);
    });

    it('the keyword values stay escaped, since they need no trust', () => {
        // Only the url is unescaped, and only because it cannot contain a quote.
        // Everything else is an internal keyword and keeps the default escaping.
        expect(block).toMatch(/background-size:\s*\{\{/);
        expect(block).toMatch(/background-repeat:\s*\{\{/);
    });
});

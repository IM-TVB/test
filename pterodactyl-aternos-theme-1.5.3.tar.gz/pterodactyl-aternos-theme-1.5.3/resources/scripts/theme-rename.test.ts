/**
 * The light -> blue rename, and the migration it depends on.
 *
 * The rename touched four files that have to agree: the stylesheet, the hook
 * that owns the theme state, the pre-paint script in the blade template, and the
 * toggle that names the mode to the user. Renaming them one at a time is the
 * dangerous part, and the failure is silent and severe:
 *
 *   `.aternos-theme` no longer matches ANY rule in the stylesheet. A page still
 *   carrying that class gets no theme styling at all -- no background, no
 *   colours, an unstyled panel. Nothing errors. It just looks broken.
 *
 * So the assertions here are mostly about agreement BETWEEN files rather than
 * about any one file being right, because "this file is self-consistent" is
 * exactly what a partial rename looks like while it is still broken.
 *
 * The migration is the other half. Anyone who visited before the rename has
 * `light` in localStorage. They have to land on blue without a flash of
 * unstyled panel, which means the pre-paint script -- not React -- has to clear
 * the old class, because React runs after first paint.
 */

import { readFileSync } from 'fs';
import { join } from 'path';
import { normalise } from '@/plugins/useTheme';

/**
 * The blade template lives outside resources/scripts. __dirname is
 * <root>/resources/scripts, so one `..` reaches <root>/resources, which is where
 * views/ sits -- not <root>, which is where the first attempt looked and found
 * nothing.
 */
const read = (p: string) => readFileSync(join(__dirname, p), 'utf8');
const readTemplate = (p: string) => readFileSync(join(__dirname, '..', p), 'utf8');

const css = read('assets/aternos.css');
const useTheme = read('plugins/useTheme.ts');
const wrapper = readTemplate('views/templates/wrapper.blade.php');
const nav = read('components/NavigationBar.tsx');

/** Class names that appear as a selector in the stylesheet. */
const selectorsInCss = () => new Set(css.match(/\.aternos-[a-z-]+/g) ?? []);

describe('the rename is complete across all four files', () => {
    it('the stylesheet no longer knows the old class', () => {
        // A literal anywhere, selector or comment. The stylesheet's own comment
        // is written to avoid the string for this reason.
        expect(css).not.toMatch(/aternos-theme/);
    });

    it('nothing anywhere still APPLIES the old class', () => {
        // The one direction that breaks users. Adding the old class puts
        // <html> into a state no rule matches.
        //
        // Checked per file rather than as one blob so a failure names the file
        // that has to change. `classList.add` and `classList.add(...)` are the
        // only ways the theme reaches the DOM.
        const adds = (src: string) =>
            [...src.matchAll(/classList\.add\(([^)]*)\)/g)].map((m) => m[1]);

        const offenders: string[] = [];

        [
            ['useTheme.ts', useTheme],
            ['wrapper.blade.php', wrapper],
        ].forEach(([name, src]) => {
            adds(src as string).forEach((arg) => {
                if (arg.includes('LEGACY') || arg.includes('aternos-theme')) {
                    offenders.push(`${name}: classList.add(${arg})`);
                }
            });
        });

        expect(offenders).toEqual([]);
    });

    it('the stylesheet defines both current classes as selectors', () => {
        const selectors = selectorsInCss();

        expect(selectors.has('.aternos-blue')).toBe(true);
        expect(selectors.has('.aternos-dark')).toBe(true);
    });

    it('the hook and the pre-paint script agree on the class names', () => {
        // They are two implementations of the same decision. If they disagree,
        // React will "correct" the class on the first interaction and the panel
        // repaints under the user.
        const BLUE = 'aternos-blue';
        const DARK = 'aternos-dark';

        expect(useTheme).toContain(`const BLUE = '${BLUE}'`);
        expect(useTheme).toContain(`const DARK = '${DARK}'`);
        expect(wrapper).toContain(`var BLUE = '${BLUE}'`);
        expect(wrapper).toContain(`var DARK = '${DARK}'`);

        // And both must be able to remove what the other adds.
        expect(useTheme).toMatch(/classList\.remove\(BLUE, DARK/);
        expect(wrapper).toMatch(/classList\.remove\(BLUE, DARK/);
    });

    it('they agree on the storage key', () => {
        const key = 'pterodactyl:theme';

        expect(useTheme).toContain(`'${key}'`);
        expect(wrapper).toContain(`'${key}'`);
    });
});

describe('the migration handles every value the panel has ever written', () => {
    // Driven against the real exported function rather than a copy of its logic.
    // A replica here would pass even if useTheme were wrong, which is the trap
    // this file is most exposed to: the migration is only correct if the code
    // that ships and the code under test are the same code.
    it.each([
        ['blue', 'blue'],
        ['dark', 'dark'],
        ['light', 'blue'], // pre-rename value: they were on light, which is now blue
        [null, 'blue'], // first visit, nothing stored
        ['', 'blue'],
        ['nonsense', 'blue'],
        ['DARK', 'blue'], // case-sensitive on purpose; never written by us
    ])('stored %p resolves to %p', (stored, expected) => {
        expect(normalise(stored as string | null)).toBe(expected);
    });

    it('the pre-paint script defaults to blue, not to the retired light', () => {
        // A fresh visitor with storage disabled must still get the theme.
        expect(wrapper).toMatch(/var theme = 'blue';/);
        expect(wrapper).not.toMatch(/var theme = 'light';/);
    });

    it('the pre-paint script rewrites the legacy stored value', () => {
        // Otherwise the legacy spelling lingers in storage forever and any future
        // reader of that key has to know about it again.
        expect(wrapper).toMatch(/LEGACY_VALUE = 'light'/);
        expect(wrapper).toMatch(/setItem\('pterodactyl:theme', theme\)/);
        expect(wrapper).toMatch(/stored !== null && stored !== theme/);
    });

    it('the pre-paint script removes the legacy class', () => {
        // The one that matters. It runs before first paint, so it is the only
        // thing standing between a returning visitor and an unstyled panel.
        expect(wrapper).toMatch(/LEGACY_CLASS = 'aternos-theme'/);
        expect(wrapper).toMatch(/classList\.remove\(BLUE, DARK, LEGACY_CLASS\)/);
    });

    it('the hook also clears the legacy class, for the back/forward cache', () => {
        // A page restored from bfcache is handed to React with whatever class it
        // had, which may be the pre-rename one.
        expect(useTheme).toMatch(/LEGACY_CLASS = 'aternos-theme'/);
        expect(useTheme).toMatch(/classList\.remove\(BLUE, DARK, LEGACY_CLASS\)/);
    });
});

describe('the mode is called blue to the user', () => {
    it('the toggle names blue, not light', () => {
        expect(nav).toContain("? 'Blue mode' : 'Dark mode'");
        expect(nav).not.toContain("'Light mode'");
    });

    it('the toggle describes the switch in blue terms too', () => {
        // Both the aria-label and the title, which are what a screen reader
        // announces and what a tooltip shows.
        expect(nav.match(/Switch to blue mode/g)).toHaveLength(2);
        expect(nav).not.toMatch(/Switch to light mode/);
    });

    it('the hook exposes blue as a theme, not light', () => {
        expect(useTheme).toMatch(/export type Theme = 'blue' \| 'dark';/);
        expect(useTheme).not.toMatch(/export type Theme = 'light'/);
    });
});

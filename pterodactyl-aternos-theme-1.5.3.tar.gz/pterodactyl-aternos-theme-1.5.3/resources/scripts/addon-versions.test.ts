/**
 * The version picker.
 *
 * The feature is "let someone pick a version" instead of always being handed the
 * newest build. That is easy to state and easy to get subtly wrong, because the
 * failure is silent: pick the wrong version and the install *succeeds*, the file
 * is a real jar, and the server ends up on a version nobody chose.
 *
 * So the assertions here are about the two ways that happens:
 *
 *   1. A chosen version being re-resolved to "latest" somewhere downstream. The
 *      picker would say 1.2.3 and the server would get 2.0.0.
 *   2. A row offering a download the source cannot perform. Spigot will list
 *      forty versions and refuse all but the newest.
 *
 * It also pins the Spigot bypass, which is the one place the panel route stops
 * being a fallback and becomes the only route -- see the note in install.ts.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const read = (p: string) => readFileSync(join(__dirname, p), 'utf8');

const providers = read('api/server/plugins/providers.ts');
const install = read('api/server/plugins/install.ts');
const spiget = read('api/server/plugins/spiget.ts');
const hangar = read('api/server/plugins/hangar.ts');
const curseforge = read('api/server/plugins/curseforge.ts');
const modal = read('components/server/plugins/AddOnVersions.tsx');
const container = read('components/server/plugins/PluginsContainer.tsx');

describe('a chosen version is installed as that version', () => {
    it('modrinth looks it up by id instead of re-picking', () => {
        // pickVersion() over the same list would ignore the choice entirely and
        // return the newest compatible build.
        expect(install).toMatch(/opts\.chosen\s*\?\s*\n?\s*versions\.find\(\(v\) => v\.id === opts\.chosen!\.id\)/);
        expect(install).not.toMatch(/const version = pickVersion\(versions[^;]*chosen/);
    });

    it('hangar resolves the named build, not the newest', () => {
        expect(install).toMatch(/chosen\s*\?\s*await getHangarFile\(hit\.hangarSlug!, chosen\.id\)/);
        expect(hangar).toContain('/versions/${encodeURIComponent(versionName)}');
    });

    it('curseforge downloads the chosen file id', () => {
        // A CurseForge file IS a version, so falling back to the search hit's
        // fileId installs the newest build while the picker says otherwise.
        expect(install).toMatch(/const fileId = chosen \? Number\(chosen\.id\) : hit\.curseforgeFileId/);
    });

    it('a plain install is unaffected', () => {
        // Every other caller passes nothing, and must still get the newest. The
        // default lives on the parameter, not at the call site, so the card's
        // own Install button cannot start pinning a version by accident.
        expect(container).toMatch(/const onInstall = async \(hit: AddOnHit, version: AddOnVersion \| null = null\)/);
        // The chosen version is handed over in the container, not in install.ts.
        expect(container).toMatch(/chosen: version,/);
    });
});

describe('spigot does not pretend', () => {
    it('the chosen version skips the direct route entirely', () => {
        /*
         * cdn.spiget.org serves the resource's NEWEST jar at /{id}.jar and 404s
         * for per-version paths. So the direct download of an older version does
         * not fail -- it succeeds and returns the wrong jar. withPanelFallback
         * would treat that success as done. This is the one place the panel
         * route is not a fallback but the only route.
         */
        expect(install).toMatch(/const \{ blob, filename \} = chosen\s*\?[\s\S]{0,900}?downloadViaPanel\(/);
    });

    it('and it goes to the panel with the version identifier', () => {
        expect(install).toContain('{ id, version: chosen.id }');
    });

    it('the list is still shown in full', () => {
        // Hiding the versions Spigot cannot serve would make the picker look
        // broken; showing them with no button is honest.
        expect(modal).toMatch(/version\.installable \? \(/);
        expect(modal).toContain('not downloadable');
    });
});

describe('the picker opens from a result', () => {
    it('the card title is the control', () => {
        expect(container).toMatch(/className=\{'at-pcard__head at-pcard__head--link'\}/);
        expect(container).toContain('onClick={() => setPicking(hit)}');
    });

    it('and the modal is mounted once, not per result', () => {
        // One per card would be N modals in the DOM, N of them fetching.
        expect(container.match(/<AddOnVersions/g)).toHaveLength(1);
        expect(container).toMatch(/\{picking \? \(/);
    });

    it('it closes on success but not on failure', () => {
        // Closing on failure throws away the selection and leaves the user
        // re-picking to retry the same version.
        expect(container).toMatch(/setPicking\(null\);\s*\n\s*addFlash\(/);
    });
});

describe('every source can be asked for versions', () => {
    it.each([
        ['spiget', spiget, 'getSpigotVersions'],
        ['hangar', hangar, 'getHangarVersions'],
        ['curseforge', curseforge, 'getCurseForgeVersions'],
        ['modrinth', providers, 'getModrinthVersions'],
    ])('%s has a version lister', (_name, src, fn) => {
        expect(src).toContain(fn);
    });

    it('and the dispatcher maps all four', () => {
        ['modrinth', 'spigot', 'hangar', 'curseforge'].forEach((p) => {
            expect(providers).toContain(`hit.provider === '${p}'`);
        });
        expect(providers).toContain('export const versionsFor');
    });

    it('a source that cannot be asked yields an empty list, not a crash', () => {
        // A version picker that hard-fails takes the whole browser page with it,
        // and the caller already handles "no versions" by falling back.
        expect(providers).toMatch(/catch \(e\) \{\s*\n\s*return \[\];/);
    });

    it('installable is carried from the provider, not assumed in the UI', () => {
        // Spigot rows are installable -- the panel can fetch them -- but only the
        // newest is installable from the browser, and the list says so in the
        // comment rather than hiding the versions it cannot serve.
        const spigotBranch = providers.slice(
            providers.indexOf("hit.provider === 'spigot'"),
            providers.indexOf("hit.provider === 'hangar'")
        );

        expect(spigotBranch).toContain('installable: true');
        expect(spigotBranch).toContain('Only the newest is fetchable from the browser');
        expect(modal).toMatch(/\{version\.installable \? \(/);
        // A row that cannot be installed must not render a button.
        // \s+ after <span: the element gained a second attribute (the row's own
        // reason) and was wrapped across lines, which the exact-match form read
        // as a missing affordance.
        expect(modal).toMatch(/\) : \(\s*<span\s+className=\{'at-vmodal__version-why'\}/);
    });
});

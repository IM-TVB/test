/**
 * How the login page's own background reaches the auth screen.
 *
 * The login page could not show a background before this. The panel's background
 * is applied to <body>, and the auth screen is `.at-auth` — a full-viewport grid
 * inside React's #app that paints an opaque `background: var(--at-page)`, with an
 * opaque hard-coded gradient on its left half. So the body image was completely
 * hidden there, and no admin setting could reach the gradient.
 *
 * The fix threads the image in as a CSS *custom property* on body, which the
 * stylesheet then reads with the old values as fallbacks. Two properties of that
 * choice are load-bearing and asserted here:
 *
 *   1. Inheritance. A rule in the wrapper targeting `.at-auth` would have to win a
 *      specificity contest against `.aternos-blue .at-auth` in the bundle, and the
 *      wrapper's inline <style> is emitted *before* that bundle, so it would lose.
 *      A custom property is not a competing declaration — the stylesheet keeps the
 *      only rule and the wrapper just supplies a value.
 *
 *   2. The fallbacks. With no image set the auth screen must look exactly as it
 *      did. If either fallback is dropped, the login page silently loses its
 *      background instead of keeping the old one.
 *
 * Like background-image.test.ts, these are structural assertions on the
 * template and the stylesheet rather than a rendered page: a Blade change that
 * kept the strings would still pass. test-auth-background.php covers the service
 * and what the composer hands the view.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const wrapper = readFileSync(join(__dirname, '../views/templates/wrapper.blade.php'), 'utf8');
const themeCss = readFileSync(join(__dirname, 'assets/aternos.css'), 'utf8');

/**
 * The auth block in the wrapper, from its @if to its @endif.
 *
 * Returns an empty string rather than throwing when the guard is missing. The
 * original threw, which is how sibling tests in this directory are written, but it
 * means one renamed key takes the whole file down: a control that changed the
 * composer's key to `auth_background` killed all sixteen assertions at module load
 * and reported "0 total", which is a detection but tells you nothing and verifies
 * nothing else. A missing guard now fails exactly one assertion and the other
 * fifteen still run.
 */
const authBlock = (() => {
    const guard = "@if(!empty($siteConfiguration['authBackground']['url']))";
    const start = wrapper.indexOf(guard);

    if (start < 0) return '';

    const end = wrapper.indexOf('@endif', start);

    if (end < 0) return wrapper.slice(start);

    return wrapper.slice(start, end);
})();

/**
 * One CSS rule's declarations, found by any one of its selectors.
 *
 * The theme writes these as comma-separated groups -- `.aternos-blue .at-auth,
 * .aternos-dark .at-auth` -- so a naive `${selector} {` lookup finds nothing and
 * the first version of this reported nine failures against CSS that was correct.
 * The selector list is walked back to the brace that opens it instead.
 */
/*
 * A selector has to be matched as a whole token, not as a substring.
 *
 * `themeCss.indexOf('.aternos-blue .at-auth')` also matches
 * `.aternos-blue .at-auth__aside` and `.aternos-blue .at-auth-card`, of which there
 * are eighteen. A lookup for the auth screen's own box would therefore start by
 * reading the aside's declarations, and every assertion built on it would pass
 * against the wrong rule. It did, once: the first version of this helper matched
 * a wrapper rule and three assertions failed against CSS that was correct.
 */
const rule = (selector: string) => {
    /*
     * Anchored to the start of a line, with the selector required to be followed
     * by a comma or a brace.
     *
     * The brace is what keeps `.at-auth` from matching `.at-auth__aside` -- the
     * next character there is `_`, not a `,` or `{` -- and the `m` flag is what lets
     * `^` mean the start of a selector line without needing a newline inside a
     * character class. An earlier version used `(?:^|[\n,])`, which took three
     * attempts to get right through two levels of string escaping and then
     * matched one of the two selectors and not the other, from the same source.
     */
    const escaped = selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const found = new RegExp(`^\\s*${escaped}\\s*[,{]`, 'm').exec(themeCss);

    if (!found) throw new Error(`no rule mentions ${selector}`);

    const at = found.index + found[0].length - 1;

    // Back up over the rest of the selector list, stopping at the `}` or `*/`
    // that ends whatever came before it.
    let start = themeCss.lastIndexOf('}', at);
    const commentEnd = themeCss.lastIndexOf('*/', at);

    if (commentEnd > start) {
        start = commentEnd;
    }

    start = themeCss.indexOf('\n', start) === -1 ? 0 : themeCss.lastIndexOf('\n', start) + 1;

    const brace = themeCss.indexOf('{', at);

    if (brace < 0) throw new Error(`the rule for ${selector} has no body`);

    // Drop any comment inside the body: these rules are heavily commented, and a
    // comment mentioning an old value would satisfy a containment assertion.
    const body = themeCss.slice(brace + 1, themeCss.indexOf('}', brace)).replace(/\/\*[\s\S]*?\*\//g, '');

    return body;
};

describe('the auth screen rule', () => {
    it('reads the image from an inherited custom property', () => {
        expect(rule('.aternos-blue .at-auth')).toContain('background: var(--at-auth-bg');
    });

    it('and falls back to the page colour, so an unset background changes nothing', () => {
        // Without this the login page would have no background at all rather
        // than the one it had before, which is the one thing that must not move.
        expect(rule('.aternos-blue .at-auth')).toMatch(/var\(--at-auth-bg,\s*var\(--at-page\)\)/);
        expect(rule('.aternos-dark .at-auth')).toMatch(/var\(--at-auth-bg,\s*var\(--at-page\)\)/);
    });

    it('no longer paints an opaque page colour over the image', () => {
        // The original line was a bare `background: var(--at-page)`, which is what
        // hid the body background. It has to be the fallback, not the value.
        expect(rule('.aternos-blue .at-auth')).not.toMatch(/background:\s*var\(--at-page\)\s*;/);
    });

    it('sizes the image to cover the screen', () => {
        const declarations = rule('.aternos-blue .at-auth');

        expect(declarations).toContain('background-size: cover');
        expect(declarations).toContain('background-repeat: no-repeat');
    });
});

describe('the auth screen aside', () => {
    it('reads a custom property', () => {
        expect(rule('.aternos-blue .at-auth__aside')).toContain('background: var(--at-auth-aside');
    });

    it('and still has the original gradient as its fallback', () => {
        // The exact gradient the theme shipped. Asserted as a literal rather than
        // "some gradient", because the point is that a panel with no login
        // background keeps the colours it had, and there is nothing else to
        // compare against.
        expect(rule('.aternos-blue .at-auth__aside')).toContain(
            'linear-gradient(150deg, #0b6fd4 0%, #004d99 55%, #00335f 100%)'
        );
    });

    it('so with nothing set it is still fully opaque', () => {
        // A fallback with an alpha would tint whatever is behind it, which is the
        // page colour -- the panel would look washed out with no image set.
        const fallback = /var\(--at-auth-aside,\s*([^)]*)\)\)/.exec(rule('.aternos-blue .at-auth__aside'))?.[1] ?? '';

        expect(fallback).toContain('#0b6fd4');
        expect(fallback).not.toMatch(/rgba?\([^)]*0?\.\d+\)/);
    });
});

describe('what the wrapper emits for it', () => {
    it('sets the property on body, so it inherits into the React tree', () => {
        expect(authBlock).toContain('.aternos-blue body {');
        expect(authBlock).toContain('.aternos-dark body {');
    });

    it('for both variables in both modes', () => {
        /*
         * Split on the mode marker, not by counting braces.
         *
         * Slicing each rule to the first `}` stops inside the first declaration,
         * because a Blade echo ends `!!};` -- there is a closing brace inside the
         * rule before the rule is over. The first version of this sliced to that
         * brace and so could never have seen --at-auth-aside, which made the
         * assertion impossible to pass rather than wrong about the CSS.
         */
        const blue = authBlock.indexOf('.aternos-blue body {');
        const dark = authBlock.indexOf('.aternos-dark body {');

        expect(blue).toBeGreaterThan(-1);
        expect(dark).toBeGreaterThan(blue);

        for (const [mode, body] of [
            ['blue', authBlock.slice(Math.max(blue, 0), Math.max(dark, 0))],
            ['dark', authBlock.slice(Math.max(dark, 0))],
        ] as const) {
            expect(body).toContain('--at-auth-bg:');
            expect(body).toContain('--at-auth-aside:');
            // And the dark one must actually be the dark page colour, not a copy
            // of the blue block with the label changed.
            expect(body).toContain(mode === 'dark' ? 'background_page.dark' : 'background_page.blue');
        }
    });

    it('and composes the scrim over the image, page colour first', () => {
        expect(authBlock).toContain("linear-gradient(rgba(%s, %s), rgba(%s, %s)), url('%s')");
    });

    it('with the url echoed raw, because a <style> does not decode entities', () => {
        // {{ }} would turn an apostrophe into &#039;, which inside <style> is a
        // literal, and the url() would silently never load. Same reasoning as the
        // panel background block above it; asserted so the two cannot drift.
        expect(authBlock).toContain('{!! $atAuthLayers(');
        expect(authBlock).not.toContain('{{ $atAuthLayers(');
        expect(authBlock).toContain('{!! $atAuthAside !!}');
    });

    it('caps the scrim at the same ceiling as the panel background', () => {
        expect(authBlock).toContain('min(0.95');
    });

    it('makes the aside translucent so the photograph shows through it', () => {
        const aside = /atAuthAside = '([^']+)'/.exec(authBlock)?.[1] ?? '';

        expect(aside).not.toBe('');
        // Every stop has to be below 1, or it is the opaque original and the
        // image is half-covered.
        for (const alpha of aside.match(/rgba\([^)]*?,\s*([\d.]+)\)/g) ?? []) {
            const value = Number(/,\s*([\d.]+)\)$/.exec(alpha)?.[1] ?? 1);

            expect(value).toBeLessThan(1);
        }
    });

    it('is emitted only when a url exists', () => {
        expect(authBlock).toContain("@if(!empty($siteConfiguration['authBackground']['url']))");
    });

    it('and reads the same key the composer provides', () => {
        // If the composer sent `auth_background` or nested it differently, the
        // guard would be false forever and the page would silently keep the old
        // look with no error anywhere.
        expect(authBlock).toContain("@if(!empty($siteConfiguration['authBackground']['url']))");
        // The dim is read through a local rather than the long path, so the guard
        // and the local assignment are what have to line up.
        expect(authBlock).toMatch(/\$atAuth = \$siteConfiguration\['authBackground'\];/);
        expect(authBlock).toContain("(float) \$atAuth['dim']");
    });

    it('without disturbing the panel background block', () => {
        expect(wrapper).toContain("@if(!empty($siteConfiguration['background']['url']))");
        expect(wrapper).toContain('background-attachment: fixed');
    });
});

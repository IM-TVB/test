/**
 * The sidebar logo in the navigation, and the admin screen that sets it.
 *
 * The property that matters is the fallback: with no logo set the sidebar must
 * draw the initial-letter tile it has always drawn, and with one set it must use
 * the image. The failure mode is an <img> pointed at nothing, which shows a
 * broken image in the sidebar of every page.
 *
 * There is also a load-bearing constraint that is not obvious from the admin
 * page: the admin area loads no theme stylesheet at all, so anything that relies
 * on one is invisible there. That is asserted below, because it produced a
 * full-width black slab the first time.
 */

import { readdirSync, readFileSync } from 'fs';
import { join } from 'path';

const nav = readFileSync(join(__dirname, 'components/NavigationBar.tsx'), 'utf8');
const settings = readFileSync(join(__dirname, 'state/settings.ts'), 'utf8');
const composer = readFileSync(join(__dirname, '../../app/Http/ViewComposers/AssetComposer.php'), 'utf8');
const logoBlade = readFileSync(join(__dirname, '../../resources/views/admin/settings/logo.blade.php'), 'utf8');
const navBlade = readFileSync(join(__dirname, '../../resources/views/partials/admin/settings/nav.blade.php'), 'utf8');
const adminLayout = readFileSync(join(__dirname, '../../resources/views/layouts/admin.blade.php'), 'utf8');
const css = readFileSync(join(__dirname, 'assets/aternos.css'), 'utf8');

describe('the navigation reads the logo from site settings', () => {
    it('from the logo url specifically', () => {
        expect(nav).toMatch(/state\.settings\.data\?\.logo\?\.url/);
    });

    it('with a null fallback, not a bare undefined', () => {
        expect(nav).toMatch(/logo\?\.url\) \|\| null/);
    });

    it('and the settings type declares it as nullable', () => {
        expect(settings).toMatch(/logo:\s*\{\s*url: string \| null;/);
    });
});

describe('the tile is the fallback, and it is deliberate', () => {
    it('an image is only rendered when there is a url', () => {
        expect(nav).toMatch(/logoUrl \? <img src=\{logoUrl\}/);
    });

    it('otherwise the site initial is drawn', () => {
        expect(nav).toMatch(/: initial\}/);
    });

    it('the img is decorative, so it carries an empty alt', () => {
        // The sidebar already spells the panel name out next to the mark, so
        // repeating it in the alt text makes a screen reader say it twice.
        expect(nav).toMatch(/<img src=\{logoUrl\} alt=\{''\}/);
    });

    it('the initial is the same derivation as before', () => {
        expect(nav).toContain("const initial = (name || 'P').trim().charAt(0).toUpperCase();");
    });
});

describe('both places that draw the logo share one', () => {
    it('the mark is built once, not twice in the markup', () => {
        expect(nav).toContain('const logoMark = (size:');
        // Two hand-written copies would drift: one gets the image and the other
        // keeps the letter.
        expect(nav.match(/logoMark\('/g) ?? []).toHaveLength(2);
    });

    it('and the burger bar no longer sizes the logo inline', () => {
        // It used to override width/height/font-size, which meant the letter and
        // an uploaded image had to be sized by two different mechanisms.
        expect(nav).not.toMatch(/at-sidebar__logo'[^}]*style=\{\{/);
    });
});

describe('the css knows about an image inside the tile', () => {
    it('the image fills the tile and is cropped, not letterboxed', () => {
        const rule = css.slice(css.indexOf('.at-sidebar__logoimg {'));

        expect(rule).toContain('object-fit: cover');
        expect(rule).toContain('width: 100%');
        // The inline-image baseline gap shifts the row by a few pixels otherwise.
        expect(rule).toContain('display: block');
        expect(rule).toContain('border-radius: inherit');
    });

    it('both sizes are a rule rather than an inline style', () => {
        expect(css).toContain('.at-sidebar__logo--small');
    });
});

describe('the server hands the theme a url or nothing', () => {
    it('the composer passes the logo to the page', () => {
        expect(composer).toMatch(/'logo' => \$this->logo->forTheme\(\)/);
        expect(composer).toMatch(/private LogoService \$logo/);
    });

    it('and its absence means the tile, which is what the service documents', () => {
        expect(composer).toMatch(/Null url means no logo/);
    });
});

describe('the admin area loads no theme stylesheet', () => {
    it('so the preview cannot borrow the sidebar class', () => {
        // This is the whole reason the preview is inline. The class is defined
        // only in the theme stylesheet, that stylesheet is bundled into the
        // *client* JavaScript, and this layout loads neither -- so the class
        // matched nothing and the preview rendered as a full-width black slab
        // with an enormous letter.
        expect(adminLayout).not.toMatch(/aternos/);
        expect(adminLayout).not.toMatch(/assets\/bundle/);
    });

    it('and the preview therefore carries the values itself', () => {
        expect(logoBlade).toMatch(/width:34px/);
        expect(logoBlade).toMatch(/height:34px/);
        expect(logoBlade).toMatch(/object-fit:cover/);
        expect(logoBlade).toMatch(/display:inline-grid/);
        expect(logoBlade).toMatch(/place-items:center/);
        expect(logoBlade).toMatch(/border-radius:10px/);
        expect(logoBlade).toMatch(/linear-gradient\(135deg,#007bff/);
    });

    it('with no use of a class the admin area cannot resolve', () => {
        // Comments stripped, so the explanation naming the class is not read as a
        // use of it.
        const code = logoBlade.replace(/\{\{--[\s\S]*?--\}\}/g, '');

        expect(code).not.toMatch(/at-sidebar__logo/);
    });

    it('and no admin blade silently depends on the client stylesheet', () => {
        /*
         * Two names are allowed through. They predate this page, sit on screens
         * nobody has reported, and are recorded rather than fixed -- a test that
         * fails on known-broken markup is a test that gets ignored. Remove one
         * from the set only when it is actually fixed.
         */
        const known = new Set(['background.blade.php', 'providers.blade.php']);
        const views = join(__dirname, '../../resources/views/admin');
        const offenders: string[] = [];

        const walk = (dir: string): void => {
            for (const entry of readdirSync(dir, { withFileTypes: true })) {
                const full = join(dir, entry.name);

                if (entry.isDirectory()) {
                    walk(full);
                    continue;
                }

                if (!entry.name.endsWith('.blade.php') || known.has(entry.name)) {
                    continue;
                }

                // Comments are stripped first, and that is not cosmetic. A blade
                // that explains why it must not use a theme token has to be able to
                // *name* the token in the explanation, and the background and logo
                // pages both do exactly that -- so scanning the raw source flagged a
                // comment as a dependency and failed a page that has none. A comment
                // is not a dependency; a comment about one is the opposite.
                const source = readFileSync(full, 'utf8')
                    .replace(/\{\{--[\s\S]*?--\}\}/g, '')
                    .replace(/\/\*[\s\S]*?\*\//g, '')
                    .replace(/<!--[\s\S]*?-->/g, '');

                // A class attribute carrying an at- name, or a style using a theme
                // custom property. Both resolve only against the theme stylesheet.
                if (/class="[^"]*\bat-[a-z]/.test(source) || /var\(--at-/.test(source)) {
                    offenders.push(entry.name);
                }
            }
        };

        walk(views);

        expect(offenders).toEqual([]);
    });
});

describe('the admin screen', () => {
    it('is reachable from the settings tabs', () => {
        expect(navBlade).toMatch(/admin\.settings\.logo/);
    });

    it('shows the image or the letter, in one if/else', () => {
        // The structure, not two copies of the condition: an image in the preview
        // must be the same branch the sidebar's tile is, or the admin page and
        // the sidebar disagree about what is set.
        expect(logoBlade).toMatch(
            /@if\(\$hasImage\)[\s\S]{0,400}\$url[\s\S]{0,300}@else[\s\S]{0,200}\$initial[\s\S]{0,40}@endif/
        );
    });

    it('accepts the formats the service probes, and says why not SVG', () => {
        expect(logoBlade).toContain('accept="image/png,image/jpeg,image/gif,image/webp"');
        expect(logoBlade).toMatch(/SVG is not accepted/);
    });

    it('states the limits the service enforces', () => {
        expect(logoBlade).toContain('$maxBytes');
        expect(logoBlade).toContain('$minDimension');
    });

    it('cannot reset a logo that is not set', () => {
        // A destructive button that always renders is one click on a form that
        // has nothing to do.
        expect(logoBlade).toMatch(
            /@if\(\$hasImage\)[\s\S]{0,600}Restore default[\s\S]{0,400}\@else[\s\S]{0,300}disabled/
        );
    });

    it('its comment blocks are comments, not echoes', () => {
        // `{{ /* ... */ }}` compiles to e() with no arguments and the page 500s,
        // which is what happened on the first attempt.
        const chunks = logoBlade.match(/\{\{(?!--)[\s\S]*?\}\}/g) ?? [];
        const echoes = chunks.filter((chunk) => !chunk.includes('route(') && !chunk.includes('$'));

        expect(echoes).toEqual([]);
    });
});

/**
 * Relevance as a sort, rather than a hidden exception.
 *
 * The interesting property is a negative one. Modrinth already ranked by
 * relevance, and the merge used to re-sort every source by download count --
 * which is strictly worse than not ranking, because it threw away an ordering
 * that answered the question the user asked and replaced it with one that did
 * not. "luck perms" surfaced whichever plugin had the most downloads.
 *
 * So the assertion that matters is that relevance leaves each stream alone, and
 * only interleaves. A test that just checks a `relevance` value exists would
 * pass against exactly the code that was broken.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const providers = readFileSync(join(__dirname, 'api/server/plugins/providers.ts'), 'utf8');
// The sort control is styled, not just rendered, so the CSS is read here too: a
// <select> with no appearance reset draws the native arrow into the padding and
// reads as a text input.
//
// Each helper returns ONE rule, up to its closing brace. Slicing to a later
// landmark instead swept in the rules that follow, which is how hardcoding the
// control's own background passed a "uses tokens" assertion -- the tokens were
// right there in the next rule.
const css = () => readFileSync(join(__dirname, 'assets/aternos.css'), 'utf8');
const rule = (selector: string) => {
    const source = css();
    const at = source.indexOf(selector);

    expect(at).toBeGreaterThan(-1);

    return source.slice(at, source.indexOf('}', at));
};
const selectRule = () => rule('.at-sort__select {');
const selectOptionRule = () => rule('.at-sort__select option {');

/**
 * A custom property as declared inside one mode block.
 *
 * Anchored on a blank line before the selector, and that is load-bearing twice
 * over. The shared block's selector LIST ends in `.aternos-dark {`, so both a
 * plain indexOf and a line-anchored regex resolve `.aternos-dark` to the SHARED
 * block and read no palette tokens from it. A shared block introduced by a dashed
 * comment rule is found by its two-line selector list instead.
 */
const modeTokens = (scope: string): Record<string, string> => {
    const at = css().indexOf('\n\n' + scope + ' {');

    expect(at).toBeGreaterThan(-1);

    const body = css().slice(at, css().indexOf('\n}', at));
    const out: Record<string, string> = {};

    for (const [, name, value] of body.matchAll(/(--at-[a-z0-9-]+):\s*([^;]+);/g)) {
        out[name] = value.trim();
    }

    return out;
};

const modeToken = (name: string, scope: string): string => {
    const fromMode = modeTokens(scope)[name];

    if (fromMode) {
        return fromMode;
    }

    // Not every token is redeclared per mode; the rest live in the shared block.
    const at = css().indexOf('.aternos-blue,\n.aternos-dark {');
    const shared = css().slice(at, css().indexOf('\n}', at));
    const found = shared.match(new RegExp(name + ':\\s*([^;]+);'));

    expect(found).not.toBeNull();

    return found![1].trim();
};

/** '#abc' or 'hsl(210, 16%, 82%)' to [r, g, b]. The palettes use both. */
const toRgb = (value: string): [number, number, number] => {
    if (value.startsWith('#')) {
        let h = value.slice(1);

        if (h.length === 3) {
            h = h
                .split('')
                .map((c) => c + c)
                .join('');
        }

        return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)) as [number, number, number];
    }

    const m = value.match(/hsl\(\s*([\d.]+)\s*,\s*([\d.]+)%\s*,\s*([\d.]+)%/);

    expect(m).not.toBeNull();

    const [h, sat, l] = [parseFloat(m![1]) / 360, parseFloat(m![2]) / 100, parseFloat(m![3]) / 100];
    const hue = (t: number) => {
        const k = (n: number) => (n + h * 12) % 12;
        const a = sat * Math.min(l, 1 - l);
        const f = (n: number) => l - a * Math.max(-1, Math.min(k(n) - 3, 9 - k(n), 1));
        return Math.round(f(0) * 255);
    };

    return [hue(0), hue(8), hue(4)];
};

const relativeLuminance = ([r, g, b]: [number, number, number]): number => {
    const ch = (c: number) => {
        const v = c / 255;
        return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
    };

    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b);
};

const contrastRatio = (a: string, b: string): number => {
    const la = relativeLuminance(toRgb(a));
    const lb = relativeLuminance(toRgb(b));
    const [hi, lo] = la > lb ? [la, lb] : [lb, la];

    return (hi + 0.05) / (lo + 0.05);
};
const container = readFileSync(
    join(__dirname, 'components/server/plugins/PluginsContainer.tsx'),
    'utf8'
);

describe('relevance is a sort, and the default one', () => {
    it('is in the sort type', () => {
        expect(providers).toContain("export type AddOnSort = 'relevance' | 'downloads' | 'name' | 'mixed';");
    });

    it('is what the page starts on', () => {
        expect(container).toMatch(/useState<AddOnSort>\('relevance'\)/);
        expect(container).not.toMatch(/useState<AddOnSort>\('downloads'\)/);
    });

    it('is the first option, because it is the default', () => {
        const options = container.slice(container.indexOf("['relevance', 'Relevance']") - 40);

        expect(options).toContain("['relevance', 'Relevance']");
        expect(options.indexOf("['relevance'")).toBeLessThan(options.indexOf("['downloads'"));
    });

    it('and it says what it does', () => {
        // "Relevance" alone does not say whether the sources are re-ranked, which
        // is the whole difference between this and "Even mix".
        expect(container).toContain("Each source's own best match for what you typed");
    });

    it('every sort is explained, not only relevance', () => {
        // The wording moved out of a nested ternary into a lookup, so a sort
        // added without an explanation is now visible rather than silent.
        expect(container).toMatch(/const SORT_EXPLAINED: Record<AddOnSort, string> = \{/);

        for (const key of ['relevance', 'downloads', 'name', 'mixed']) {
            // Either quote: relevance's wording contains an apostrophe, so it is a
            // double-quoted string and a single-quote pattern misses exactly the
            // entry this test exists to check.
            expect(container).toMatch(new RegExp(`\\n\\s{4}${key}: ['\"]`));
        }
    });
});

describe('the ordering is chosen from a <select>', () => {
    it('it is a real select, not a row of buttons', () => {
        // Asked for explicitly: four similarly-named options are what a dropdown
        // is for, and the chip row above already crowds the toolbar.
        // The element itself, from its opening tag to its closing tag, found by
        // this control's id. A bare /<select/ matches the other selects in this
        // file -- a global measurement put 15k characters between one of them and
        // the sort control's first <option> -- and a fixed-size window off the id
        // was too small, because the options array sits between the tags.
        const at = container.indexOf("id={'plugin-sort'}");
        const control = container.slice(container.lastIndexOf('<select', at), container.indexOf('</select>', at));

        expect(container).toContain("className={'at-sort__select'}");
        expect(control).toMatch(/<option/);
        // And nothing left over from the chip row it replaced.
        expect(control).not.toContain('<button');
        expect(control).not.toContain('at-chipbtn');
    });

    it('the label is bound to it', () => {
        // A <span> labelled the group but pointed at nothing, so a screen reader
        // announced "Sort" as an unlabelled group with no control in it.
        expect(container).toMatch(/<label className=\{'at-sort__label'\} htmlFor=\{'plugin-sort'\}/);
        expect(container).toContain("id={'plugin-sort'}");
    });

    it('choosing an option changes the sort', () => {
        expect(container).toMatch(/onChange=\{\(e\) => setSort\(e\.target\.value as AddOnSort\)\}/);
        // Cast, not a trust: a hand-edited value would otherwise reach the sort
        // comparison as a string that matches no branch and silently does nothing.
        expect(container).not.toMatch(/onChange=\{\(e\) => setSort\(e\.target\.value\)\}/);
    });

    it('the current choice is described on the control', () => {
        // Browsers are inconsistent about an <option>'s title, so the same text
        // has to be reachable from the control itself.
        expect(container).toContain('title={SORT_EXPLAINED[sort]}');
    });

    it('the arrow is drawn, since appearance is none', () => {
        // Without appearance:none the browser arrow is still drawn and lands in
        // the padding; without a replacement of its own the control reads as a
        // text input, because nothing about it says "this opens".
        expect(selectRule()).toContain('appearance: none;');
        expect(selectRule()).toContain('-webkit-appearance: none;');
        expect(selectRule()).toMatch(/background-image: url\("data:image\/svg\+xml/);
    });

    it('the control itself is styled in tokens, not fixed colours', () => {
        // The main rule only. A slice that ran on to the next rule picked up the
        // `option` rule's var(--at-surface), so hardcoding the control's own
        // background still passed -- the tokens were present, just not here.
        expect(selectRule()).toMatch(/background-color: var\(--at-surface\);/);
        expect(selectRule()).toMatch(/color: var\(--at-text\);/);
        expect(selectRule()).not.toMatch(/background-color: #[0-9a-f]{3,6};/i);
        expect(selectRule()).not.toMatch(/color: #[0-9a-f]{3,6};/i);
    });

    it('the option rows are coloured too', () => {
        // Checked separately, and not folded into the arrow assertion: the open
        // list is drawn by the OS widget, so it ignores the control's own colours
        // and comes out light-on-light against a dark panel without these.
        expect(selectOptionRule()).toMatch(/background-color: var\(--at-surface\);/);
        expect(selectOptionRule()).toMatch(/color: var\(--at-text\);/);
    });

    it('focus is visible', () => {
        expect(css()).toMatch(/\.at-sort__select:focus-visible \{/);
    });

    it('each palette gets its own arrow colour', () => {
        // A background-image data URI cannot inherit currentColor, so the arrow is
        // a fixed colour -- and one fixed colour cannot clear 3:1 against both
        // surfaces, which are too far apart in luminance. A single mid-grey
        // measured 2.41:1 light and 1.99:1 dark, so the dark palette needs its own
        // rule. Without this the dark control keeps the light arrow.
        expect(css()).toMatch(/\.aternos-dark \.at-sort__select \{/);

        // match() rather than matchAll(): spreading the latter's iterator yields
        // plain arrays here, not RegExpExecArray, so m.group is not a function.
        // With the /g flag match() returns whole matches, hence the slicing.
        const prefix = "fill='%23";
        const arrows = (css().match(/fill='%23[0-9a-fA-F]{6}'/g) ?? []).map((m) => '#' + m.slice(prefix.length, -2));

        expect(arrows).toHaveLength(2);
        expect(new Set(arrows).size).toBe(2);
    });

    it('and both arrows clear 3:1 against their own surface', () => {
        // Computed, not asserted as a literal: the whole point is that a palette
        // change can move a surface out from under a hard-coded arrow, and a
        // contrast ratio in a test is the only thing that notices.
        const surfaces: Record<string, string> = {
            '.aternos-blue': modeToken('--at-surface', '.aternos-blue'),
            '.aternos-dark': modeToken('--at-surface', '.aternos-dark'),
        };

        const arrows = [
            [css().match(/fill='%23([0-9a-fA-F]{6})'/)![1], '.aternos-blue'],
            [rule('.aternos-dark .at-sort__select {').match(/fill='%23([0-9a-fA-F]{6})'/)![1], '.aternos-dark'],
        ];

        for (const [arrow, scope] of arrows) {
            const ratio = contrastRatio('#' + arrow, surfaces[scope]);

            expect({ arrow, scope, ratio: Math.round(ratio * 100) / 100 }).toEqual({
                arrow,
                scope,
                ratio: expect.any(Number),
            });
            expect(ratio).toBeGreaterThanOrEqual(3);
        }
    });
});

describe('relevance does not re-rank what a source already ranked', () => {
    it('each stream is passed through untouched', () => {
        // The bug: every stream sorted by downloads before interleaving, so
        // Modrinth's relevance was discarded.
        const merge = providers.slice(providers.indexOf('const ordered ='));

        expect(merge).toMatch(/const ordered = byRelevance\s*\n\s*\?\s*settled\.map\(\(stream\) => \[\.\.\.stream\]\)/);
    });

    it('and the other sorts still rank', () => {
        // Relevance must not have quietly become "never sort".
        expect(merge_downloads()).toBeTruthy();
    });

    it('downloads still ranks across every source together', () => {
        const merge = providers.slice(providers.indexOf('const ordered ='));

        expect(merge).toMatch(/settled\.map\(\(stream\) => \[\.\.\.stream\]\.sort\(\(a, b\) => \(b\.downloads \?\? 0\)/);
    });

    it('name still sorts by title', () => {
        expect(providers).toContain('a.title.localeCompare(b.title)');
    });
});

describe('Modrinth is asked for relevance, and only when it means something', () => {
    it('a real query asks for relevance', () => {
        expect(providers).toMatch(/const relevanceFirst = Boolean\(opts\.query\) && sort !== 'name'/);
        expect(providers).toMatch(/sort: relevanceFirst \? 'relevance' : 'downloads'/);
    });

    it('an empty query is not', () => {
        // With nothing typed there is no query to be relevant to, and Modrinth's
        // relevance over an empty box is not useful.
        expect(providers).toContain('Boolean(opts.query)');
    });
});

/** Kept as a function so the assertion above reads as a claim, not a tautology. */
function merge_downloads(): boolean {
    const merge = providers.slice(providers.indexOf('const ordered ='));

    return merge.includes('.sort((a, b) => (b.downloads ?? 0)');
}

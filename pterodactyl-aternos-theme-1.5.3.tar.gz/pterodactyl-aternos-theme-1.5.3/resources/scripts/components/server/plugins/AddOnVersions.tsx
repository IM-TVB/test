import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faCircleNotch,
    faDownload,
    faExternalLinkAlt,
    faHistory,
    faInfoCircle,
    faTimes,
} from '@fortawesome/free-solid-svg-icons';
import { AddOnHit, AddOnVersion, versionsFor } from '@/api/server/plugins/providers';
import { providerLabel, providerPageUrl } from '@/api/server/plugins/panelFallback';
import Spinner from '@/components/elements/Spinner';

/**
 * The version picker.
 *
 * Reached by asking a project for its versions rather than by browsing a route:
 * the panel has no page per add-on, and a modal keeps the search results behind
 * it so coming back is a click rather than a re-search.
 *
 * The one thing this is careful about is not promising a download it cannot
 * perform. Spigot in particular will list forty versions and then refuse all but
 * the newest, and a row with a button that fails after the click is worse than a
 * row that says plainly why it cannot. So `installable` is carried all the way
 * from the provider rather than assumed here, and a row without it shows the
 * reason instead of a button.
 */

interface Props {
    hit: AddOnHit;
    onClose: () => void;
    onInstall: (hit: AddOnHit, version: AddOnVersion | null) => void;
    busy: boolean;
    /**
     * The server this list is for. Without it a version list cannot be fitted to
     * anything, and an unfitted list recommends whichever build the source
     * published most recently -- a NeoForge mod, or a snapshot, offered to a
     * Bukkit server.
     */
    loaders: string[];
    gameVersion: string;
}

/**
 * Why a row has no download button, in words rather than a disabled control.
 *
 * The row's own reason comes first: "built for Minecraft 1.8" answers "why can I
 * not install this", while the source-level reason -- "this project publishes its
 * file elsewhere" -- is a non-sequitur for a version that is simply the wrong
 * build.
 */
const whyNot = (hit: AddOnHit, version?: AddOnVersion | null): string => {
    if (version?.unavailableReason) {
        return version.unavailableReason;
    }

    if (hit.external) {
        return 'This project publishes its file elsewhere, so it cannot be downloaded from the panel.';
    }

    if (hit.provider === 'spigot') {
        return 'Spigot serves only the newest build of a resource. Older versions are not downloadable from here.';
    }

    return 'This version has no downloadable file.';
};

const AddOnVersions = ({ hit, onClose, onInstall, busy, loaders, gameVersion }: Props) => {
    const [state, setState] = useState<{ loading: boolean; versions: AddOnVersion[] }>({
        loading: true,
        versions: [],
    });
    const [error, setError] = useState<string | null>(null);
    const [working, setWorking] = useState<string | null>(null);

    // Resolved once rather than inside the render, and null for a project with no
    // reachable page.
    const pageUrl = providerPageUrl(hit);

    React.useEffect(() => {
        let live = true;

        // versionsFor swallows a source's failure and returns [], so a provider
        // that cannot be asked shows as "no versions" rather than an error. That
        // distinction matters: an empty list is a fact about the project, a
        // failure is a fact about us, and only the second is worth reporting.
        versionsFor(hit, { loaders, gameVersions: gameVersion ? [gameVersion] : [] })
            .then((versions) => {
                if (live) setState({ loading: false, versions });
            })
            .catch((e: Error) => {
                if (!live) return;
                setState({ loading: false, versions: [] });
                setError(e?.message ?? 'Could not load the version list.');
            });

        return () => {
            live = false;
        };
        // loaders and gameVersion are inputs, not incidental captures: changing
        // the software or the Minecraft version changes which build of this
        // project is installable, so the list has to be refetched.
    }, [hit, loaders, gameVersion]);

    return (
        <div className={'at-vmodal'} role={'dialog'} aria-modal={'true'} aria-label={`${hit.title} versions`}>
            <div className={'at-vmodal__scrim'} onClick={onClose} role={'presentation'} />

            <div className={'at-vmodal__panel'}>
                <header className={'at-vmodal__head'}>
                    <div className={'at-vmodal__heading'}>
                        <h2 className={'at-vmodal__title'}>{hit.title}</h2>
                        <span className={`at-pcard__src at-pcard__src--${hit.provider}`}>
                            {providerLabel(hit)}
                        </span>
                    </div>
                    <button type={'button'} className={'at-vmodal__close'} onClick={onClose} aria-label={'Close'}>
                        <FontAwesomeIcon icon={faTimes} />
                    </button>
                </header>

                {hit.description ? <p className={'at-vmodal__desc'}>{hit.description}</p> : null}

                {/*
                    providerPageUrl returns null for a project with no reachable
                    page, and an href of null renders a link that goes nowhere.
                    The row is omitted rather than disabled: there is no partial
                    usefulness in a link to a page that does not exist.
                */}
                {pageUrl ? (
                    <a
                        className={'at-vmodal__link'}
                        href={pageUrl}
                        target={'_blank'}
                        rel={'noopener noreferrer'}
                    >
                        <FontAwesomeIcon icon={faExternalLinkAlt} className={'at-vmodal__link-icon'} />
                        View on {providerLabel(hit)}
                    </a>
                ) : null}

                <div className={'at-vmodal__versions-head'}>
                    <FontAwesomeIcon icon={faHistory} className={'at-vmodal__versions-icon'} />
                    Versions
                </div>

                {state.loading ? (
                    <div className={'at-vmodal__state'}>
                        <Spinner size={'small'} /> Loading versions…
                    </div>
                ) : error ? (
                    <div className={'at-vmodal__state at-vmodal__state--error'}>
                        <FontAwesomeIcon icon={faInfoCircle} /> {error}
                    </div>
                ) : state.versions.length === 0 ? (
                    <div className={'at-vmodal__state'}>
                        This project does not publish a version list we can read.
                    </div>
                ) : (
                    <ul className={'at-vmodal__versions'}>
                        {state.versions.map((version) => (
                            <li key={version.id} className={'at-vmodal__version'}>
                                <span className={'at-vmodal__version-name'}>
                                    {version.version}
                                    {version.recommended ? (
                                        <span className={'at-vmodal__tag'}>recommended</span>
                                    ) : null}
                                    {!version.installable ? (
                                        <span className={'at-vmodal__tag at-vmodal__tag--muted'}>unavailable</span>
                                    ) : null}
                                </span>

                                {version.gameVersions.length > 0 ? (
                                    <span className={'at-vmodal__version-games'}>
                                        {version.gameVersions.slice(0, 4).join(' · ')}
                                        {version.gameVersions.length > 4
                                            ? ` +${version.gameVersions.length - 4}`
                                            : ''}
                                    </span>
                                ) : null}

                                {version.installable ? (
                                    <button
                                        type={'button'}
                                        className={'at-btn at-btn--sm at-btn--primary at-vmodal__dl'}
                                        disabled={busy}
                                        onClick={() => {
                                            setWorking(version.id);
                                            onInstall(hit, version);
                                        }}
                                        title={`Install ${version.version}`}
                                        aria-label={`Install ${version.version}`}
                                    >
                                        {busy && working === version.id ? (
                                            <Spinner size={'small'} />
                                        ) : (
                                            <FontAwesomeIcon icon={faDownload} />
                                        )}
                                    </button>
                                ) : (
                                    <span
                                        className={'at-vmodal__version-why'}
                                        title={whyNot(hit, version)}
                                    >
                                        <FontAwesomeIcon icon={faCircleNotch} />
                                    </span>
                                )}
                            </li>
                        ))}
                    </ul>
                )}

                <footer className={'at-vmodal__foot'}>
                    <button type={'button'} className={'at-btn at-btn--sm'} onClick={onClose}>
                        Close
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default React.memo(AddOnVersions);

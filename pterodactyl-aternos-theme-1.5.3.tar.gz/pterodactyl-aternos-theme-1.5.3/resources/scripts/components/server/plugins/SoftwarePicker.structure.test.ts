/**
 * The software picker is a two-step flow: pick the software, then pick one of its
 * versions, and only from that step can a reinstall be started.
 *
 * The version grid used to sit on the plugins page, which put "Reinstall with
 * <software>" one click from the software list. These assertions keep the steps
 * in order, because the ordering is the whole point and nothing else checks it.
 */
import { readFileSync } from 'fs';
import { join } from 'path';

const source = readFileSync(join(__dirname, 'SoftwarePicker.tsx'), 'utf8');

describe('SoftwarePicker wizard', () => {
    it('has a software step and a version step', () => {
        expect(source).toMatch(/useState<'software' \| 'version'>/);
        // Clicking a card only records the choice and advances the step.
        expect(source).toMatch(/setChosen\(option\);[\s\n]*setStep\('version'\);/);
    });

    it('hosts the version grid on the version step', () => {
        expect(source).toMatch(/<VersionGrid/);
        expect(source).toMatch(/softwareName=\{chosen\.name\}/);
    });

    it('does not open the confirmation from the software cards', () => {
        // setPending is what opens the destructive confirmation, so it must not
        // appear in a software card's onClick. Anchored on setChosen(option),
        // which only the card handler calls: slicing between `onClick` and
        // `at-scards` produced an empty string, because at-scards comes first in
        // the file and the assertion then passed without checking anything.
        const at = source.indexOf('setChosen(option)');
        expect(at).toBeGreaterThan(-1);

        const handler = source.slice(at - 300, at + 300);
        expect(handler).toMatch(/setStep\('version'\)/);
        expect(handler).not.toMatch(/setPending\(/);
    });

    it('offers a reinstall when the software differs OR only the version does', () => {
        // Judging on egg_id alone made "same software, new game version" look like
        // nothing to do -- which is the most common reason to reinstall at all.
        expect(source).toMatch(/chosen\.egg_id !== current\.egg_id \|\|/);
        expect(source).toMatch(/version !== \(current\.version/);
    });

    it('sends the version the operator picked', () => {
        // The button reads "Reinstall as Paper 1.21.4" but the payload omitted the
        // version, so the server was reinstalled with the egg's default and the
        // chosen one was discarded. The endpoint has always accepted it.
        expect(source).toMatch(/\.\.\.\(version \? \{ version \} : \{\}\)/);
    });

    it('reads the version from state inside the confirm callback', () => {
        // Otherwise a stale closure would reinstall whatever was selected when
        // the dialog opened rather than what is now shown in it.
        expect(source).toMatch(/\[pending, identifier, version, mutate, addFlash\]/);
    });

    it('offers the choice as a switch, defaulting to deleting', () => {
        // A reinstall and a wipe are different operations. The endpoint treats an
        // absent flag as "delete", so the dialog has to send the choice rather
        // than leave it to a default the user never saw.
        expect(source).toMatch(/const \[deleteFiles, setDeleteFiles\] = useState\(true\)/);
        expect(source).toMatch(/setDeleteFiles\(true\)/);
        expect(source).toMatch(/<Switch/);
        expect(source).toMatch(/name=\{'at-files'\}/);
        expect(source).toMatch(/label=\{'Delete existing files'\}/);
    });

    it('drives the switch from the change event, not a click handler', () => {
        expect(source).toMatch(/onChange=\{\(e\) => setDeleteFiles\(e\.target\.checked\)\}/);
    });

    it('remounts the switch when the dialog opens', () => {
        // Switch is uncontrolled and reads defaultChecked once on mount, so
        // without a key the knob would keep the last position while React state
        // said otherwise the next time the dialog was opened.
        expect(source).toMatch(/key=\{visible \? 'files-open' : 'files-closed'\}/);
        expect(source).toMatch(/defaultChecked\b/);
    });

    it('says what the switch position does, in the description', () => {
        // A bare label leaves the consequence to be inferred from the knob.
        expect(source).toMatch(/description=\{\s*deleteFiles/);
        expect(source).toContain('This is what a reinstall has always done.');
        expect(source).toContain('installed over the top');
    });

    it('passes the choice through to the confirm handler', () => {
        // .* rather than [^)]*: the argument list contains a nested
        // backups.find((b) => ...), so a "no parens" pattern cannot reach the
        // deleteFiles that follows it and would fail for the wrong reason.
        expect(source).toMatch(/onClick=\{\(\) => onConfirm\(.*deleteFiles\)\}/);
    });

    it('sends the choice explicitly rather than relying on the default', () => {
        expect(source).toMatch(/delete_files: deleteFiles,/);
    });

    it('warns that keeping files leaves ones the new software cannot read', () => {
        // The footgun: a Paper server reinstalled over Bungeecord keeps jars the
        // new software will never load, and they will not show as installed
        // either, so the failure is silent.
        expect(source).toMatch(/\{!deleteFiles && \(/);
        expect(source).toContain('will never load');
    });

    it('reports afterwards which of the two actually happened', () => {
        expect(source).toContain('existing files were deleted');
        expect(source).toContain('existing files were kept');
    });

    it('does not claim a deletion in the button label when keeping', () => {
        expect(source).toMatch(/deleteFiles \? 'Reinstall' : 'Install over'/);
    });

    it('imports React by name for the classic JSX runtime', () => {
        expect(source).toMatch(/^import React\b/m);
    });
});

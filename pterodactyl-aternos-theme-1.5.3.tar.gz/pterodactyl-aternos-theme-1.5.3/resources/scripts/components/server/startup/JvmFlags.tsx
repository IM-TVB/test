import React, { useCallback, useEffect, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';
import tw from 'twin.macro';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import Select from '@/components/elements/Select';
import Spinner from '@/components/elements/Spinner';
import InputSpinner from '@/components/elements/InputSpinner';
import { ServerContext } from '@/state/server';
import { getJvmFlags, JvmFlagOptions, setJvmFlags } from '@/api/server/jvmFlags';

/**
 * Picks the JVM flags this server's startup runs with.
 *
 * It lives on the startup page because that is where the command it edits is
 * shown, one box above. The panel substitutes flags from a fixed list, so the
 * client never supplies a flag: these end up inside a shell invocation that Wings
 * runs, and a text box here would be an injection point.
 *
 * Nothing is pushed to the daemon. Wings re-reads the configuration from the
 * panel in onBeforeStart(), before every start, so a change stored here is used
 * by the next boot -- which is also what makes it safe to change while the
 * server is running.
 *
 * The flag sets are Aikar's, and they were checked against a real JVM rather than
 * read: as published they do not start a current Java, because the flags they
 * depend on were removed in 12 and 14. Hence the -XX:+IgnoreUnrecognizedVMOptions
 * at the front of each, without which picking "Aikar" would take the server down
 * on the next start.
 */
const formatHeap = (mb: number): string => {
    if (mb >= 1024) {
        const gb = mb / 1024;

        return `${gb % 1 === 0 ? gb : gb.toFixed(1)} GB`;
    }

    return `${mb} MB`;
};

export default () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data?.uuid);
    const [data, setData] = useState<JvmFlagOptions | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [saving, setSaving] = useState(false);
    const [saved, setSaved] = useState<string | null>(null);

    const load = useCallback(() => {
        if (!uuid) return;

        setError(null);

        getJvmFlags(uuid)
            .then(setData)
            .catch((e: Error) => setError(e?.message ?? 'Could not load the JVM flag settings.'));
    }, [uuid]);

    useEffect(() => {
        load();
    }, [load]);

    const choose = async (preset: string) => {
        if (!uuid || saving) return;

        setSaving(true);
        setSaved(null);

        try {
            const next = await setJvmFlags(uuid, preset);

            setData(next);
            setSaved('Saved. The next time this server starts it will use these flags.');
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Could not change the JVM flags.');
            // Re-read rather than leaving the select showing a choice that was
            // refused: the startup is unchanged, so it must go back to what is
            // actually in it.
            load();
        } finally {
            setSaving(false);
        }
    };

    if (!uuid) {
        return null;
    }

    const chosen = data?.current.preset ?? '';

    // A stored command matching no preset is a fact the user needs, not an edge
    // case: an admin may have edited the startup, or the egg may have changed.
    // Reporting a preset that is not in the command would be a lie, so the
    // unrecognised flags are shown instead of a confident selection.
    const unrecognised = data && data.current.preset === null && data.current.flags !== null;
    const described = data?.presets.find((preset) => preset.key === chosen) ?? null;

    if (!data) {
        return (
            <TitledGreyBox title={'JVM Flags'} css={tw`mt-8`}>
                {error ? (
                    <p css={tw`text-xs text-red-500`}>
                        <FontAwesomeIcon icon={faExclamationTriangle} /> {error}
                    </p>
                ) : (
                    <Spinner size={'small'} />
                )}
            </TitledGreyBox>
        );
    }

    if (!data.supported) {
        return (
            <TitledGreyBox title={'JVM Flags'} css={tw`mt-8`}>
                <p css={tw`text-xs text-neutral-300`}>{data.reason}</p>
            </TitledGreyBox>
        );
    }

    return (
        <TitledGreyBox title={'JVM Flags'} css={tw`mt-8`}>
            <InputSpinner visible={saving}>
                <Select value={chosen} onChange={(e) => choose(e.target.value)}>
                    {unrecognised ? (
                        // A placeholder, not a third preset: it exists so the
                        // control does not claim a selection that is not in the
                        // command.
                        <option value={''}>Custom (not one of these)</option>
                    ) : null}
                    <option value={'pterodactyl'}>Pterodactyl default</option>
                    {data.presets.map((preset) => (
                        <option key={preset.key} value={preset.key} title={preset.blurb}>
                            {preset.label}
                        </option>
                    ))}
                </Select>
            </InputSpinner>

            <p css={tw`text-xs text-neutral-300 mt-2`}>
                The flags the server starts with. Your software's own flags are kept, so the memory this node
                allocates is unaffected.
            </p>

            {unrecognised ? (
                <p css={tw`text-xs text-neutral-300 mt-2`}>
                    This server is using flags that are not one of these:{' '}
                    <span css={tw`font-mono`}>{data.current.flags}</span>
                </p>
            ) : null}

            {described ? (
                <div css={tw`mt-3 space-y-2`}>
                    <p css={tw`text-xs text-neutral-300`}>{described.blurb}</p>

                    {!described.suited_to_this_server ? (
                        <p css={tw`text-xs text-yellow-500 flex items-start gap-1`}>
                            <FontAwesomeIcon icon={faExclamationTriangle} className={'mt-px'} /> These flags
                            are written for {formatHeap(described.target_heap_mb)} and up. This server has{' '}
                            {formatHeap(data.heap_mb)}, where they can make start-up slower rather than faster.
                        </p>
                    ) : null}

                    {described.dropped_on_modern_jvm.length > 0 ? (
                        <p css={tw`text-xs text-neutral-300`}>
                            A current Java ignores {described.dropped_on_modern_jvm.join(', ')} from this
                            set.
                        </p>
                    ) : null}

                    <p
                        css={tw`text-xs text-neutral-400 font-mono break-all bg-neutral-900 rounded p-2`}
                        className={'at-jvm__flags'}
                    >
                        {described.flags}
                    </p>
                </div>
            ) : null}

            {saved ? <p css={tw`text-xs text-green-500 mt-2`}>{saved}</p> : null}
            {error ? (
                <p css={tw`text-xs text-red-500 mt-2`}>
                    <FontAwesomeIcon icon={faExclamationTriangle} /> {error}
                </p>
            ) : null}
        </TitledGreyBox>
    );
};

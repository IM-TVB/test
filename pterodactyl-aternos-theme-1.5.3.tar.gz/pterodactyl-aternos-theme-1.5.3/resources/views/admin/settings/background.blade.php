@extends('layouts.admin')
@include('partials.admin.settings.nav', ['activeTab' => 'background'])

@section('title')
    Background
@endsection

@section('content-header')
    <h1>Panel Background<small>Put an image behind the panel, or leave it plain.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Settings</li>
    </ol>
@endsection

@section('content')
    @yield('settings::nav')

    {{--
        A photograph behind a text interface is unreadable unless something sits
        between the image and the text, so this is not an optional extra: the dim
        setting below is what keeps body text at the contrast it had with no
        image. The panel is composited as a solid page-coloured layer at
        (1 - dim) over the image, so `dim` changes how much of the photo you see
        and never whether you can read the page.
    --}}
    <form action="{{ route('admin.settings.background.update') }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PATCH')

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Background Image</h3>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-3 text-center">
                                @if($hasImage)
                                    <img
                                        src="{{ $url }}"
                                        alt="Current background"
                                        class="img-rounded"
                                        style="width:100%;max-width:220px;aspect-ratio:16/10;object-fit:cover"
                                    />
                                    <p class="text-muted">
                                        <small>
                                            Current background
                                            @if(!empty($meta['updatedAt']))
                                                &mdash; set {{ \Carbon\Carbon::parse($meta['updatedAt'])->diffForHumans() }}
                                            @endif
                                        </small>
                                    </p>
                                @else
                                    <div
                                        class="img-rounded"
                                        style="width:100%;max-width:220px;aspect-ratio:16/10;background:var(--at-surface-2);border:1px dashed var(--at-border-strong);display:flex;align-items:center;justify-content:center"
                                    >
                                        <span class="text-muted"><small>No background set</small></span>
                                    </div>
                                    <p class="text-muted"><small>No background set</small></p>
                                @endif
                            </div>
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label class="control-label">Upload a background</label>
                                    <input
                                        type="file"
                                        name="image"
                                        accept="image/png,image/jpeg,image/gif,image/webp"
                                    />
                                    <p class="text-muted">
                                        <small>
                                            PNG, JPEG, GIF or WebP, up to {{ number_format($maxBytes / 1048576, 0) }} MB.
                                            SVG is not accepted &mdash; it can carry script, and this file is
                                            downloaded by every visitor on every page. The file is written
                                            into <code>public/backgrounds/</code> and served straight from
                                            there, so it is fetched again whenever you replace it.
                                        </small>
                                    </p>
                                </div>

                                <div class="form-group">
                                    <label class="control-label" for="bg-fit">How it fills the background</label>
                                    <select name="fit" id="bg-fit" class="form-control">
                                        @foreach($fits as $option)
                                            <option value="{{ $option }}" @if($fit === $option) selected @endif>
                                                {{ ucfirst($option) }}
                                                @if($option === 'cover')
                                                    &mdash; fill the screen, cropping the edges
                                                @elseif($option === 'contain')
                                                    &mdash; show the whole image
                                                @else
                                                    &mdash; repeat it as a pattern
                                                @endif
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="control-label" for="bg-dim">
                                        Dim: <span id="bg-dim-value">{{ number_format($dim * 100, 0) }}%</span>
                                    </label>
                                    <input
                                        type="range"
                                        name="dim"
                                        id="bg-dim"
                                        class="form-control"
                                        min="{{ $minDim }}"
                                        max="{{ $maxDim }}"
                                        step="0.05"
                                        value="{{ $dim }}"
                                        oninput="document.getElementById('bg-dim-value').textContent = Math.round(this.value * 100) + '%'"
                                    />
                                    <p class="text-muted">
                                        <small>
                                            How far the panel's own colour is laid over the image.
                                            Higher means more of the panel colour and less of the photo.
                                            Text contrast is preserved either way &mdash; this changes
                                            how much of your image shows, not whether the page can be read.
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Reset</h3>
                </div>
                <div class="box-body">
                    <p class="text-muted" style="margin:0">
                        Removes the image and its stored settings, and puts the plain panel background
                        back. This does not touch the icon or the browser theme colour &mdash; those
                        have their own reset on the Branding page.
                    </p>
                </div>
                @if($hasImage)
                    <div class="box-footer">
                        <form
                            action="{{ route('admin.settings.background.reset') }}"
                            method="POST"
                            onsubmit="return confirm('Remove the background image and restore the default?')"
                        >
                            @csrf
                            <button type="submit" class="btn btn-sm btn-danger">Restore default</button>
                        </form>
                    </div>
                @endif
            </div>
        </div>
    </div>

    {{--
        The login page's own image, in its own form.

        Separate from the form above rather than a second set of fields in it,
        for two reasons that are not stylistic. A single form would have to give
        the two sliders and two selects distinct names while keeping the same
        `dim`/`fit` field names the controllers read, and the first form's values
        would be submitted with the second form's intent. And a single reset would
        have to mean "clear both" or "clear one", and the two are stored in
        different directories precisely so an operator can clear either without
        touching the other.

        The preview is a miniature of the login split: image behind, translucent
        panel on the left, card on the right. It is styled inline because the
        admin area loads no theme stylesheet -- assets/aternos.css is bundled into
        the client JS, which the admin layout never loads, so every `at-*` class
        and `var(--at-*)` here would be dead.
    --}}
    <form action="{{ route('admin.settings.auth-background.update') }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PATCH')

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Login Background</h3>
                    </div>
                    <div class="box-body">
                        <p class="text-muted" style="margin-top:0">
                            A separate image for the sign-in page, shown behind the whole screen
                            with the left-hand panel made translucent over it. Independent of the
                            panel background above: you can use one image for both, two different
                            ones, or a login image and no panel background.
                        </p>

                        <div class="row">
                            <div class="col-md-3 text-center">
                                @if($authHasImage)
                                    <img
                                        src="{{ $authUrl }}"
                                        alt="Current login background"
                                        class="img-rounded"
                                        style="width:100%;max-width:220px;aspect-ratio:16/10;object-fit:cover"
                                    />
                                    <p class="text-muted">
                                        <small>
                                            Current login background
                                            @if(!empty($authMeta['updatedAt']))
                                                &mdash; set {{ \Carbon\Carbon::parse($authMeta['updatedAt'])->diffForHumans() }}
                                            @endif
                                        </small>
                                    </p>
                                @else
                                    <div
                                        class="img-rounded"
                                        style="width:100%;max-width:220px;aspect-ratio:16/10;background:var(--at-surface-2,#f5f5f5);border:1px dashed #c8c8c8;display:flex;align-items:center;justify-content:center"
                                    >
                                        <span class="text-muted"><small>No login background set</small></span>
                                    </div>
                                    <p class="text-muted">
                                        <small>
                                            No login background set &mdash; the sign-in page keeps its
                                            original blue gradient.
                                        </small>
                                    </p>
                                @endif
                            </div>
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label class="control-label">Upload a login background</label>
                                    <input
                                        type="file"
                                        name="image"
                                        accept="image/png,image/jpeg,image/gif,image/webp"
                                    />
                                    <p class="text-muted">
                                        <small>
                                            PNG, JPEG, GIF or WebP, up to {{ number_format($authMaxBytes / 1048576, 0) }} MB.
                                            SVG is not accepted &mdash; it can carry script, and this file is
                                            downloaded by every visitor who tries to sign in. The file is
                                            written into <code>public/auth-backgrounds/</code> and served
                                            straight from there, so it is fetched again whenever you
                                            replace it.
                                        </small>
                                    </p>
                                </div>

                                <div class="form-group">
                                    <label class="control-label" for="auth-bg-fit">How it fills the login background</label>
                                    <select name="fit" id="auth-bg-fit" class="form-control">
                                        @foreach($fits as $option)
                                            <option value="{{ $option }}" @if($authFit === $option) selected @endif>
                                                {{ ucfirst($option) }}
                                                @if($option === 'cover')
                                                    &mdash; fill the screen, cropping the edges
                                                @elseif($option === 'contain')
                                                    &mdash; show the whole image
                                                @else
                                                    &mdash; repeat it as a pattern
                                                @endif
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="control-label" for="auth-bg-dim">
                                        Dim: <span id="auth-bg-dim-value">{{ number_format($authDim * 100, 0) }}%</span>
                                    </label>
                                    <input
                                        type="range"
                                        name="dim"
                                        id="auth-bg-dim"
                                        class="form-control"
                                        min="{{ $minDim }}"
                                        max="{{ $maxDim }}"
                                        step="0.05"
                                        value="{{ $authDim }}"
                                        oninput="document.getElementById('auth-bg-dim-value').textContent = Math.round(this.value * 100) + '%'"
                                    />
                                    <p class="text-muted">
                                        <small>
                                            How far the page colour is laid over the login image. Higher
                                            means more of the colour and less of the photo. The sign-in
                                            form sits on its own card either way, so this changes how
                                            much of your image shows, not whether the form can be read.
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-sm btn-primary pull-right">Save login background</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Reset Login Background</h3>
                </div>
                <div class="box-body">
                    <p class="text-muted" style="margin:0">
                        Removes the login image and its stored settings, putting the sign-in page's
                        original blue gradient back. This only touches
                        <code>public/auth-backgrounds/</code> &mdash; the panel background above, the
                        icon and the browser theme colour are all left alone.
                    </p>
                </div>
                @if($authHasImage)
                    <div class="box-footer">
                        <form
                            action="{{ route('admin.settings.auth-background.reset') }}"
                            method="POST"
                            onsubmit="return confirm('Remove the login background and restore the original gradient?')"
                        >
                            @csrf
                            <button type="submit" class="btn btn-sm btn-danger">Restore original</button>
                        </form>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection

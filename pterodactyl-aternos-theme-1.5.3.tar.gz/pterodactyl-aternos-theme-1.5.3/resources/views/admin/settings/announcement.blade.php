@extends('layouts.admin')
@include('partials.admin.settings.nav', ['activeTab' => 'announcement'])

@section('title')
    Announcement
@endsection

@section('content-header')
    <h1>Announcement<small>A banner shown to every visitor, e.g. maintenance, updates.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Settings</li>
    </ol>
@endsection

@section('content')
    @yield('settings::nav')

    <form action="{{ route('admin.settings.announcement.update') }}" method="POST">
        @csrf
        @method('PATCH')
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Site Announcement</h3>
                    </div>
                    <div class="box-body">
                        <div class="form-group">
                            <label class="control-label">Message</label>
                            <textarea name="message" class="form-control" rows="3" maxlength="500" placeholder="e.g. Scheduled maintenance on Sunday 02:00 UTC.">{{ $message }}</textarea>
                        </div>

                        <div class="form-group">
                            <label class="control-label">Style</label>
                            <select name="type" class="form-control">
                                @foreach($types as $t)
                                    <option value="{{ $t }}" @if($type === $t) selected @endif>{{ ucfirst($t) }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="control-label">Custom background colour (optional)</label>
                            <input type="color" name="color" value="{{ $color !== '' ? $color : '#f59e0b' }}" style="width:46px;height:34px;padding:1px;border:1px solid #d2d6de;border-radius:6px;background:#fff;vertical-align:middle" />
                            <input type="text" name="color_text" value="{{ $color }}" class="form-control input-sm" style="display:inline-block;max-width:130px;vertical-align:middle;margin-left:8px" placeholder="#f59e0b" />
                            <p class="text-muted"><small>Leave the field empty to use the style's built-in colour. The text colour is picked automatically for readability.</small></p>
                        </div>

                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="enabled" value="1" @if($enabled) checked @endif />
                                Show this announcement to visitors
                            </label>
                            @if($updatedAt)
                                <p class="text-muted"><small>Last changed: {{ $updatedAt }}</small></p>
                            @endif
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Save Announcement</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <script>
        (function () {
            var picker = document.querySelector('input[name="color"]');
            var text = document.querySelector('input[name="color_text"]');
            var form = picker && picker.form;
            if (!picker || !text || !form) return;
            picker.addEventListener('input', function () { text.value = picker.value; });
            text.addEventListener('change', function () {
                var v = text.value.trim();
                if (v === '') { picker.value = '#ffffff'; return; }
                if (v.charAt(0) !== '#') v = '#' + v;
                if (/^#[0-9a-fA-F]{6}$/.test(v)) picker.value = v;
            });
            form.addEventListener('submit', function () {
                // An empty hex field means "use the built-in palette", so the
                // colour picker's always-present value must not be submitted.
                if (text.value.trim() === '') { picker.removeAttribute('name'); }
            });
        })();
    </script>

    <form action="{{ route('admin.settings.announcement.reset') }}" method="POST">
        @csrf
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-danger">
                    <div class="box-body">
                        <label>
                            <input type="checkbox" name="confirm" value="1" required />
                            I understand this clears the announcement everywhere
                        </label>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-danger">Clear Announcement</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection

@include('partials/admin.settings.notice')

@section('settings::nav')
    @yield('settings::notice')
    <div class="row">
        <div class="col-xs-12">
            <div class="nav-tabs-custom nav-tabs-floating">
                <ul class="nav nav-tabs">
                    <li @if($activeTab === 'basic')class="active"@endif><a href="{{ route('admin.settings') }}">General</a></li>
                    <li @if($activeTab === 'mail')class="active"@endif><a href="{{ route('admin.settings.mail') }}">Mail</a></li>
                    <li @if($activeTab === 'advanced')class="active"@endif><a href="{{ route('admin.settings.advanced') }}">Advanced</a></li>
                    <li @if($activeTab === 'branding')class="active"@endif><a href="{{ route('admin.settings.branding') }}">Branding</a></li>
                    <li @if($activeTab === 'colors')class="active"@endif><a href="{{ route('admin.settings.colors') }}">Colors</a></li>
                    <li @if($activeTab === 'announcement')class="active"@endif><a href="{{ route('admin.settings.announcement') }}">Announcement</a></li>
                    <li @if($activeTab === 'background')class="active"@endif><a href="{{ route('admin.settings.background') }}">Background</a></li>
                    <li @if($activeTab === 'logo')class="active"@endif><a href="{{ route('admin.settings.logo') }}">Logo</a></li>
                    <li @if($activeTab === 'providers')class="active"@endif><a href="{{ route('admin.plugins.providers') }}">Plugin Sources</a></li>
                </ul>
            </div>
        </div>
    </div>
@endsection

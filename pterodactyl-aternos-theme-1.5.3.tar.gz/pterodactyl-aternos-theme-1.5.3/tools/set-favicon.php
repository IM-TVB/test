<?php

/**
 * set-favicon.php — CLI front-end for Pterodactyl\Services\Settings\FaviconService.
 *
 *   php tools/set-favicon.php path/to/logo.png [options]
 *
 * Options:
 *   --color=#007bff        mask-icon / theme colour (default: the current one)
 *   --name="My Panel"      name written into manifest.json
 *   --no-crop              letterbox instead of centre-cropping to a square
 *   --reset                restore the icons the panel shipped with
 *
 * The admin UI (Settings -> Branding) uses the same service, so both paths
 * behave identically. Nothing is rebuilt: the Blade templates cache-bust the
 * icons by mtime, so the change is live on the next page load.
 */

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "This script must be run from the command line.\n");
    exit(1);
}

$root = dirname(__DIR__);

$argv = $_SERVER['argv'];
array_shift($argv);

$source = null;
$color = null;
$name = null;
$crop = true;
$reset = false;

foreach ($argv as $arg) {
    if (str_starts_with($arg, '--color=')) {
        $color = substr($arg, 8);
    } elseif (str_starts_with($arg, '--name=')) {
        $name = trim(substr($arg, 7), '"\'');
    } elseif ($arg === '--no-crop') {
        $crop = false;
    } elseif ($arg === '--reset') {
        $reset = true;
    } elseif (!str_starts_with($arg, '--')) {
        $source = $arg;
    } else {
        fwrite(STDERR, "Unknown option: {$arg}\n");
        exit(1);
    }
}

if ($source === null && !$reset) {
    fwrite(STDERR, "Usage: php tools/set-favicon.php <image.png> [--color=#007bff] [--name=\"Panel\"] [--no-crop]\n");
    fwrite(STDERR, "       php tools/set-favicon.php --reset\n");
    exit(1);
}

if (!is_file($root . '/vendor/autoload.php')) {
    fwrite(STDERR, "Composer dependencies are missing. Run `composer install` in {$root} first.\n");
    exit(1);
}

require $root . '/vendor/autoload.php';

$app = require $root . '/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$icons = $app->make(Pterodactyl\Services\Settings\FaviconService::class);

if ($reset) {
    if ($icons->reset()) {
        echo "Default panel icon restored.\n";
    } else {
        fwrite(STDERR, "No stored copy of the default icon was found; nothing changed.\n");
        exit(1);
    }
    exit(0);
}

if (!is_file($source)) {
    fwrite(STDERR, "Source image not found: {$source}\n");
    exit(1);
}

$info = $icons->probe($source);

if (max($info[0], $info[1]) < 180) {
    fwrite(STDERR, "Warning: source is only {$info[0]}x{$info[1]}. 512x512 or larger gives the best result.\n");
}

echo "Source: {$source} ({$info[0]}x{$info[1]})\n";
echo "Output: {$icons->iconDirectory()}\n\n";

$result = $icons->regenerate($source, $color, $name, $crop);

printf(
    "\nDone. %d files, %.1f KB, theme colour %s.\nReload the panel — the new icon appears on the next page load.\n",
    $result['files'],
    $result['bytes'] / 1024,
    $result['color']
);

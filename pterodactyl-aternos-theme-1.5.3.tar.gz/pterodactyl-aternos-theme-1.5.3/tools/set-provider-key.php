<?php

/**
 * Sets or clears the API key for an external plugin source.
 *
 * This is the command-line equivalent of Admin -> Settings -> Plugin Sources,
 * which is the better place to do it: that page tests the key before accepting
 * it, and never renders the stored value back into the HTML. Use this when you
 * have shell access and no browser session, or to script it.
 *
 * One source needs a key:
 *   bukkit  an X-Api-Token from your dev.bukkit.org account -- not bukkit.org,
 *           which is unreachable and publishes no API.
 *
 * That upstream is not CORS-open, so the panel calls it server-side through
 * KeyedProviderProxy and the browser never holds the credential.
 *
 * Note: the old www.curseforge.com/account/api-proxies page no longer exists.
 * CurseForge's own API docs point at the Studios console for key generation.
 *
 * Usage:
 *   sudo -H php tools/set-provider-key.php bukkit <token>
 *   sudo -H php tools/set-provider-key.php bukkit --clear
 *   sudo -H php tools/set-provider-key.php          # show status
 */

define('LARAVEL_START', microtime(true));

require dirname(__DIR__) . '/vendor/autoload.php';

$app = require dirname(__DIR__) . '/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use Pterodactyl\Services\Plugins\ProviderKeyService;

$service = $app->make(ProviderKeyService::class);

$provider = $argv[1] ?? null;
$value = $argv[2] ?? null;

if ($provider === null) {
    printf("Plugin sources known to this panel:\n\n");
    foreach ($service->availability() as $row) {
        printf("  %-12s %-12s %s\n", $row['id'], $row['name'], $row['configured'] ? 'ready' : 'NOT configured');
        if ($row['hint']) {
            printf("               %s\n", $row['hint']);
        }
    }
    echo "\n";
    exit(0);
}

if (!array_key_exists($provider, ProviderKeyService::PROVIDERS)) {
    fprintf(STDERR, "Unknown provider '%s'. Known: %s\n", $provider, implode(', ', array_keys(ProviderKeyService::PROVIDERS)));
    exit(1);
}

if ($value === '--clear') {
    $service->forget($provider);
    printf("Cleared the key for '%s'.\n", $provider);
    exit(0);
}

if ($value === null) {
    fprintf(STDERR, "Usage: php tools/set-provider-key.php %s <key|--clear>\n", $provider);
    exit(1);
}

$service->set($provider, $value);
printf("Stored a %d-character key for '%s'.\n", strlen($value), $provider);
// No cache clear is needed: availability() reads the settings table on every
// request, so the browser's next fetch of /api/client/plugins/providers already
// reflects this. Saying otherwise would send an operator hunting for a problem
// that does not exist.
printf("Reload the plugin browser (or Admin -> Settings -> Plugin Sources) to see it take effect.\n");

<?php

/**
 * Creates (or refreshes) the Leaf egg in the Minecraft nest.
 *
 * Leaf is a Paper fork, so this mirrors the stock Paper egg field for field --
 * same docker images, startup command, config parsing and stop command -- and
 * differs only in the install script, which resolves a build from Leaf's v2 API
 * instead of PaperMC's.
 *
 * Idempotent: re-running updates the existing egg rather than adding a second
 * one, so it is safe to run after a panel upgrade.
 *
 * Usage:
 *   sudo -H php tools/add-leaf-egg.php            # create or update
 *   sudo -H php tools/add-leaf-egg.php --dry-run  # show what would change
 */

define('LARAVEL_START', microtime(true));

$root = dirname(__DIR__);

require $root . '/vendor/autoload.php';

$app = require $root . '/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use Ramsey\Uuid\Uuid;
use Pterodactyl\Models\Egg;
use Pterodactyl\Models\EggVariable;
use Pterodactyl\Models\Nest;

$dryRun = in_array('--dry-run', $argv, true);

const API = 'https://api.leafmc.one/v2/projects/leaf';

$installScript = <<<'ASH'
#!/bin/ash
# Leaf Installation Script
# Leaf is a Paper fork; the jar is resolved from Leaf's v2 build API.
#
# Project:   https://www.leafmc.one
# API:       https://api.leafmc.one/v2

PROJECT=leaf
API=https://api.leafmc.one/v2/projects/leaf
USER_AGENT="Pterodactyl (https://pterodactyl.io)"

cd /mnt/server

# A supplied download URL wins, exactly as it does on the Paper egg.
if [ -n "${DL_PATH}" ]; then
    echo "Using supplied download url: ${DL_PATH}"
    DOWNLOAD_URL=`eval echo $(echo ${DL_PATH} | sed -e 's/{{/${/g' -e 's/}}/}/g')`
    curl --fail --user-agent "${USER_AGENT}" -o ${SERVER_JARFILE} ${DOWNLOAD_URL} || {
        echo "Failed to download from the supplied URL."
        exit 1
    }
    exit 0
fi

# The payload is piped with printf, never echo: dash's echo interprets
# backslash escapes, which rewrites the escaped quotes inside the JSON and
# corrupts it into something jq cannot parse.
#
# Leaf's build list contains raw control characters inside commit messages --
# newlines and tabs appear literally inside JSON strings, which is invalid JSON
# and makes jq reject the entire document. Stripping every control character
# (including tab/newline/carriage return) is safe here: those three are only
# ever JSON whitespace *between* tokens, and removing them cannot join two
# tokens together in this payload.
#
# The `tr` is written out inline at every use rather than held in a variable: a
# variable would need the octal escapes in single quotes, and ${VAR} expansion
# does not re-parse them, so tr would receive literal backslashes and silently
# strip nothing.

if [ -z "${LEAF_VERSION}" ] || [ "${LEAF_VERSION}" = "latest" ]; then
    LEAF_VERSION=$(curl -sSL ${API} | tr -d '\000-\037' | jq -r '.versions[0]')
fi

# Leaf does not publish every version; fall back rather than fail the install.
VER_EXISTS=$(curl -sSL ${API} | tr -d '\000-\037' | jq -r --arg V "${LEAF_VERSION}" '.versions | index($V) != null')
if [ "${VER_EXISTS}" != "true" ]; then
    LEAF_VERSION=$(curl -sSL ${API} | tr -d '\000-\037' | jq -r '.versions[0]')
    echo "Minecraft version not offered by Leaf; using ${LEAF_VERSION}"
fi

# Resolve the build. Newest stable ("default") is preferred; some versions only
# ever publish experimental builds, so fall back to the newest of any channel
# rather than leaving the install with nothing to download.
if [ -z "${LEAF_BUILD}" ] || [ "${LEAF_BUILD}" = "latest" ]; then
    BUILDS=$(curl -sSL "${API}/versions/${LEAF_VERSION}/builds" | tr -d '\000-\037')
    LEAF_BUILD=$(printf '%s' "${BUILDS}" | jq -r '[.builds[] | select(.channel=="default")] | if length > 0 then max_by(.build).build else empty end')
    if [ -z "${LEAF_BUILD}" ] || [ "${LEAF_BUILD}" = "null" ]; then
        echo "No stable Leaf build for ${LEAF_VERSION}; using the newest available."
        LEAF_BUILD=$(printf '%s' "${BUILDS}" | jq -r '[.builds[].build] | max')
    fi
else
    BUILDS=$(curl -sSL "${API}/versions/${LEAF_VERSION}/builds" | tr -d '\000-\037')
    BUILD_EXISTS=$(printf '%s' "${BUILDS}" | jq -r --arg B "${LEAF_BUILD}" '[.builds[] | select((.build|tostring) == $B)] | length > 0')
    if [ "${BUILD_EXISTS}" != "true" ]; then
        echo "Leaf build ${LEAF_BUILD} does not exist for ${LEAF_VERSION}; using the newest stable."
        LEAF_BUILD=$(printf '%s' "${BUILDS}" | jq -r '[.builds[] | select(.channel=="default")] | if length > 0 then max_by(.build).build else ([.builds[].build] | max) end')
    fi
fi

if [ -z "${LEAF_BUILD}" ] || [ "${LEAF_BUILD}" = "null" ]; then
    echo "Could not resolve a Leaf build for ${LEAF_VERSION}."
    exit 1
fi

echo "Version being downloaded"
echo "MC Version: ${LEAF_VERSION}"
echo "Leaf build: ${LEAF_BUILD}"

DOWNLOAD_URL="${API}/versions/${LEAF_VERSION}/builds/${LEAF_BUILD}/downloads/leaf-${LEAF_VERSION}-${LEAF_BUILD}.jar"
echo "Downloading: ${DOWNLOAD_URL}"

# --fail turns an HTTP error into a non-zero exit instead of writing the error
# page to disk as if it were the jar.
curl --fail --user-agent "${USER_AGENT}" -o ${SERVER_JARFILE} ${DOWNLOAD_URL} || {
    echo "Failed to download ${DOWNLOAD_URL}"
    exit 1
}

# A jar is a zip archive, so it must start with "PK". Without this check a
# truncated or error response would be installed and only fail much later, at
# server start, with a far less obvious message.
if [ ! -s "${SERVER_JARFILE}" ] || [ "$(head -c 2 ${SERVER_JARFILE})" != "PK" ]; then
    echo "Downloaded file is not a valid jar; aborting."
    rm -f ${SERVER_JARFILE}
    exit 1
fi

# Paper forks refuse to start without these; the vanilla file is only fetched
# when missing so a reinstall keeps a customised copy.
if [ ! -f server.properties ]; then
    echo "Downloading MC server.properties"
    curl -sSL -o server.properties https://raw.githubusercontent.com/pterodactyl/game-eggs/main/minecraft/java/server.properties
fi

echo "done"
ASH;

$variables = [
    [
        'name' => 'Leaf Minecraft Version',
        'description' => 'The Minecraft version of Leaf to download.' . "\n\n" . 'Leave at latest to always get the newest version Leaf offers. Versions Leaf does not publish fall back to the newest one.',
        'env_variable' => 'LEAF_VERSION',
        'default_value' => 'latest',
        'user_viewable' => true,
        'user_editable' => true,
        'rules' => 'nullable|string|max:20',
    ],
    [
        'name' => 'Server Jar File',
        'description' => 'The name of the server jarfile to run the server with.',
        'env_variable' => 'SERVER_JARFILE',
        'default_value' => 'leaf.jar',
        'user_viewable' => true,
        'user_editable' => true,
        'rules' => 'required|regex:/^([\w\d._-]+)(\.jar)$/',
    ],
    [
        'name' => 'Leaf Build Number',
        'description' => 'The Leaf build number to download.' . "\n\n" . 'Leave at latest to get the newest stable build. Builds that do not exist fall back to the newest stable one.',
        'env_variable' => 'LEAF_BUILD',
        'default_value' => 'latest',
        'user_viewable' => true,
        'user_editable' => true,
        'rules' => 'nullable|string|max:20',
    ],
    [
        'name' => 'Download Path',
        'description' => 'A URL to use to download the jar rather than the ones in the install script. Not user viewable.',
        'env_variable' => 'DL_PATH',
        'default_value' => '',
        'user_viewable' => false,
        'user_editable' => false,
        'rules' => 'nullable|string',
    ],
];

$nest = Nest::where('name', 'Minecraft')->first();

if (!$nest) {
    fwrite(STDERR, "No nest named 'Minecraft' was found; nothing to do.\n");
    exit(1);
}

$attributes = [
    'nest_id' => $nest->id,
    'name' => 'Leaf',
    'description' => 'High-performance Paper fork with drastically reduced memory usage. Runs the full Paper and Purpur API, so every Bukkit, Spigot and Paper plugin works unchanged.',
    // The panel generates the author from its own service config for any new
    // egg, so use that rather than borrowing Paper's; it is what the admin
    // "Create Egg" form would have written.
    'author' => (string) config('pterodactyl.service.author', 'parker@pterodactyl.io'),
    'features' => ['eula', 'java_version', 'pid_limit'],
    'docker_images' => [
        'Java 25' => 'ghcr.io/pterodactyl/yolks:java_25',
        'Java 21' => 'ghcr.io/pterodactyl/yolks:java_21',
        'Java 17' => 'ghcr.io/pterodactyl/yolks:java_17',
        'Java 16' => 'ghcr.io/pterodactyl/yolks:java_16',
        'Java 11' => 'ghcr.io/pterodactyl/yolks:java_11',
        'Java 8' => 'ghcr.io/pterodactyl/yolks:java_8',
    ],
    'file_denylist' => [],
    'config_files' => '{"server.properties":{"parser":"properties","find":{"server-ip":"0.0.0.0","server-port":"{{server.build.default.port}}","query.port":"{{server.build.default.port}}"}}}',
    'config_startup' => '{"done":")! For help, type "}',
    'config_logs' => '{}',
    'config_stop' => 'stop',
    'startup' => 'java -Xms128M -XX:MaxRAMPercentage=95.0 -Dterminal.jline=false -Dterminal.ansi=true -jar {{SERVER_JARFILE}}',
    'script_container' => 'ghcr.io/pterodactyl/installers:alpine',
    'script_entry' => 'ash',
    'script_is_privileged' => true,
    'script_install' => $installScript,
    'force_outgoing_ip' => false,
    'config_from' => null,
];

$existing = Egg::where('nest_id', $nest->id)->where('name', 'Leaf')->first();

if ($dryRun) {
    printf("Dry run. Would %s egg 'Leaf' in nest #%d (%s).\n", $existing ? 'UPDATE' : 'CREATE', $nest->id, $nest->name);
    printf("  variables: %s\n", implode(', ', array_column($variables, 'env_variable')));
    exit(0);
}

if ($existing) {
    $existing->forceFill($attributes)->save();
    $egg = $existing;
    printf("Updated existing egg #%d 'Leaf'.\n", $egg->id);
} else {
    // forceFill, not create(): Egg's $fillable deliberately omits nest_id,
    // author and uuid, so mass assignment drops them silently and the model
    // then fails validation claiming all three are missing. The admin's
    // EggCreationService writes the same three through the repository, which
    // bypasses mass-assignment protection.
    $egg = new Egg();
    $egg->forceFill($attributes + ['uuid' => (string) Uuid::uuid4()->toString()])->save();
    printf("Created egg #%d 'Leaf'.\n", $egg->id);
}

// Variables are replaced wholesale so a re-run cannot leave duplicates behind
// behind from an older definition.
foreach ($egg->variables as $stale) {
    $stale->delete();
}

foreach ($variables as $definition) {
    EggVariable::create($definition + ['egg_id' => $egg->id]);
}

$egg->refresh()->load('variables');

printf("Egg #%d '%s' in nest '%s' now has %d variable(s).\n", $egg->id, $egg->name, $nest->name, $egg->variables->count());
printf("  %s\n", implode(', ', $egg->variables->pluck('env_variable')->all()));
printf("Existing servers are unaffected; they keep the egg they were created with.\n");

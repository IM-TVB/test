<?php

/**
 * Values the theme needs on the server side.
 *
 * Only one thing lives here, and it is here for a specific reason: the
 * background-image scrim is composed in wrapper.blade.php, before first paint,
 * as an rgba() over the image. A custom property cannot be used there, because
 * it is only defined once a theme class is on <html> and this rule has to be in
 * the head before that is known to be painted.
 *
 * So the page colour is stated here as rgb components as well as in the
 * stylesheet, and the two have to agree. `test-background.php` asserts that
 * they do, against the real stylesheet, because a mismatch would show as a
 * scrim that does not quite match the page it covers -- subtle, and the kind of
 * thing that survives for months.
 */
return [
    'background_page' => [
        // Must match --at-page in .aternos-blue (assets/aternos.css).
        'blue' => '120, 177, 242',
        // Must match --at-page in .aternos-dark, which is hsl(209, 20%, 25%).
        'dark' => '51, 64, 76',
    ],
];

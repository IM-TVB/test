<?php

/**
 * Print the panel's resolved database settings, for panel-update.sh to consume.
 *
 * Why not read .env directly from the shell:
 *
 *   The password on this install is 64 characters and the naive parse got it
 *   wrong, so mysqldump was handed a truncated one and refused. A .env value may
 *   be quoted, may contain a `#` that a shell comment would eat, and may be
 *   overridden in config/database.php -- which the panel's own bootstrap already
 *   knows about and a text parse does not.
 *
 * So the panel is asked, rather than the file being interpreted. That also makes
 * this portable: it is the same answer on any install, whatever the .env looks
 * like there.
 *
 * Output is one KEY=VALUE per line, shell-sourceable. The password is a single
 * line and may contain spaces, so it is emitted quoted.
 */

require $argv[1] . '/vendor/autoload.php';

$app = require $argv[1] . '/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$connection = config('database.default');
$config = config('database.connections.' . $connection);

if (! is_array($config) || ! isset($config['database'], $config['username'])) {
    fwrite(STDERR, "Could not resolve a database connection for '" . $connection . "'.\n");
    exit(1);
}

$quote = static function ($value): string {
    return "'" . str_replace("'", "'\\''", (string) $value) . "'";
};

$rows = [
    'DB_CONNECTION' => $connection,
    'DB_HOST' => $config['host'] ?? '127.0.0.1',
    'DB_PORT' => $config['port'] ?? 3306,
    'DB_DATABASE' => $config['database'],
    'DB_USERNAME' => $config['username'],
    'DB_PASSWORD' => $config['password'] ?? '',
    // An empty socket means TCP. Pterodactyl's own default leaves it empty even
    // when host is localhost, so this cannot be used to decide anything.
    'DB_SOCKET' => $config['unix_socket'] ?? '',
];

foreach ($rows as $key => $value) {
    echo $key . '=' . $quote($value) . "\n";
}

// One extra line the shell cannot get wrong: how to actually reach the server.
$viaSocket = ($rows['DB_SOCKET'] ?? '') !== '';
echo 'DB_VIA_SOCKET=' . ($viaSocket ? 'yes' : 'no') . "\n";
